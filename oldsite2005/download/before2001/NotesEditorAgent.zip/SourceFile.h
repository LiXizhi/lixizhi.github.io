#if !defined(AFX_SOURCEFILE_H__D3F178B2_0233_4B08_BC0F_8C7AE208112E__INCLUDED_)
#define AFX_SOURCEFILE_H__D3F178B2_0233_4B08_BC0F_8C7AE208112E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SourceFile.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSourceFile view

class CSourceFile : public CEditView
{
protected:
	CSourceFile();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CSourceFile)

// Attributes
public:

// Operations
public:
	void SetModify(BOOL nStatus);
	void SetParseState(BOOL nStatus);
	BOOL IsParsed();
	BOOL m_bIsParsed;
	BOOL IsModified();
	void ProjectOpenSrc();
	void ProjectSaveSrc();
	void ProjectSaveasSrc();
	void QuickSave();
	
	CString GetFilePath();
	BOOL HighLightPos(int nFrom, int nTo);
	void ReLoad(CString path = _T(""));
	CString m_strFilePath;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSourceFile)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSourceFile();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CSourceFile)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SOURCEFILE_H__D3F178B2_0233_4B08_BC0F_8C7AE208112E__INCLUDED_)

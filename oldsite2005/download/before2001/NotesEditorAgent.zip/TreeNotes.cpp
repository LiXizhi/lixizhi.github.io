// TreeNotes.cpp : implementation file
//

#include "stdafx.h"
#include "NotesEditor.h"
#include "TreeNotes.h"


#include "MainFrm.h"

#include "NotesEditorDoc.h"

#include "NotesEditorView.h"
#include "FreeEdit.h"
#include "SourceFile.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMainFrame* g_pMainWnd;

/////////////////////////////////////////////////////////////////////////////
// CTreeNotes

IMPLEMENT_DYNCREATE(CTreeNotes, CTreeView)

CTreeNotes::CTreeNotes()
{
}

CTreeNotes::~CTreeNotes()
{
}


BEGIN_MESSAGE_MAP(CTreeNotes, CTreeView)
	//{{AFX_MSG_MAP(CTreeNotes)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeNotes drawing

void CTreeNotes::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CTreeNotes diagnostics

#ifdef _DEBUG
void CTreeNotes::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTreeNotes::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTreeNotes message handlers

//-----------------------------------------------------
// display all the contents in the notes
//-----------------------------------------------------
void CTreeNotes::VisualizeAll()
{
	CNotesEditorDoc* pDoc = ((CNotesEditorDoc*)GetDocument());
	ASSERT(pDoc);

	NoteItem* pItem = pDoc->m_pNoteList;
	
	// clear all items in the list
	GetTreeCtrl().DeleteAllItems();
	
	//TODO: build Tree text
	int nCurrentLayer = 0;
	HTREEITEM hCurParent = GetTreeCtrl().InsertItem("ROOT",0,1);
	while(pItem)
	{
		// Set currect layer
		if(pItem->m_nLayer>nCurrentLayer)
		{
			nCurrentLayer++;
			int nIndex = GetImageIndex(nCurrentLayer);
			hCurParent = GetTreeCtrl().InsertItem("SubLayer", nIndex, nIndex+1, hCurParent);
		}
		else if(pItem->m_nLayer<nCurrentLayer)
		{
			hCurParent = GetTreeCtrl().GetParentItem(hCurParent);
			nCurrentLayer--;
		}
		
		if(hCurParent)
		{
			// attach the notes here
			GetTreeCtrl().InsertItem(pItem->m_str, 0,1, hCurParent);
		}
		else
		{
			// an error is met
			return;
		}

		pItem = pItem->m_pNext;
	}

	GetTreeCtrl().Expand(GetTreeCtrl().GetRootItem(), TVE_EXPAND);
}

void CTreeNotes::OnInitialUpdate() 
{
	CTreeView::OnInitialUpdate();
	
	m_bmpTreeNodes.Create(IDB_TREENODES, 16, 10, ILC_COLOR16);
	GetTreeCtrl().SetImageList(&m_bmpTreeNodes, TVSIL_NORMAL);

}

#define PAIR_NUMBER	5
int CTreeNotes::GetImageIndex(int nLayer)
{
	int nIndex = 2*nLayer;
	if(nLayer<PAIR_NUMBER)
		return nIndex;
	return (PAIR_NUMBER-1)*2; 
}

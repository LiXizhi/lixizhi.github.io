// SourceFile.cpp : implementation file
//

#include "stdafx.h"
#include "NotesEditor.h"
#include "SourceFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CSourceFile

IMPLEMENT_DYNCREATE(CSourceFile, CEditView)

CSourceFile::CSourceFile()
{
	m_strFilePath = _T("");
	m_bIsParsed = FALSE; 
}

CSourceFile::~CSourceFile()
{
}


BEGIN_MESSAGE_MAP(CSourceFile, CEditView)
	//{{AFX_MSG_MAP(CSourceFile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSourceFile drawing

void CSourceFile::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CSourceFile diagnostics

#ifdef _DEBUG
void CSourceFile::AssertValid() const
{
	CEditView::AssertValid();
}

void CSourceFile::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSourceFile message handlers

void CSourceFile::ReLoad(CString path)
{
	if (path != _T(""))
	{
		CFile file;
		if(file.Open(path, CFile::modeReadWrite|CFile::shareDenyNone))
		{
			file.Close();
			// the file exists, so we open it
			m_strFilePath = path;
			ReLoad();
		}
	}
	else
	{
		// Reload file(in m_strFilePath) to the source viewer
		CFile file;
		if(file.Open(m_strFilePath, CFile::modeReadWrite|CFile::shareDenyNone))
		{
			CArchive ar(&file, CArchive::load);
			SerializeRaw(ar);
			ar.Close();
			file.Close();
			// file is changed, we need to parse it before using
			SetParseState(FALSE);
		}
	}
}

//--------------------------------
// center the contents in position specified by the parameters (in BYTEs of the file)
// in the view, the high light them(Select them)
//--------------------------------
BOOL CSourceFile::HighLightPos(int nFrom, int nTo)
{
	//TODO:
	return TRUE;
}

void CSourceFile::ProjectOpenSrc() 
{
	CFileDialog dlg(TRUE);
	
	if(dlg.DoModal() == IDOK)
	{
		// Load file
		ReLoad(dlg.GetPathName());
	}
}

void CSourceFile::ProjectSaveSrc() 
{
	// save what is in the viewer to the file
	CFile file;
	if(file.Open(m_strFilePath, CFile::modeReadWrite|CFile::shareDenyNone))
	{
		file.Close();

		if(file.Open(m_strFilePath, CFile::modeCreate|CFile::modeReadWrite|CFile::shareDenyNone))
		{
			CArchive ar(&file, CArchive::store);
			SerializeRaw(ar);
			ar.Close();
			file.Close();
			// file is changed, we need to parse it before using
			SetParseState(FALSE);
			SetModify(FALSE);
		}
	}
	else
	{
		// if the file doesn't exist, we will save as a new file
		ProjectSaveasSrc();
	}
}

void CSourceFile::ProjectSaveasSrc() 
{
	CFileDialog dlg(FALSE, NULL, m_strFilePath);
	
	if(dlg.DoModal() == IDOK)
	{
		// save what is in the viewer to the file
		CFile file;
		if(file.Open(dlg.GetPathName(), CFile::modeCreate|CFile::modeReadWrite|CFile::shareDenyNone))
		{
			CArchive ar(&file, CArchive::store);
			SerializeRaw(ar);
			ar.Close();
			file.Close();
			// file is changed, we need to parse it before using
			SetParseState(FALSE);
			SetModify(FALSE);
		}
	}
}

CString CSourceFile::GetFilePath()
{
	return m_strFilePath;
}


void CSourceFile::QuickSave()
{
	ProjectSaveSrc();
}

BOOL CSourceFile::IsModified()
{
	return GetEditCtrl().GetModify();
}

//----------------------------------
// usually, if a file is parsed, the source file should be unmodified
//----------------------------------
BOOL CSourceFile::IsParsed()
{
	return m_bIsParsed;
}

void CSourceFile::SetParseState(BOOL nStatus)
{
	m_bIsParsed = nStatus;
}

void CSourceFile::SetModify(BOOL nStatus)
{
	GetEditCtrl().SetModify(nStatus);
}

// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "NotesEditor.h"

#include "NotesEditorView.h"
#include "FreeEdit.h"
#include "SourceFile.h"
#include "TreeNotes.h"

#include "MainFrm.h"


#include "AgentCtlCharacters.h"
#include "agentctlaudioobjectex.h"
#include "agentctlspeechinput.h"
#include "AgentCtlPropertySheet.h"
#include "agentctlcommandswindow.h"

#include "agentctlrequest.h"
#include "agentctlcharacterex.h"
#include "agentctlcommandsex.h"

#include "agentctlcommandex.h"
#include "agentctlcommand.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CMainFrame* g_pMainWnd = NULL;
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_COMMAND(ID_AGENT_SHOW, OnAgentShow)
	ON_UPDATE_COMMAND_UI(ID_AGENT_SHOW, OnUpdateAgentShow)
	ON_COMMAND(ID_AGENT_INTRO, OnAgentIntro)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	BOOL bResult;
	
	// create the main splitterWnd: the left is the AIOutputView. the right is another embedded splitter window
	bResult = m_wndSplitterMain.CreateStatic( this, 1, 2);
	ASSERT(bResult);

	m_wndSplitterMain.CreateView(0, 0, RUNTIME_CLASS(CSourceFile), CSize(300,400), pContext);
	
	// create the right splitterWnd: the up is the AIMapView. the down is AICmdView
	bResult = m_wndSplitterRight.CreateStatic( &m_wndSplitterMain, 3, 1, 
		WS_CHILD | WS_VISIBLE, m_wndSplitterMain.IdFromRowCol(0,1));
	ASSERT(bResult);

	m_wndSplitterRight.CreateView(0, 0, RUNTIME_CLASS(CFreeEdit), CSize(300,200), pContext);
	m_wndSplitterRight.CreateView(1, 0, RUNTIME_CLASS(CTreeNotes), CSize(300,150), pContext);
	m_wndSplitterRight.CreateView(2, 0, RUNTIME_CLASS(CInfoView), CSize(300,50), pContext);

	SetActiveView((CView*)m_wndSplitterRight.GetPane(0,0));
	
	// Create the microsoft agent control.
	m_Agent.Create("Agent", WS_CHILD|WS_DISABLED, CRect(0,0,0,0), this, 777);
	m_Agent.SetConnected(TRUE);

	// Create a variant to store the full path of the character to load
	/*
	VARIANT vPath;
	VariantInit(&vPath);

	vPath.vt = VT_BSTR;
	vPath.bstrVal = SysAllocString(L"merlin.acs");
	*/
	COleVariant vPath;
	vPath = "merlin.acs";
	m_Agent.GetCharacters().Load("merlin", vPath);
	
	CAgentCtlCommandsEx CtlCmd = m_Agent.GetCharacters().GetItem("merlin").GetCommands();
	
	COleVariant str = "ParsingCmd";
	COleVariant val;
	val.boolVal = TRUE;
	CtlCmd.Add("Parsing", str, str, val,val);
	g_pMainWnd = this;
	return bResult;

}

CView* CMainFrame::GetFreeView()
{
	return ((CView*)m_wndSplitterRight.GetPane(0,0));
}

CView* CMainFrame::GetSourceView()
{
	return ((CView*)m_wndSplitterMain.GetPane(0,0));

}

CView* CMainFrame::GetInfoView()
{
	return ((CView*)m_wndSplitterRight.GetPane(2,0));
}

CView* CMainFrame::GetTreeNotesView()
{
	return ((CView*)m_wndSplitterRight.GetPane(1,0));
}

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();
}

void CMainFrame::OnAgentShow() 
{
	COleVariant val;
	val.boolVal = FALSE;
	if( !m_Agent.GetCharacters().GetItem("merlin").GetVisible())
	{
		// show it
		m_Agent.GetCharacters().GetItem("merlin").Show(val);
	}
	else
	{
		// Hide it
		m_Agent.GetCharacters().GetItem("merlin").Hide(val);
	}
}

void CMainFrame::OnUpdateAgentShow(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_Agent.GetCharacters().GetItem("merlin").GetVisible());
}

void CMainFrame::OnAgentIntro() 
{
	// Make the character speak
	ShowAgentAnyWay();

	PlayAgentMessage("Hello World");

}

void CMainFrame::ShowAgentAnyWay()
{
	if( !m_Agent.GetCharacters().GetItem("merlin").GetVisible())
	{
		COleVariant val;
		val.boolVal = FALSE;
	
		// show it
		m_Agent.GetCharacters().GetItem("merlin").Show(val);
	}

}

void CMainFrame::PlayAgentMessage(LPCTSTR msg)
{
	// we only put out message when the agent is alive
	if( m_Agent.GetCharacters().GetItem("merlin").GetVisible())
	{
		// Make the character speak
		COleVariant bszSpeak = msg;
		COleVariant val;
		val.intVal = NULL;
		m_Agent.GetCharacters().GetItem("merlin").Speak(bszSpeak, val);
	}
}


// NotesEditorDoc.cpp : implementation of the CNotesEditorDoc class
//

#include "stdafx.h"
#include "NotesEditor.h"
#include "MainFrm.h"

#include "NotesEditorDoc.h"

#include "NotesEditorView.h"
#include "FreeEdit.h"
#include "SourceFile.h"
#include "TreeNotes.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMainFrame* g_pMainWnd;

#define TYPE_NUM	5
TCHAR MarkSet[][2][MAX_LEN] =
{
	{_T("//"), _T("\r\n")},
	{_T("/*"), _T("*/")},
	{_T("{"), _T("{")},
	{_T("}"), _T("}")},
	{_T("\""), _T("\"")},
};

enum MARK_TYPE
{
	DoubleSlash = 0, SlashAsterisk, BracketLeft, BracketRight, Quotation
};

#define ERROR_PARSING	-1
#define NO_FILE		5
#define PARSING_OK		77
#define PARSING_START	1
#define OPERATION_DENIED 4
/////////////////////////////////////////////////////////////////////////////
// CNotesEditorDoc

IMPLEMENT_DYNCREATE(CNotesEditorDoc, CDocument)

BEGIN_MESSAGE_MAP(CNotesEditorDoc, CDocument)
	//{{AFX_MSG_MAP(CNotesEditorDoc)
	ON_COMMAND(ID_PROJECT_PARSING, OnProjectParsing)
	ON_COMMAND(ID_SYC_DEL_ALL, OnSycDelAll)
	ON_COMMAND(ID_PROJECT_SAVE_SRC, OnProjectSaveSrc)
	ON_COMMAND(ID_PROJECT_SAVEAS_SRC, OnProjectSaveasSrc)
	ON_COMMAND(ID_PROJECT_OPEN_SRC, OnProjectOpenSrc)
	ON_COMMAND(ID_SYCHO_DO_CMD, OnDoCmd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNotesEditorDoc construction/destruction

CNotesEditorDoc::CNotesEditorDoc()
{
	m_pNoteList = NULL;
	
	// this is the ANIC code, unicode is not supportted is this version
	m_nBytePerChar = 1;
}

CNotesEditorDoc::~CNotesEditorDoc()
{
	SafeReleaseList(&m_pNoteList);
}

BOOL CNotesEditorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	((CFreeEdit*)g_pMainWnd->GetFreeView())->ClearAll();

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CNotesEditorDoc serialization

void CNotesEditorDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	
	((CFreeEdit*)g_pMainWnd->GetFreeView())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CNotesEditorDoc diagnostics

#ifdef _DEBUG
void CNotesEditorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CNotesEditorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CNotesEditorDoc commands
void CNotesEditorDoc::OnProjectSaveSrc() 
{
	((CSourceFile*)g_pMainWnd->GetSourceView())->ProjectSaveSrc();
}

void CNotesEditorDoc::OnProjectSaveasSrc() 
{
	((CSourceFile*)g_pMainWnd->GetSourceView())->ProjectSaveasSrc();
	
}

void CNotesEditorDoc::OnProjectOpenSrc() 
{
	((CSourceFile*)g_pMainWnd->GetSourceView())->ProjectOpenSrc();
}


void CNotesEditorDoc::AddToTail(NoteItem *pObject, NoteList *pList)
{
	if((*pList) == NULL)
	{
		AddToList(pObject, pList);
		return;
	}

	NoteItem* pItem = (*pList);
	
	while(pItem->m_pNext)
	{
		pItem = pItem->m_pNext;
	}

	AddToList(pObject, &pItem);
}

void CNotesEditorDoc::AddToList(NoteItem *pObject, NoteList *pList)
{
	if((*pList) == NULL)
	{
		(*pList) = pObject;
		pObject->m_pPrev = NULL;
		pObject->m_pNext = NULL;

		return;
	}

	pObject->m_pNext = (*pList)->m_pNext;
    pObject->m_pPrev = (*pList);

    if( (*pList)->m_pNext )
        (*pList)->m_pNext->m_pPrev = pObject;
    (*pList)->m_pNext = pObject;
}

// this is a static function
void CNotesEditorDoc::DeleteFromList(NoteItem *pObject, NoteList *pList)
{
	if( pObject->m_pNext )
        pObject->m_pNext->m_pPrev = pObject->m_pPrev;
    if( pObject->m_pPrev )
        pObject->m_pPrev->m_pNext = pObject->m_pNext;
    // point the list to a new header, if the header is being deleted 
	if((*pList) == pObject)
		(*pList) = pObject->m_pNext;
	delete( pObject );
}

void CNotesEditorDoc::SafeReleaseList(NoteList *ppList)
{
	NoteItem * pObject = *ppList;
	while( pObject )
	{
		NoteItem* pTempObj = pObject->m_pNext;

		DeleteFromList(pObject, ppList);
		
		pObject = pTempObj;
	}
}


void CNotesEditorDoc::SortList()
{

}

//---------------------------------------------------
// this is the central working function to generate the list from the source file
//---------------------------------------------------
int CNotesEditorDoc::GenerateNotesList()
{
	int nResult = PARSING_OK;
	CString strSrcPath = ((CSourceFile*)g_pMainWnd->GetSourceView())->GetFilePath();
	CFile file;
	if(file.Open(strSrcPath, CFile::modeRead|CFile::shareDenyNone))
	{
		//----------------------------------------------
		// we have successfully opened the file
		// now we will start parsing the file
		//----------------------------------------------
		
		//-------------------------------------
		// Add headings to the first note
		//-------------------------------------
		// 0 denotes the root of the notes tree
		int nCurrenLayer = 0;

		{
			NoteItem* pItem = new NoteItem();
			pItem->m_str = _T("/*M Notes Editor version 1.0: \r\n")
						   _T("Created from: ");
			pItem->m_str += strSrcPath + "\r\n";
			pItem->m_str += _T("Last modified: ");
			CTime time = CTime::GetCurrentTime();
			pItem->m_str += time.Format("%#c");
			pItem->m_str += "\r\n//------contents----------------------//*/\r\n";

			pItem->m_nFrom = 0;
			pItem->m_nTo = 0;
			
			pItem->m_nLayer = nCurrenLayer;
			
			AddToList(pItem, &m_pNoteList);
		}


		file.SeekToBegin();
		BOOL nRunning = TRUE;
		do
		{
			// in each cycle, we will progress a "meaningful" amount of BYTEs
			int nType = FindNextMark(&file);
			
			switch(nType)
			{
				case DoubleSlash:
				case SlashAsterisk:
				{
					//---------------
					//	()denotes the current file position, * denotes a BYTE 
					//	File postion: //(*)*******
					//---------------
					int nLen = FindPairMark(&file, nType);
					if(nLen < 0)
					{
						// An error is detected
						nRunning = FALSE;
						nResult = ERROR_PARSING;
					}
					else
					{
						//---------------
						//	()denotes the current file position, * denotes a BYTE 
						//	File postion: //********\r\n(*)
						//---------------
						NoteItem* pItem = new NoteItem();
						pItem->m_nLayer = nCurrenLayer;
						pItem->m_nTo = file.GetPosition();
						char * str = pItem->m_str.GetBuffer(nLen+10);
						
						int nSegmentLen = nLen+(int)strlen(MarkSet[nType][0])*m_nBytePerChar;
						file.Seek(-nSegmentLen, CFile::current);
						pItem->m_nFrom = file.GetPosition();
						file.Read(str, nSegmentLen);
						
						str[nSegmentLen]= '\0'; 
						
						pItem->m_str.ReleaseBuffer();

						//---------------
						//	()denotes the current file position, * denotes a BYTE 
						//	File postion: //********/r/r(/n)
						//---------------

						AddToTail(pItem, &m_pNoteList);
					}
					break;
				}
				case BracketLeft:
				{
					nCurrenLayer++;
					break;
				}
				case BracketRight:
				{
					nCurrenLayer--;
					if(nCurrenLayer<0)
					{
						// An error is detected
						nRunning = FALSE;
						nResult = ERROR_PARSING;
					}

					break;
				}
				case Quotation:
				{
					for(;;)
					{
			
						int nLen = FindPairMark(&file, nType);
						if(nLen < 0)
						{
							// An error is detected
							nResult = ERROR_PARSING;
							nRunning = FALSE;
							break;
						}
						
						// avoid "****(\")****"
						char cChar;
						file.Seek(-2, CFile::current);
						file.Read(&cChar, 1);
						file.Seek(1, CFile::current);
						if(cChar != '\\')
						{
							break;
						}
					}

					break;
				}
				default:
				{
					// an error is discovered
					// TODO: deal with it
					nRunning = FALSE;
				}
			}
				
		}while(nRunning);

		if(nCurrenLayer!=0)
		{
			// An error is detected
			// Layer should return to 0
			nRunning = FALSE;
			nResult = ERROR_PARSING;
		}

		file.Close();
	}
	else
		nResult = NO_FILE;
	
	return nResult;
}

//------------------------------------------------------
// find the corresponding mark in the Markset[nType][1][]
// the file pointer is set at the next unrelated BYTE in the CFile
// Return:
//	If succeeded, return length of the read BYTE, else return -1
//------------------------------------------------------
int CNotesEditorDoc::FindPairMark(CFile *pFile, int nType)
{
	return FindMark(pFile, MarkSet[nType][1]);
}

//--------------------------------------------
// find the mark in str
// the file pointer is set at the next unrelated BYTE in the CFile
// Return:
//	If succeeded, return length of the read BYTE, else return -1
//------------------------------------------------------
int CNotesEditorDoc::FindMark(CFile *pFile, LPCTSTR str)
{
	int zoneTest = 0;
	int nFileLen = pFile->GetLength();
	
	for(int nLen = 0; nLen<nFileLen;)
	{
		char cChar;
		pFile->Read(&cChar, 1);
		nLen++;
	
		if(str[zoneTest] == cChar)
		{
			zoneTest++;
			
			if(str[zoneTest] == '\0')
			{
				// we have found a mark
				return nLen; 
			}
		}
		else
		{
			zoneTest = 0;
		}

	}
	return -1;
}

//--------------------------------------------
// find the mark in the Markset[All the nType][0][]
// the file pointer is set at the next unrelated BYTE in the CFile
// Return:
//	If succeeded, return the nType in the MarkSet, else return -1;
//------------------------------------------------------
int CNotesEditorDoc::FindNextMark(CFile *pFile)
{
	BOOL nRunning = TRUE;
	int zoneTest[TYPE_NUM];
	memset(zoneTest, 0, sizeof(zoneTest));
	
	int nFileLen = pFile->GetLength();
	
	for(int nLen = 0; nLen<nFileLen;)
	{
		char cChar;
		pFile->Read(&cChar, 1);
		nLen++;
		
		for(int i = 0;i < TYPE_NUM; i++)
		{
			if(MarkSet[i][0][zoneTest[i]] == cChar)
			{
				zoneTest[i]++;
				
				if(MarkSet[i][0][zoneTest[i]] == '\0')
				{
					// we have found a mark
					return i; 
				}
			}
			else
			{
				zoneTest[i] = 0;
			}
		}
	};

	// we have reached the end of the file, but still donot find what we want
	return -1;
}

void CNotesEditorDoc::OnProjectParsing() 
{
	// save the file before we start parsing
	if(((CSourceFile*)g_pMainWnd->GetSourceView())->IsModified())
		((CSourceFile*)g_pMainWnd->GetSourceView())->QuickSave();
	// display starting msg
	DisplayMsg(PARSING_START);
	// clear notes
	SafeReleaseList(&m_pNoteList);	
	// generate notes
	int nResult = GenerateNotesList();
	DisplayMsg(nResult);

	// show the result in the free edit window
	((CFreeEdit*)g_pMainWnd->GetFreeView())->ShowItemList();
	if (nResult == PARSING_OK)
		((CTreeNotes*)g_pMainWnd->GetTreeNotesView())->VisualizeAll();
}

void CNotesEditorDoc::DisplayMsg(int nType)
{
	CString str = "Wrong Type";
	if(nType == ERROR_PARSING)
	{
		str = "An Error is detected in the source file\r\n"
			"Parsing cannot proceed.\r\n";
	}
	else if(nType == PARSING_START)
	{
		((CInfoView*)g_pMainWnd->GetInfoView())->ClearAll();
		str = "Start Parsing ... \r\n";
	}
	else if(nType == PARSING_OK)
	{
		str = "File parsed succeesully\r\n";
		// so that we know that parsing has finished
		((CSourceFile*)g_pMainWnd->GetSourceView())->SetParseState(TRUE);
	}
	else if(nType == NO_FILE)
	{
		str = "Please open a source file first. click in the right window, then choose MENU->Project->Open source file\r\n";
	}
	else if(nType == OPERATION_DENIED)
	{
		str = "Operation is denied. Your source file has changed since last parsing. "
			"You may need to parse the source file before performing any operation to the source file.\r\n";
	}
	
	((CInfoView*)g_pMainWnd->GetInfoView())->AddText(str);
	
	g_pMainWnd->PlayAgentMessage(str);
}

//----------------------------------------------
// delete all notes in the source code
//----------------------------------------------
void CNotesEditorDoc::OnSycDelAll() 
{
	if( (((CSourceFile*)g_pMainWnd->GetSourceView())->IsModified()) || 
		!((CSourceFile*)g_pMainWnd->GetSourceView())->IsParsed() )
	{
		// file hasn't been parsed
		DisplayMsg(OPERATION_DENIED);
		return;
	}
	// Modify notes
	CString strSrcPath = ((CSourceFile*)g_pMainWnd->GetSourceView())->GetFilePath();
	CFile file;
	if(file.Open(strSrcPath, CFile::modeRead|CFile::shareDenyNone))
	{
		NoteItem* pItem = m_pNoteList;
		
		// clear the contents in the notes
		while(pItem)
		{
			CmdFormatMe(pItem->m_str);
			
			pItem = pItem->m_pNext;
		}
		
		file.Close();
		// immerge notes to source file
		ImmergeNotesToSrc();
	}
	
}

void CNotesEditorDoc::ImmergeNotesToSrc()
{
	CString strSrcPath = ((CSourceFile*)g_pMainWnd->GetSourceView())->GetFilePath();
	CFile file;
	if(file.Open(strSrcPath, CFile::modeRead|CFile::shareDenyNone))
	{
		NoteItem* pItem = m_pNoteList;
		
		// build outout text
		CString strOutput="";
		while(pItem)
		{
			//---------------------------------------------
			// write text in source from from pItem->m_pPrev->m_nTo to  pItem->m_nFrom
			//---------------------------------------------
			if(pItem->m_pPrev)
			{
				CString str="";
						
				int nSegmentLen = pItem->m_nFrom - pItem->m_pPrev->m_nTo;
				char * strSegment = str.GetBuffer(nSegmentLen+10);
							
				file.Seek(pItem->m_pPrev->m_nTo,CFile::begin);
				file.Read(strSegment, nSegmentLen);
				
				strSegment[nSegmentLen]= '\0'; 
				
				str.ReleaseBuffer();
				strOutput +=str;
			}
			else 
			{
				if(pItem->m_nFrom == 0)
				{
				}
				else
				{
					CString str="";
						
					int nSegmentLen = pItem->m_nFrom - 0;
					char * strSegment = str.GetBuffer(nSegmentLen+10);
								
					file.Seek(0,CFile::begin);
					file.Read(strSegment, nSegmentLen);
					
					strSegment[nSegmentLen]= '\0'; 
					
					str.ReleaseBuffer();
					strOutput += str;
				}
			}
			//---------------------------------------------
			// write text in source from pItem->m_nFrom to  pItem->m_nTo
			//---------------------------------------------
			{
				strOutput += pItem->m_str;
			}
			//---------------------------------------------
			// write text in source to the end
			//---------------------------------------------
			if(!pItem->m_pNext)
			{
				// this is the last element
				CString str="";
						
				int nSegmentLen = file.GetLength() - pItem->m_nTo;
				char * strSegment = str.GetBuffer(nSegmentLen+10);
							
				file.Seek(-nSegmentLen, CFile::end);
				file.Read(strSegment, nSegmentLen);
				
				strSegment[nSegmentLen]= '\0'; 
				
				str.ReleaseBuffer();
				strOutput += str;
			}

			pItem = pItem->m_pNext;
	
		}
		((CSourceFile*)g_pMainWnd->GetSourceView())->SetWindowText(strOutput);
	}	
}

void CNotesEditorDoc::OnDoCmd() 
{
	if( (((CSourceFile*)g_pMainWnd->GetSourceView())->IsModified()) || 
		!((CSourceFile*)g_pMainWnd->GetSourceView())->IsParsed() )
	{
		// file hasn't been parsed
		DisplayMsg(OPERATION_DENIED);
		return;
	}

	// Modify notes
	CString strSrcPath = ((CSourceFile*)g_pMainWnd->GetSourceView())->GetFilePath();
	CFile file;
	if(file.Open(strSrcPath, CFile::modeRead|CFile::shareDenyNone))
	{
		NoteItem* pItem = m_pNoteList;
		
		while(pItem)
		{
			DoCmd(GetCmd(pItem->m_str), pItem->m_str);
			
			pItem = pItem->m_pNext;
		}
		
		file.Close();
		// immerge notes to source file
		ImmergeNotesToSrc();
	}
		
}

void CNotesEditorDoc::CmdFormatMe(CString &cmd)
{
	int nLen = cmd.GetLength();
	int nLast = nLen;
	int nCounter = 0;
	int nFirst = nLen;
	int j=-2;
	while( (j = cmd.Find("\r\n", j+2)) != -1 )
	{
		nCounter++;
		if(nCounter == 1)
			nFirst = j;
		nLast = j;
	}
	
	// we will delete the string between nFirst and nLast, where replacing the outsider with ' '(space holder)
	CString str = "";
	str += cmd.Left(nFirst);
	str += cmd.Right(nLen - nLast);
	nLen = str.GetLength();
	for(int i = 0; i<nLen; i++)
	{
		if(str[i] != '\r' && str[i] != '\n')
			str.SetAt(i, ' ');
	}
	cmd = str;
}

CString CNotesEditorDoc::GetCmd(CString& str)
{
	//------------------------------------------
	// Get Short cmd just the first 3 char
	//------------------------------------------
	CString strCmd = str.Left(3);
	if((strCmd[2] == 'M') || (strCmd[2] == 'm'))
	{
		// clear the contents in the notes
		return _T("Format me");
	}
	else if (strCmd == "///")
	{
		// pay special attention to this
		return _T("HTML");
	}
	else if (strCmd == "/*/")
	{
		// Change style from /* to //
		return _T("To //");
	}
	
	// TODO:
	return _T("");
	
	//------------------------------------------
	// TODO: get one line cmd
	//------------------------------------------
	int nLen = str.GetLength();
	for(int i=0; i<nLen;i++)
	{
		if(str[i] == '\r')
			break;
	}
	// now strCmd contains the first line in the str where the cmd may reside
	strCmd = str.Left(i);
	

	// no cmd appears in this line
	return _T("");
}

void CNotesEditorDoc::DoCmd(LPCTSTR cCmd, CString &strResult)
{
	CString cmd = cCmd;
	if (cmd == "")
	{
		return;
	}
	else if (cmd == _T("Format me"))
	{
		CmdFormatMe(strResult);
	}
	else if (cmd == _T("HTML"))
	{
		
	}
	else if (cmd == _T("To //"))
	{
		
	}

	return;	
	
}

#if !defined(AFX_TREENOTES_H__16086688_1620_41D8_882D_1C8ADBACEFF4__INCLUDED_)
#define AFX_TREENOTES_H__16086688_1620_41D8_882D_1C8ADBACEFF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TreeNotes.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTreeNotes view
#include <afxcview.h>

class CTreeNotes : public CTreeView
{
protected:
	CTreeNotes();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CTreeNotes)

// Attributes
public:
	CImageList m_bmpTreeNodes;
// Operations
public:
	int GetImageIndex(int nLayer);
	void VisualizeAll();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTreeNotes)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CTreeNotes();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CTreeNotes)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TREENOTES_H__16086688_1620_41D8_882D_1C8ADBACEFF4__INCLUDED_)

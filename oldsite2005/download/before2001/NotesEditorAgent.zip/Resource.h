//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NotesEditor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_NOTESETYPE                  129
#define IDB_TREENODES                   130
#define ID_PROJECT_PARSING              32771
#define ID_PROJECT_SHOWALL              32772
#define ID_PROJECT_SHOW_LAYER           32773
#define ID_SYC_DEL_ALL                  32774
#define ID_SYC_EDIT_NOTE                32775
#define ID_PROJECT_OPEN_SRC             32776
#define ID_PROJECT_SAVE_SRC             32777
#define ID_PROJECT_SAVEAS_SRC           32778
#define ID_PROJECT_OPEN_SEL             32779
#define ID_PROJECT_TREENOTES            32780
#define ID_SYCHO_DO_CMD                 32781
#define ID_AGENT_SHOW                   32782
#define ID_AGENT_INTRO                  32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

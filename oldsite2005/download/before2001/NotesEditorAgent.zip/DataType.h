#ifndef DATA_TYPE_2001
#define DATA_TYPE_2001

struct NoteItem
{
public:
	// type of the notes
	BYTE m_type;
	// in what layer, starting from 0(root)
	int m_nLayer;
	// type of operation
	BYTE m_nOperation;
	// the position in the corresponding file
	LONG m_nFrom, m_nTo;
	// the content of the note
	CString m_str;

	// maintaining a one direction list
	NoteItem* m_pPrev;
	NoteItem* m_pNext;
};

typedef NoteItem*	NoteList;

#define MAX_LEN	10
extern TCHAR MarkSet[][2][MAX_LEN];

#endif


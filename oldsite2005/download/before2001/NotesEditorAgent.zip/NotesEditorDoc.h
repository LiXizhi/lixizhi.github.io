// NotesEditorDoc.h : interface of the CNotesEditorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_NOTESEDITORDOC_H__2139BD92_0B13_40E4_AD41_172E2003BAC9__INCLUDED_)
#define AFX_NOTESEDITORDOC_H__2139BD92_0B13_40E4_AD41_172E2003BAC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "datatype.h"

class CNotesEditorDoc : public CDocument
{
protected: // create from serialization only
	CNotesEditorDoc();
	DECLARE_DYNCREATE(CNotesEditorDoc)

// Attributes
public:

// Operations
public:
	void AddToList(NoteItem *pObject, NoteList *pList);
	void AddToTail(NoteItem *pObject, NoteList *pList);
	void DeleteFromList(NoteItem *pObject, NoteList *pList);
	void SafeReleaseList(NoteList *pList);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNotesEditorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	void DoCmd(LPCTSTR cmd, CString& strResult);
	CString GetCmd(CString& str);
	void CmdFormatMe(CString &cmd);
	void ImmergeNotesToSrc();
	void DisplayMsg(int nType);
	int m_nBytePerChar;
	int FindNextMark(CFile* pFile);
	int FindMark(CFile *pFile, LPCTSTR str);
	int FindPairMark(CFile* pFile, int nType);
	NoteList m_pNoteList;
	int GenerateNotesList();
	void SortList();
	virtual ~CNotesEditorDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CNotesEditorDoc)
	afx_msg void OnProjectParsing();
	afx_msg void OnSycDelAll();
	afx_msg void OnProjectSaveSrc();
	afx_msg void OnProjectSaveasSrc();
	afx_msg void OnProjectOpenSrc();
	afx_msg void OnDoCmd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NOTESEDITORDOC_H__2139BD92_0B13_40E4_AD41_172E2003BAC9__INCLUDED_)

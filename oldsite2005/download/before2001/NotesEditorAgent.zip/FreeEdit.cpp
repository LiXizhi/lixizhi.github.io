// FreeEdit.cpp : implementation file
//

#include "stdafx.h"
#include "NotesEditor.h"
#include "MainFrm.h"

#include "FreeEdit.h"
#include "NotesEditorDoc.h"
#include "SourceFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMainFrame* g_pMainWnd;

/////////////////////////////////////////////////////////////////////////////
// CFreeEdit

IMPLEMENT_DYNCREATE(CFreeEdit, CEditView)

CFreeEdit::CFreeEdit()
{
}

CFreeEdit::~CFreeEdit()
{
}


BEGIN_MESSAGE_MAP(CFreeEdit, CEditView)
	//{{AFX_MSG_MAP(CFreeEdit)
	ON_COMMAND(ID_PROJECT_OPEN_SEL, OnProjectOpenSel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFreeEdit drawing

void CFreeEdit::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CFreeEdit diagnostics

#ifdef _DEBUG
void CFreeEdit::AssertValid() const
{
	CEditView::AssertValid();
}

void CFreeEdit::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFreeEdit message handlers

void CFreeEdit::GetFilePath(CString &str)
{
	// TODO: Get the being- processed file in the CDocument

}

//--------------------------------------------------
// Visualize the data in Document
//--------------------------------------------------
void CFreeEdit::ShowItemList(int nFrom, int nTo)
{
	// TODO:
	CNotesEditorDoc* pDoc = ((CNotesEditorDoc*)GetDocument());
	ASSERT(pDoc);

	CString strOutput = "";
	NoteItem* pItem = pDoc->m_pNoteList;
	
	// build outout text
	while(pItem)
	{
		strOutput += pItem->m_str;
		if(strOutput.Right(2) != "\r\n")
			strOutput += "\r\n";

		pItem = pItem->m_pNext;
	}

	SetWindowText(strOutput);
}


void CFreeEdit::ClearAll()
{
	SetWindowText(NULL);
}

void CFreeEdit::OnProjectOpenSel() 
{
	CString strPath;
	GetSelectedText(strPath);
	
	((CSourceFile*)g_pMainWnd->GetSourceView())->ReLoad(strPath);
}

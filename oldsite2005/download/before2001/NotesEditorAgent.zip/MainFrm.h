// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__45D7EB39_E4F8_4DF1_96A9_DC1F39A4581B__INCLUDED_)
#define AFX_MAINFRM_H__45D7EB39_E4F8_4DF1_96A9_DC1F39A4581B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "agentctlex.h"

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	void PlayAgentMessage(LPCTSTR msg);
	void ShowAgentAnyWay();
	CAgentCtlEx m_Agent;
	CView* GetTreeNotesView();
	CView* GetInfoView();
	CView* GetSourceView();
	CView* GetFreeView();
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	CSplitterWnd m_wndSplitterMain;
	CSplitterWnd m_wndSplitterRight;
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnAgentShow();
	afx_msg void OnUpdateAgentShow(CCmdUI* pCmdUI);
	afx_msg void OnAgentIntro();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__45D7EB39_E4F8_4DF1_96A9_DC1F39A4581B__INCLUDED_)

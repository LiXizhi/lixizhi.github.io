#if !defined(AFX_DLGTERRAINEDIT_H__790D2014_6764_45D8_A489_B79F5F676C84__INCLUDED_)
#define AFX_DLGTERRAINEDIT_H__790D2014_6764_45D8_A489_B79F5F676C84__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgTerrainEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgTerrainEdit dialog
class CTerrain;
class CDlgTerrainEdit : public CDialog
{
// Construction
public:
	BOOL IsModified();
	BOOL m_bIsModified;
	CTerrain* m_pTerrain;
	CString m_strSearchPath;
	CDlgTerrainEdit(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgTerrainEdit)
	enum { IDD = IDD_TERRAIN_EDIT };
	CString	m_strTerrainName;
	float	m_fLength;
	float	m_fMaxHeight;
	int		m_nSegment;
	float	m_fWidth;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgTerrainEdit)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgTerrainEdit)
	afx_msg void OnLoad();
	virtual void OnOK();
	afx_msg void OnCreateRandom();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGTERRAINEDIT_H__790D2014_6764_45D8_A489_B79F5F676C84__INCLUDED_)

// Terrain.h: interface for the CTerrain class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TERRAIN_H__1907047A_AE2D_4FC7_B2C8_3F2386088D2A__INCLUDED_)
#define AFX_TERRAIN_H__1907047A_AE2D_4FC7_B2C8_3F2386088D2A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Lines that separate segments, 
// also including information about the next ajacent segment
struct LINE
{
	float fY; // segment length
	float fHeight; // Height of the line
	DWORD dwColor; // color of the segment
};

class CTerrain  
{
public:
	CTerrain();
	virtual ~CTerrain();

public:
	LINE* m_pData; // a list of LINE represents the terrain
	
	// terrain size
	float m_fLength;
	float m_fWidth;

	int m_nSegment; // number of segments
	float m_fMaxHeight; // the maximum height of the terrain
	float m_fMinSegLength; // the minimum length of one segment
	float m_fRadius; // the radius of the turning between segments(usually 2.0 cm)
public:
	float GetSegmentSlope(int nSegment);
	float LowerHeight(int i);
	float GetHeightFromY(float fPosY);
	float GetSlope(float fPosY);
	int GetSegmentFromY(float fPosY);
	//float GetSlope(int nSegment);
	void GetLookingAngle(float fPosY, float * pAngle);
	void GetLookingAngle(int nIndex, float fPosRY, float * pAngle);
	HRESULT LoadTerrain(LPCTSTR pPath);
	HRESULT SaveTerrain(LPCTSTR pPath);
	HRESULT CreateRandomTerrain();


};

#endif // !defined(AFX_TERRAIN_H__1907047A_AE2D_4FC7_B2C8_3F2386088D2A__INCLUDED_)

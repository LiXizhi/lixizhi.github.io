#if !defined(AFX_DLGD3DPROPERTIES_H__69281BBF_4231_4CD2_A6E8_6B58E07ED9B8__INCLUDED_)
#define AFX_DLGD3DPROPERTIES_H__69281BBF_4231_4CD2_A6E8_6B58E07ED9B8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgD3DProperties.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgD3DProperties dialog
class CD3DApplication;

class CDlgD3DProperties : public CDialog
{
// Construction
public:
	CD3DApplication* m_pD3dWnd;
	CDlgD3DProperties(CD3DApplication* pD3dWnd, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgD3DProperties)
	enum { IDD = IDD_DLG_D3D_PROPERTIES };
	BOOL	m_bZbuffer;
	int		m_nDevice;
	DWORD	m_dwHeight;
	DWORD	m_dwWidth;
	BOOL	m_bIsFullScreen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgD3DProperties)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgD3DProperties)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGD3DPROPERTIES_H__69281BBF_4231_4CD2_A6E8_6B58E07ED9B8__INCLUDED_)

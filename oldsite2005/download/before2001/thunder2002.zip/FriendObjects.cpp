// FriendObjects.cpp: implementation of the CEnemyTrack class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Thunder.h"

#include "ThunderView.h"

#include "friendobjects.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEnemyTrack::CEnemyTrack(CThunderView* pView)
{
	m_pView = pView;
}

CEnemyTrack::~CEnemyTrack()
{

}

// universal job is done before execute this
void CEnemyTrack::GenerateMark(CBaseObject *pObject)
{
	// generate nearX, nearY accroding to missile
	CBaseObject* pMissile = m_pView->m_pMissileList;

	// always store the nearest distance between the scanned missiles and the plane
	float MINX = 3.0f, MINY = 3.0f; // the initials are checking limits
	float nearX = MINX, nearY = -MINY; 
	while( pMissile )
	{
		if( ((CMissile*)pMissile)->m_nManufactory == USER )
		{
			D3DXVECTOR3 rv = pMissile->m_vPos - pObject->m_vPos;
			if ((float)sqrt(rv.x*rv.x + rv.y*rv.y + rv.z*rv.z) < 
				(pObject->m_fSize+pMissile->m_fSize) )
			{
				// condition 2: overlapped with a user missile, so delete them both
				m_pView->HitMarks(pObject, pMissile);
				
			}
			else if(rv.y<0.0f && rv.y>nearY && fabs(rv.x)<nearX)
			{
				nearX = rv.x;
				nearY = rv.y;
			}
		}
		
		pMissile = pMissile->m_pNext;
	}
				
	// store the old status, to be used for inertial movement later
	DWORD bIsMovingLeft = GET_MARK(pObject->m_dwMark, MARK_LEFT);
	DWORD bIsMovingForward = GET_MARK(pObject->m_dwMark, MARK_FORWARD);
	// Clear the movement marks , for we will generate new ones
	pObject->m_dwMark = CLEAR_PLANEMARK(pObject->m_dwMark);

	// move the enemy
	
	// generating X movement
	// 1. avoid user missile
	if((0.0f<nearX) && (nearX< MINX) ) 
	{
		pObject->m_dwMark |= MARK_RIGHT;
	}
	else if( (nearX <= 0.0f) && (-MINX < nearX) )
	{
		pObject->m_dwMark |= MARK_LEFT;
	}
	else
	// 2. avoid other planes
	{
		// regenerate nearX, nearY accroding to other planes
		CBaseObject* pPlane = m_pView->m_pEnemyList;

		// always store the nearest distance between the scanned other planes and the plane
		if(pPlane)
			MINX = pPlane->m_fSize*2;  // assume that all planes are of a size
		else
			MINX = 1.0f;
		MINY = MINX;
		nearX = MINX;
		nearY = -MINY; 
		while( pPlane )
		{
			if( pPlane != pObject)
			{
				// we are now comparing with ourselves
				D3DXVECTOR3 rv = pPlane->m_vPos - pObject->m_vPos;
				if(rv.y<(-nearY) && rv.y>nearY && fabs(rv.x)<nearX)
				{
					nearX = rv.x;
					nearY = rv.y;
				}
			}
			
			pPlane = pPlane->m_pNext;
		}

		// avoid if nessesary
		if((0.0f<nearX) && (nearX< MINX) ) 
		{
			pObject->m_dwMark |= MARK_RIGHT;
		}
		else if( (nearX <= 0.0f) && (-MINX < nearX) )
		{
			pObject->m_dwMark |= MARK_LEFT;
		}
		else
		{
			// 3. we need to avoid neither missiles, nor planes, so we apply 
			// inertial movement, if within boarder.
			if(0.0f > pObject->m_vPos.x)
			{
				pObject->m_dwMark |= MARK_LEFT;
			}
			else if(pObject->m_vPos.x > m_pView->m_terrain.m_fWidth)
			{
				pObject->m_dwMark |= MARK_RIGHT;
			}
			else
			{
				// inertial movement
				if(bIsMovingLeft)
				{
					pObject->m_dwMark |= MARK_LEFT;
				}
				else
				{
					pObject->m_dwMark |= MARK_RIGHT;
				}
			}
		}
	}

	// generating Y movement
	
	// relative pos
	D3DXVECTOR3 rPos = m_pView->m_pPlane->m_vPos - pObject->m_vPos;
	
	if( (-(2*MINY)>rPos.y) && (rPos.y>-(7*MINY)) )
	{
		// 1. if within a fair distance, apply inertial movement
		if(bIsMovingForward)
		{
			pObject->m_dwMark |= MARK_FORWARD;
		}
		else
		{
			pObject->m_dwMark |= MARK_BACKWARD;
		}
		
		// fire missile anyway
		pObject->m_dwMark |= MARK_FIRE;


	}
	else
	{
		// trun off fire
		//pObject->m_dwMark &= (^MARK_FIRE);
		if(rPos.y>=-(2*MINY))
		{
			pObject->m_dwMark |= MARK_BACKWARD;
		}
		else
		{
			pObject->m_dwMark |= MARK_FORWARD;
		}
	}

}

void CEnemyTrack::ApplyMark(CBaseObject *pObject)
{

}

//////////////////////////////////////////////////////////////////////
// CMissileTrack Class
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// this can only be used or user plane
CMissileTrack::CMissileTrack(CThunderView* pView)
		: CEnemyTrack(pView)
{

}

CMissileTrack::~CMissileTrack()
{

}

void CMissileTrack::GenerateMark(CBaseObject *pObject)
{
	
}

void CMissileTrack::ApplyMark(CBaseObject *pObject)
{
	// reset the target
	/* set to every plane
	CBaseObject* pPlane = m_pView->m_pEnemyList;

	static int nTarget = 0; // the target plane index to track to
	int nCount=0;
	while( pPlane )
	{
		if(nCount == nTarget)
		{
			((CMissile*)pObject)->m_vTarget = pPlane->m_vPos;
			break;
		}
		pPlane = pPlane->m_pNext;
		nCount++;
	}
	if(nCount < nTarget)
	{
		// if there isn't a target in the list, we will srt the target to the first one
		nTarget =0;
	}
	else
	{
		nTarget++;
	}
*/
	// 2. set only to the first plane
	if(m_pView->m_pEnemyList)
	{
		((CMissile*)pObject)->m_vTarget = m_pView->m_pEnemyList->m_vPos;
	}

	// move the missile towards the target at a constant velocity
	
	float rx = ( ((CMissile*)pObject)->m_vTarget.x - ((CMissile*)pObject)->m_vPos.x );
	float ry = ( ((CMissile*)pObject)->m_vTarget.y - ((CMissile*)pObject)->m_vPos.y ); 
	float rs = (float)sqrt(rx*rx + ry*ry);
	
	/*
	// set the m_fTransition to 1.0 when missile has nearly reached its target
	// so we can delete the missile later in the mark generating funtion
	if(rs < ((CMissile*)pObject)->m_fVel) 
		((CMissile*)pObject)->m_fTransition = 1.0f;
	*/

	pObject->m_vPos.x += (rx/rs) * pObject->m_fVel;
	pObject->m_vPos.y += (ry/rs) * pObject->m_fVel;
	
	((CMissile*)pObject)->m_fTransition += (((CMissile*)pObject)->m_fVel/((CMissile*)pObject)->m_fRange);

	// Set the object on its 3d terrain 
	m_pView->Set3DPositionOf(pObject);
}

//////////////////////////////////////////////////////////////////////
// CExplosion Class
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CExplosion::CExplosion(CThunderView* pView)
		: CEnemyTrack(pView)
{

}

CExplosion::~CExplosion()
{

}

void CExplosion::GenerateMark(CBaseObject *pObject)
{
	if( ((CMissile*)pObject)->m_fTransition >= 1.0f )
	{
		pObject->m_dwMark = MARK_DEAD;
	}
}

void CExplosion::ApplyMark(CBaseObject *pObject)
{
	((CMissile*)pObject)->m_fTransition += 1.0f / EXPLOSION_FRAMES;
}


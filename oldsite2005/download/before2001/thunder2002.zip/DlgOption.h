#if !defined(AFX_DLGOPTION_H__92B61F5B_F82F_4642_BD54_D9F6B129BE54__INCLUDED_)
#define AFX_DLGOPTION_H__92B61F5B_F82F_4642_BD54_D9F6B129BE54__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgOption.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgOption dialog

class CDlgOption : public CDialog
{
// Construction
public:
	CDlgOption(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgOption)
	enum { IDD = IDD_OPTIONS };
	CString	m_strMissile;
	CString	m_strParentPath;
	CString	m_strTerrain;
	float	m_fFPS;
	BOOL	m_bUnLimitedSpeed;
	BOOL	m_bAutoCamera;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgOption)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgOption)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGOPTION_H__92B61F5B_F82F_4642_BD54_D9F6B129BE54__INCLUDED_)

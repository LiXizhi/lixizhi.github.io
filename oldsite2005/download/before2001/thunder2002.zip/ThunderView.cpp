// ThunderView.cpp : implementation of the CThunderView class
//

#include "stdafx.h"
#include "Thunder.h"

#include "ThunderDoc.h"
#include "ThunderView.h"

#include "DlgD3DProperties.h"
#include "friendobjects.h"
#include "DlgOption.h"
#include "DlgTerrainEdit.h"

#include <dmusici.h>
#include "D3DFile.h"
#include "dxutil.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// FORMAT_TEXT is only used within this source code
#ifdef UNICODE
#define FORMAT_TEXT swprintf
#else
#define FORMAT_TEXT sprintf
#endif

LRESULT CALLBACK FullScreenWndProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam );
CThunderView*     g_AppView = NULL;


#define TIMER_THUNDER	777
const int msil_num = 4;
// rows and colums in the texture(the texture is devided into segments)
const int nCol = 5;
const int nRow = 2;
		
/*
TCHAR*               CThunderView::m_strShipFiles[]    = { _T("Concept Plane 3.x"), _T("Spaceship 2.x"), _T("Shusui.x"),
												 _T("Space Station 7.x"), _T("Spaceship 8.x"), _T("Orbiter.x"),
												 _T("Spaceship 13.x"),    _T("Spaceship 5.x"), _T("Star Sail.x"), 
												 _T("Heli.x"), };
												 
TCHAR*               CThunderView::m_strShipNames[]    = { _T("Concept Plane"), _T("Green Machine"),  _T("Purple Prowler"),
											 _T("Drone Clone"),   _T("Canyon Fighter"), _T("Roundabout"),
											 _T("Tie-X7"),        _T("Gunner"),         _T("Star Sail"), 
											 _T("Helicopter"), };
											 */
TCHAR*               CThunderView::m_strShipFiles[]    = { _T("Concept Plane 3.x"), _T("Spaceship 2.x"),
												 _T("Space Station 7.x"), _T("Spaceship 8.x"), _T("Orbiter.x"),
												 _T("Spaceship 13.x"),    _T("Spaceship 5.x"), _T("Shusui.x"), };

// for renference of sound segment
WCHAR*               CThunderView::m_strSoundFiles[] = 
{L"sengine.wav", L"c_bang.wav", L"gunfire.wav", 
 L"bangbang.wav", L"bounce.wav", L"sengine.wav", };/*mc000.mp3*/
enum{SOUND_SONG = 0, SOUND_FIRE_SINGLE, SOUND_FIRE_DOUBLE, 
	SOUND_BOMB, SOUND_BOUNCE, SOUND_ENGINE};
#define END_SOUND	(SOUND_ENGINE-1) 
//SHIELDBUZZ, SHIPEXPLODE, GUNFIRE,
//	SHIPBOUNCE, DONUTEXPLODE, PYRAMIDEXPLODE, CUBEEXPLODE, SPHEREEXPLODE, END_SOUND};

#define D3D_FAILED	-1

/////////////////////////////////////////////////////////////////////////////
// CThunderView

IMPLEMENT_DYNCREATE(CThunderView, CView)

BEGIN_MESSAGE_MAP(CThunderView, CView)
	//{{AFX_MSG_MAP(CThunderView)
	ON_COMMAND(ID_GAME_BEGIN, OnGameBegin)
	ON_COMMAND(ID_GAME_PAUSE, OnGamePause)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_COMMAND(ID_GAME_OPTION, OnGameOption)
	ON_COMMAND(ID_GAME_TERRAINEDIT, OnGameTerrainedit)
	ON_COMMAND(ID_GAME_EDITMAP, OnGameEditmap)
	ON_COMMAND(ID_GAME_DEVICE, OnGameDevice)
	ON_COMMAND(ID_GAME_TOGGLE_VIEW, OnGameToggleView)
	ON_WM_SIZE()
	ON_COMMAND(ID_APP_EXIT, OnAppExit)
	ON_WM_KEYUP()
	ON_COMMAND(ID_HELP_INSTRUCTIONS, OnHelpInstructions)
	ON_COMMAND(ID_BONUS_NEXT, OnBonusNext)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CThunderView construction/destruction

CThunderView::CThunderView()
{
	m_pFont                  = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
	m_nScore = 0;
	m_bAutoCamera = TRUE;

	m_dwNumShipTypes = sizeof(m_strShipFiles)/sizeof(TCHAR*);
	// TODO: add construction code here
	for(int i=0; i < (int)m_dwNumShipTypes; i++)
	{
		m_pPlaneMesh[i] = NULL;
	}
	
	m_pMissileBuffer = NULL;
	m_pTerrainBuffer = NULL;
	m_pTexture1 = NULL;
	m_pTexture2 = NULL;
	
	m_fViewSpeed = 0.02f;

	m_fCurrentLinePos = 10.0f;
	m_fMovementRange = 10.0f;
	m_nVisibleSegmentNum = 4;

	m_strMissile = _T("missile.tga");
	m_strTerrain = _T("Terrain.bmp");
	
	GetCurrentDirectory(100, m_strSearchPath.GetBuffer(100));//_T("c:\\lxzsrc\\Thunder\\Media");
	m_strSearchPath.ReleaseBuffer();

	m_nGameState = GAME_UNINITIALIZED;
	m_hwndRenderFullScreen = NULL;
	g_AppView = this;
	m_fFPS = 30.0f;
	m_fMyFPS = 30.0f;
	m_bUseDepthBuffer   = TRUE;
	m_bWindowed = TRUE;

	m_pPlane = NULL;
	m_pEnemyList = NULL;
	m_pMissileList = NULL;
	
	m_lpDI = NULL;
	m_pPerformance = NULL;
	
	m_nFlashStatus = FLASH_UNINITIALIZED;

	// encode flash files
	EncodeFlashFile();
	//decode the flash files
	DecodeFlashFile();
}

CThunderView::~CThunderView()
{
	// encode flash files
	EncodeFlashFile();
}

BOOL CThunderView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CThunderView drawing

void CThunderView::OnDraw(CDC* pDC)
{
	CThunderDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if(!m_bReady)
	{
		pDC->TextOut(10, 10, _T("Use the arrow key to nevigate your plane"));
		pDC->TextOut(10, 30, _T("Use SPACE to fire")); 
		pDC->TextOut(10, 50, _T("Use A W D X Z to change the camera"));
		pDC->TextOut(10, 70, _T("press TAB key to change your plane model"));
		pDC->TextOut(10, 90, _T("use 1 2 3 4 to change weapon"));
		
		pDC->TextOut(10, 110, _T("you plane is only movable within an invisible region"));

	}
	else
	{
		// render the scene
		TryRender();
	}
}

/////////////////////////////////////////////////////////////////////////////
// CThunderView diagnostics

#ifdef _DEBUG
void CThunderView::AssertValid() const
{
	CView::AssertValid();
}

void CThunderView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CThunderDoc* CThunderView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CThunderDoc)));
	return (CThunderDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CThunderView message handlers
void CThunderView::AddToList(CBaseObject *pObject, CBaseObject **pList)
{
	if((*pList) == NULL)
	{
		(*pList) = pObject;
		pObject->m_pPrev = NULL;
		pObject->m_pNext = NULL;

		return;
	}

	pObject->m_pNext = (*pList)->m_pNext;
    pObject->m_pPrev = (*pList);

    if( (*pList)->m_pNext )
        (*pList)->m_pNext->m_pPrev = pObject;
    (*pList)->m_pNext = pObject;
}

// this is a static function
void CThunderView::DeleteFromList(CBaseObject *pObject, CBaseObject **pList)
{
	if( pObject->m_pNext )
        pObject->m_pNext->m_pPrev = pObject->m_pPrev;
    if( pObject->m_pPrev )
        pObject->m_pPrev->m_pNext = pObject->m_pNext;
    // point the list to a new header, if the header is being deleted 
	if((*pList) == pObject)
		(*pList) = pObject->m_pNext;
	delete( pObject );
}

void CThunderView::OnGameBegin() 
{
	if(m_nGameState != GAME_UNINITIALIZED)
	{
		if(!m_bReady)
		{
			/*
			// New a game
			if(FAILED(LoadGameObjects()))
				return;
			*/
			

			// restart anyway to initialize the parameters
			Restart();
		}
		else
		{
			// restart the current game
			Restart();
		}
		
		ResumeGame();
	}
}

/*
void CThunderView::OnGameClose() 
{
	PauseGame();
	//UnloadGameObjects();
	m_nGameState = GAME_UNINITIALIZED;
	InvalidateRect(NULL);
	UpdateWindow();
	
}
*/

void CThunderView::OnGamePause() 
{
	// TODO: Add your command handler code here
	if(m_nGameState == GAME_PAUSED)
	{
		ResumeGame();
	}
	else if(m_nGameState == GAME_RUNNING)
	{
		PauseGame();
	}	
}

// This function has been abandoned 
HRESULT CThunderView::LoadGameObjects()
{
	HRESULT hr = S_OK;
	
	/*
	// 0. launch a dialog to retrieve the values for d3d device
	CDlgD3DProperties dlg(this, this);
	dlg.DoModal();

	// 1. Create d3d object
	if ( FAILED(CreateD3D(GetSafeHwnd())) )
		return E_FAIL;
	*/
    // 2. Initialize the DirectAudio stuff
	
	// I donot know why the directx doesnot offer a none COM style in Direct Audio
	CoInitialize(NULL);
    
    
	CoCreateInstance(CLSID_DirectMusicLoader, NULL, 
                     CLSCTX_INPROC, IID_IDirectMusicLoader8,
                     (void**)&m_pLoader);
	
	CoCreateInstance(CLSID_DirectMusicPerformance, NULL,
                     CLSCTX_INPROC, IID_IDirectMusicPerformance8,
                     (void**)&m_pPerformance );
	m_pPerformance->InitAudio( 
        NULL,                  // IDirectMusic interface not needed.
        NULL,                  // IDirectSound interface not needed.
        NULL,                  // Window handle.
        DMUS_APATH_SHARED_STEREOPLUSREVERB,  // Default audiopath type.
        64,                    // Number of performance channels.
        DMUS_AUDIOF_ALL,       // Features on synthesizer.
        NULL                   // Audio parameters; use defaults.
    );

	// CONVERT to WCHAR
	CString str = m_strSearchPath + _T("\\media");
	WCHAR strSearchPath[100];	
	MultiByteToWideChar( CP_ACP, 0, (LPCTSTR)str, -1, 
                         strSearchPath, str.GetLength() );
    strSearchPath[str.GetLength()] = 0;


	m_pLoader->SetSearchDirectory( 
        GUID_DirectMusicAllTypes,   // Types of files sought.
        strSearchPath,             // Where to look.
        FALSE                       // Don't clear object data.
    );
	
	for(int i=0; i<END_SOUND; i++)
	{
		if (FAILED(m_pLoader->LoadObjectFromFile(
			CLSID_DirectMusicSegment,   // Class identifier.
			IID_IDirectMusicSegment8,   // ID of desired interface.
			m_strSoundFiles[i],               // Filename.
			(LPVOID*) &m_pSegment[i])))       // Pointer that receives interface.
		{
			::MessageBox( NULL, _T("Media not found, sample will now quit."), 
							  _T("TS"), MB_OK );
			return D3D_FAILED;
		}
		m_pSegment[i]->Download( m_pPerformance );

	}
	//PlaySound(BEGINLEVEL); // try one of the sound here
	
    // 3. Initialize the DirectInput stuff
	 
	if FAILED(DirectInput8Create(AfxGetInstanceHandle(), DIRECTINPUT_VERSION, 
			IID_IDirectInput8, (void**)&m_lpDI, NULL)) 
	{ 
		// DirectInput not available; take appropriate action 
		return D3D_FAILED;
	} 

	if FAILED(m_lpDI->CreateDevice(GUID_SysKeyboard, &m_lpDIDevice, NULL)) 
	{ 
		return D3D_FAILED; 
	} 

	if FAILED(m_lpDIDevice->SetDataFormat(&c_dfDIKeyboard)) 
	{ 
		return D3D_FAILED; 
	} 
	// Set the cooperative level 
	hr = m_lpDIDevice->SetCooperativeLevel(GetSafeHwnd(), 
					   DISCL_FOREGROUND | DISCL_NONEXCLUSIVE); 
 
	if FAILED(hr) { 
		// we take no notice of the return value in this simple game
		//return D3D_FAILED; 
	} 
	
	if (m_lpDIDevice) m_lpDIDevice->Acquire(); 
    
	// 4.1 Load texture from file
	CString path =  m_strSearchPath + _T("\\Media\\") + m_strMissile;
	
	if( FAILED( D3DXCreateTextureFromFile( m_pd3dDevice, path.GetBuffer(100),
                                       &m_pTexture1 ) ) )
		return E_FAIL;
	path.ReleaseBuffer();

	//D3DUtil_SetColorKey(m_pTexture1, 0x00000000);

	path =  m_strSearchPath + _T("\\Media\\") + m_strTerrain;
	if( FAILED( D3DXCreateTextureFromFile( m_pd3dDevice, path.GetBuffer(100),
                                       &m_pTexture2 ) ) )
		return E_FAIL;
	path.ReleaseBuffer();

	// 4.2 load user's plane 

	ReloadPlane();

	// set plane original point
	
	m_pPlane = new CPlane();
	m_pPlane->m_vPos = D3DXVECTOR3(10.0f, 1.0f, - 1.0f);
	m_pPlane->m_dwType = PLANE_USER;
	// set a directional light
	D3DXVECTOR3 vecDir;
	D3DLIGHT8 light;
	ZeroMemory( &light, sizeof(D3DLIGHT8) );
	light.Type       = D3DLIGHT_DIRECTIONAL;

	light.Diffuse.r  = 1.0f;
	light.Diffuse.g  = 1.0f;
	light.Diffuse.b  = 1.0f;

	vecDir = D3DXVECTOR3(1.0f, -1.0f, 1.0f);
	D3DXVec3Normalize( (D3DXVECTOR3*)&light.Direction, &vecDir );
	light.Range       = 1000.0f;
	hr = m_pd3dDevice->SetLight( 0, &light );
    m_pd3dDevice->LightEnable( 0, TRUE );
	if FAILED(hr) { 
		// we take no notice of the return value in this simple game
		return D3D_FAILED; 
	} 
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x33333333 );
	m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

	// init camera
	m_Camera.vPos = D3DXVECTOR3(10.0f, 1.0f, -35.0f);
	
	// 5. load enemy's plane
	m_pEnemyList = NULL;

	// 6. load terrian
	
	if(!m_terrain.m_pData)
	{
		m_terrain.CreateRandomTerrain();
	}
	
	m_pTerrainBuffer = new TEXTVERTEX[(m_terrain.m_nSegment+1)*2];
	
	// there is #(m_nSegment+1)# lines
	LINE* pData = m_terrain.m_pData;
	for(i=0; i<(m_terrain.m_nSegment+1); i++)
	{
		m_pTerrainBuffer[i*2].color = pData[i].dwColor;
		m_pTerrainBuffer[i*2].x = 0.0f;
		m_pTerrainBuffer[i*2].y = pData[i].fY;
		m_pTerrainBuffer[i*2].z = -pData[i].fHeight;
		
		m_pTerrainBuffer[i*2+1].color = pData[i].dwColor;
		m_pTerrainBuffer[i*2+1].x = m_terrain.m_fWidth;
		m_pTerrainBuffer[i*2+1].y = pData[i].fY;
		m_pTerrainBuffer[i*2+1].z = -pData[i].fHeight;

		if((float)i/2.0f-i/2 == 0.0f)
		{
			m_pTerrainBuffer[i*2].tu = 0.0f;
			m_pTerrainBuffer[i*2].tv = 0.0f;

			m_pTerrainBuffer[i*2+1].tu = 1.0f;
			m_pTerrainBuffer[i*2+1].tv = 0.0f;
		}
		else
		{
			m_pTerrainBuffer[i*2].tu = 0.0f;
			m_pTerrainBuffer[i*2].tv = 1.0f;

			m_pTerrainBuffer[i*2+1].tu = 1.0f;
			m_pTerrainBuffer[i*2+1].tv = 1.0f;
		}

	}


	/*  Old simple terrain generator
	const float col_height = 6.6f;
	const float col_width = m_fWidth/3.0f;
	const int num_col = (int)(m_fLength/(col_height*2));
	tarin_num = 4*num_col*2;
	
	m_pTerrainBuffer = new DEFAULTVERTEX[tarin_num];
	
	// use uniform color and on a flat plane
	for(i=0;i<tarin_num; i++)
	{
		m_pTerrainBuffer[i].color = D3DCOLOR_XRGB(0xff,0xff,0xff); //white
		m_pTerrainBuffer[i].z = 0.0f;
	}

	for(int col=0; col<num_col; col++)
	{
		m_pTerrainBuffer[4*col+0].x = 0.0f;
		m_pTerrainBuffer[4*col+0].y = 0.0f + col*(col_height*2);
		
		m_pTerrainBuffer[4*col+1].x = col_width;
		m_pTerrainBuffer[4*col+1].y = 0.0f + col*(col_height*2);

		m_pTerrainBuffer[4*col+2].x = col_width;
		m_pTerrainBuffer[4*col+2].y = 0.0f + col*(col_height*2)+col_height;

		m_pTerrainBuffer[4*col+3].x = 0.0f;
		m_pTerrainBuffer[4*col+3].y = 0.0f + col*(col_height*2)+col_height;
	}

	for(col=0; col<num_col; col++)
	{
		m_pTerrainBuffer[4*col+4*num_col+0].x = col_width*2;
		m_pTerrainBuffer[4*col+4*num_col+0].y = m_fLength - col*(col_height*2);
		
		m_pTerrainBuffer[4*col+4*num_col+1].x = col_width*3;
		m_pTerrainBuffer[4*col+4*num_col+1].y = m_fLength -col*(col_height*2);

		m_pTerrainBuffer[4*col+4*num_col+2].x = col_width*3;
		m_pTerrainBuffer[4*col+4*num_col+2].y = m_fLength -(col*(col_height*2)+col_height);

		m_pTerrainBuffer[4*col+4*num_col+3].x = col_width*2;
		m_pTerrainBuffer[4*col+4*num_col+3].y = m_fLength -(col*(col_height*2)+col_height);
	}

	Old simple terrain generator*/

	// 7. load missile model
	m_pMissileList = NULL;
	/*
	hr = D3DXCreateBox(m_pd3dDevice, 1.1f, 1.1f, 1.1f, &m_pMissileMesh, NULL);
	if FAILED(hr) { 
		// we take no notice of the return value in this simple game
		return D3D_FAILED; 
	} 
	*/
	
	// this is another way to load missile buffer
	float width = 1.0f/nCol;
	float height = 1.0f/nRow;

	// we create a texture buffer for each unit
	m_pMissileBuffer = new TEXTVERTEX[msil_num*nCol*nRow];

	// for normal missles of the user and the enemy
	const int nKindOfMisl = 2; // all in the first row
	for(i=0; i<nKindOfMisl; i++ )
	{
		m_pMissileBuffer[i*msil_num+0].x = -0.1f;
		m_pMissileBuffer[i*msil_num+0].y = -0.1f;
		m_pMissileBuffer[i*msil_num+0].z = 0.0f;
		
		m_pMissileBuffer[i*msil_num+1].x = 0.1f;
		m_pMissileBuffer[i*msil_num+1].y = -0.1f;
		m_pMissileBuffer[i*msil_num+1].z = 0.0f;
		
		m_pMissileBuffer[i*msil_num+2].x = -0.1f;
		m_pMissileBuffer[i*msil_num+2].y = 0.1f;
		m_pMissileBuffer[i*msil_num+2].z = 0.0f;
		
		
		m_pMissileBuffer[i*msil_num+3].x = 0.1f;
		m_pMissileBuffer[i*msil_num+3].y = 0.1f;
		m_pMissileBuffer[i*msil_num+3].z = 0.0f;
	
		// texture coordinates at (0, i)
		m_pMissileBuffer[i*msil_num+0].tu = i *width;
		m_pMissileBuffer[i*msil_num+0].tv = 1 *height;

		m_pMissileBuffer[i*msil_num+1].tu = width*(i+1);
		m_pMissileBuffer[i*msil_num+1].tv = 1 *height;

		m_pMissileBuffer[i*msil_num+2].tu = width*i;
		m_pMissileBuffer[i*msil_num+2].tv = 0 *height;
	
		m_pMissileBuffer[i*msil_num+3].tu = width*(i+1);
		m_pMissileBuffer[i*msil_num+3].tv = 0 *height;

		for(int j=0;j<msil_num; j++)
		{
			m_pMissileBuffer[i*msil_num+j].color = 0xffffffff;
		}
	}

	// for explosion 
	int nOffSet = nCol*msil_num;
	
	for(i=0; i<EXPLOSION_FRAMES; i++ )
	{
		m_pMissileBuffer[nOffSet + i*msil_num+0].x = -1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+0].y = -1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+0].z = 0.0f;
		
		m_pMissileBuffer[nOffSet + i*msil_num+1].x = 1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+1].y = -1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+1].z = 0.0f;
		
		m_pMissileBuffer[nOffSet + i*msil_num+2].x = -1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+2].y = 1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+2].z = 0.0f;
		
		
		m_pMissileBuffer[nOffSet + i*msil_num+3].x = 1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+3].y = 1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+3].z = 0.0f;
	
		// texture coordinates at (1, i)
		m_pMissileBuffer[nOffSet + i*msil_num+0].tu = i *width;
		m_pMissileBuffer[nOffSet + i*msil_num+0].tv = 2 *height;

		m_pMissileBuffer[nOffSet + i*msil_num+1].tu = width*(i+1);
		m_pMissileBuffer[nOffSet + i*msil_num+1].tv = 2 *height;

		m_pMissileBuffer[nOffSet + i*msil_num+2].tu = width*i;
		m_pMissileBuffer[nOffSet + i*msil_num+2].tv = 1 *height;
	
		m_pMissileBuffer[nOffSet + i*msil_num+3].tu = width*(i+1);
		m_pMissileBuffer[nOffSet + i*msil_num+3].tv = 1 *height;

		for(int j=0;j<msil_num; j++)
		{
			m_pMissileBuffer[nOffSet + i*msil_num+j].color = 0xffffffff;
		}
	}

	return hr;
}


// This function has been abandoned 
void CThunderView::UnloadGameObjects()
{
	if(!m_bReady) return;
	// release all missiles and planes
	SAFE_DELETE( m_pPlane);
	
	SafeReleaseList(&m_pEnemyList);
	SafeReleaseList(&m_pMissileList);
	
	// destroy terrian buffer
	SAFE_DELETE(m_pTerrainBuffer);
	
	// destroy the missile objects
	SAFE_DELETE(m_pMissileBuffer);

	// destory the user plane object
	
	for(int i=0; i<(int)m_dwNumShipTypes; i++)
	{
		if(m_pPlaneMesh[i])
		{
			m_pPlaneMesh[i]->Destroy();
			SAFE_DELETE( m_pPlaneMesh[i] );
		}
	}
	
	// release texture
	SAFE_RELEASE( m_pTexture1 );
	SAFE_RELEASE( m_pTexture2 );
	
	// Release all the directinput objects
	if (m_lpDI) 
    { 
        if (m_lpDIDevice) 
        { 
        // Always unacquire device before calling Release(). 
            m_lpDIDevice->Unacquire(); 
            m_lpDIDevice->Release();
            m_lpDIDevice = NULL; 
        } 
        m_lpDI->Release();
        m_lpDI = NULL; 
    } 

	// destory sound object
	m_pPerformance->Stop(
        NULL,   // Stop all segments.
        NULL,   // Stop all segment states.
        0,      // Do it immediately.
        0       // Flags.
    );
 
    m_pPerformance->CloseDown();
 
    m_pLoader->Release(); 
    m_pPerformance->Release();
    for(i=0; i<END_SOUND; i++)
		m_pSegment[i]->Release();
 
    CoUninitialize();

}

HRESULT CThunderView::Render()
{
	// We render accroding to Game Status
	
	if(m_nGameState == GAME_RUNNING)
	{
		// Clear the backbuffer to a black color
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0L );
		
		// 1.0 Set the eye positon(camera)
		m_Camera.CaculateParam();
		m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_Camera.matView );

		D3DXMATRIX matProj;
		D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, 1.0f, 0.1f, 100.0f ); // 1~100
		m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );

		// begin scene
		m_pd3dDevice->BeginScene();
		
		// 2.0 draw the simple terrian
		
		// Set the world matrix for terrian
		D3DXMATRIX matWorld;
		D3DXMatrixIdentity( &matWorld );
		m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,      TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,     FALSE );
		//m_pd3dDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME);
		m_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x33333333);

		m_pd3dDevice->SetVertexShader( D3DFVF_TEXTVERTEX );
		
		m_pd3dDevice->SetTexture(0, m_pTexture2);

		int from = m_terrain.GetSegmentFromY(m_pPlane->m_vPos.y) - m_nVisibleSegmentNum;
		int to = from + m_nVisibleSegmentNum*2;
		if (from<0) from = 0;
		if (to > m_terrain.m_nSegment) 
			to = m_terrain.m_nSegment;
		
		//from = ((from-m_nVisibleSegmentNum) > 0) ? (from-m_nVisibleSegmentNum) : 0; 
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, (to-from)*2, &m_pTerrainBuffer[from*2], 
										   sizeof(TEXTVERTEX) );
		m_pd3dDevice->SetTexture(0, NULL);

		// draw the movable region indicator
		//DEFAULTVERTEX line[4];
		//CBaseObject nearPoint;

		/* Old simple terrain 
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_LINESTRIP, tarin_num-1, m_pTerrainBuffer, 
										   sizeof(DEFAULTVERTEX) );
		Old simple terrain */

		// 3.0 draw the plane
		
		// Set renderstates for rendering the ship
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,      TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,           TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x33333333);
		m_pd3dDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID);
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

		m_pd3dDevice->SetVertexShader( D3DFVF_MODELVERTEX );

		// Render the ship
		D3DXMatrixIdentity( &matWorld );
		D3DXMATRIX temp;
		D3DXMatrixRotationX(&temp, D3DX_PI/2 + m_pPlane->m_fAngleX);
		D3DXMatrixMultiply(&matWorld, &matWorld, &temp);
		D3DXMatrixRotationY(&temp, D3DX_PI+m_pPlane->m_fAngleY);
		D3DXMatrixMultiply(&matWorld, &matWorld, &temp);
		D3DXMatrixTranslation(&temp, m_pPlane->m_vPos.x, m_pPlane->m_vPos.y, m_pPlane->m_vPos.z);
		D3DXMatrixMultiply(&matWorld, &matWorld, &temp);

		m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

		m_pPlaneMesh[m_pPlane->m_dwCurrentShipType]->Render( m_pd3dDevice, TRUE, TRUE );

		// 3.1 draw enemy planes with the same render state as user plane
		CBaseObject* pObject = m_pEnemyList;

		while( pObject )
		{
			// draw PLANE_ENEMY1
			if((pObject->m_dwType == PLANE_ENEMY1) || (pObject->m_dwType == PLANE_ENEMY2))
			{
				// set position
				D3DXMatrixIdentity( &matWorld );
				
				if(pObject->m_fSize>1.0f)
				{
					// draw a large object
					float scale = pObject->m_fSize / 1.0f;
					D3DXMatrixScaling(&temp, scale, scale, scale);
					D3DXMatrixMultiply(&matWorld, &matWorld, &temp);
				}

				D3DXMatrixRotationX(&temp, D3DX_PI/2 - pObject->m_fAngleX);
				D3DXMatrixMultiply(&matWorld, &matWorld, &temp);
				D3DXMatrixRotationY(&temp, D3DX_PI+pObject->m_fAngleY);
				D3DXMatrixMultiply(&matWorld, &matWorld, &temp);
				
				D3DXMatrixRotationZ(&temp, D3DX_PI);
				D3DXMatrixMultiply(&matWorld, &matWorld, &temp);
				
				D3DXMatrixTranslation(&temp, pObject->m_vPos.x, pObject->m_vPos.y, pObject->m_vPos.z);
				D3DXMatrixMultiply(&matWorld, &matWorld, &temp);
				
				m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );
				
				m_pPlaneMesh[((CPlane*)pObject)->m_dwCurrentShipType]->Render( m_pd3dDevice, TRUE, TRUE );

				// Draw a simple object in local space
			}
			pObject = pObject->m_pNext;
		}
		
		// 4. Draw the missiles
		
		pObject = m_pMissileList;
		
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,      TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,           FALSE );
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
		// enable alpha and reference color for billboard
		m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
		m_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
  
		m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE, TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_ALPHAREF,        0x08 );
		m_pd3dDevice->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL );

		
		m_pd3dDevice->SetVertexShader( D3DFVF_TEXTVERTEX );
		
		// set texture status
		
		// load texture since we use billboard
		m_pd3dDevice->SetTexture(0, m_pTexture1);
		
		while( pObject )
		{
			
			// set position
			// using billboard to draw a missile
			D3DXMATRIX mat = m_Camera.matBillboard;
			
			if(pObject->m_fSize>1.0f)
			{
				// draw a large object
				float scale = pObject->m_fSize / 1.0f;
				D3DXMatrixScaling(&temp, scale, scale, scale);
				D3DXMatrixMultiply(&mat, &mat, &temp);
			}

			mat._41 = pObject->m_vPos.x;
			mat._42 = pObject->m_vPos.y;
			mat._43 = pObject->m_vPos.z;
			

			m_pd3dDevice->SetTransform( D3DTS_WORLD, &mat );

			// Draw a simple missile in local space
			// choose the right kind of missile to draw
			int n; // index of the the missle buffer
			if(pObject->m_dwType == EXPLOSION_LARGE)
			{
				// for just the explosion
				// choose n accroding to transition
				
				n = nCol + (int)( (((CMissile*)pObject)->m_fTransition) / 
							(1.0f/EXPLOSION_FRAMES) );
				if(n>=2*nCol)
				{
					n = 2*nCol -1;
				}
			}
			else
			{
				// for all other missile
				if(((CMissile*)pObject)->m_nManufactory == USER)
					n = 0; // (0,0) in texture coordinate
				else
				{
					if(pObject->m_dwType == MSIL_NORMAL)
					{
						
					}
					n = 1; // (0,1) in texture coordinate
				}
			}

			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, &m_pMissileBuffer[n*msil_num],
							sizeof(TEXTVERTEX) );
			
			pObject = pObject->m_pNext;
		}
		
		// only for billboard, so we turn it off
		m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );
		m_pd3dDevice->SetRenderState( D3DRS_ALPHATESTENABLE,    FALSE );

		m_pd3dDevice->SetTexture( 0, NULL );

		D3DXMatrixIdentity( &matWorld );
		m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );
		
		// Display info in the corner
		// Output statistics
		TCHAR score[30];

		FORMAT_TEXT(score, _T("Health: %d\nScore: %d"), m_pPlane->m_nHealth, m_nScore);
        m_pFont->DrawText( 2,  0, D3DCOLOR_ARGB(255,255,255,0), score);
        
		// End the scene
		m_pd3dDevice->EndScene();

		// Present the backbuffer contents to the display
		//m_pd3dDevice->Present( NULL, NULL, NULL, NULL );

		return S_OK;
	}//if(m_nGameState == GAME_RUNNING)
	else if(m_nGameState == USER_CRASHED)
	{
		// Clear the backbuffer to a black color
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x0000ff00, 1.0f, 0L );
		
		// begin scene
		m_pd3dDevice->BeginScene();
	
		// Output statistics
        m_pFont->DrawText( 2,  0, D3DCOLOR_ARGB(255,255,255,0), _T("you are dead! press F2 to restart."));
        //m_pFont->DrawText( 2, 20, D3DCOLOR_ARGB(255,255,255,0), m_strDeviceStats );

		// End the scene
		m_pd3dDevice->EndScene();

		return S_OK;
	}
	else if(m_nGameState == GAME_PAUSED)
	{
		// Clear the backbuffer to a black color
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0L );
		
		// begin scene
		m_pd3dDevice->BeginScene();
	
		m_pFont->DrawText( 2,  0, D3DCOLOR_ARGB(255,255,255,0), _T("Game Paused. press 'p' to resume."));
        
		// End the scene
		m_pd3dDevice->EndScene();

		return S_OK;
	}
	else if(m_nGameState == GAME_VICTORY)
	{
		// Clear the backbuffer to a black color
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0L );
		
		// begin scene
		m_pd3dDevice->BeginScene();
	
		m_pFont->DrawText( 2,  0, D3DCOLOR_ARGB(255,255,255,0), _T("You are victory!!! press 'F2' to play again"));
        
		// End the scene
		m_pd3dDevice->EndScene();

		return S_OK;
	}
	else// if(m_nGameState == GAME_INITIAL)
	{
		// Clear the backbuffer to a black color
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0L );
		
		// begin scene
		m_pd3dDevice->BeginScene();
	
		TCHAR text[100];

		FORMAT_TEXT(text, _T("HOT Keys:\n\n\
			F2:		     To start a new game\n\
			P:	     Pause the game\n\
			Arrow key:	     Navigate your plane\n\
			SPACE:	     Fire\n\
			A W D X Z :	     Change the camera\n\
			TAB:	     Change your plane model\n\
			1 2 3 4:	     Change weapon\n\n\
			Note:\n\
			You plane is only movable within an invisible region\n\
			\n\n See About... in the Help menu to see more information \n\
			about the game\n\n\
			By LiXizhi\n\
			2001.10.31"));
        
		m_pFont->DrawText( 2,  0, D3DCOLOR_ARGB(255,255,255,0), text);
        
		// End the scene
		m_pd3dDevice->EndScene();

		return S_OK;
	}
	
}

/* About the simple MVC mechanism used in this game
In order to clearify the structure of this game we no longer dispatch tasks to 
different functions. Instead, For each M/V/C we use one function to handle 
almost everything with comments before each task blocks.  
*/

/* About controller
Notice that the controller is also simplified with the support of direct-input
so call this controller function at equil intervals is sufficient to update the data
in the model.
*/
void CThunderView::Controller()
{
	// 1. Get the keyboard input
	#define KEYDOWN(name, key) (name[key] & 0x80) 
 
    char     buffer[256]; 
    HRESULT  hr; 
 
    hr = m_lpDIDevice->GetDeviceState(sizeof(buffer),(LPVOID)&buffer); 
    if FAILED(hr) 
    { 
         // If it failed, the device has probably been lost. 
         // Check for (hr == DIERR_INPUTLOST) 
         // and attempt to reacquire it here. 
         return; 
    } 
	
	// We execute keystrock accroding to Game Status
	
	if(m_nGameState == GAME_RUNNING)
	{
		// move forward the movable region every scene
	
		float fTanA = m_terrain.GetSlope(m_pPlane->m_vPos.y);
		float fCosA = 1.0f/(float)sqrt(1+(fTanA*fTanA));
		
		m_fCurrentLinePos += m_fViewSpeed*fCosA;
	
		// using the mark technoledge in the controller proccess
		/* In generating marks, we set marks for all changeable objects in the world space, 
		but do not change the model, which garrentees that every objects "sees" the same world
		space(represented by models), and accordingly generating behaviours at the same time
		*/
		GenerateMarks(buffer);
		// Once marks were generated, we will force the model to change accroding to the marks 
		// generated just now.
		ApplyMarks(buffer);
	}
	else
	{
	}
}

void CThunderView::PlaySound(int index)
{
	ASSERT(index<END_SOUND);
	m_pPerformance->PlaySegmentEx(
        m_pSegment[index],  // Segment to play.
        NULL,        // Used for songs; not implemented.
        NULL,        // For transitions. 
        0,           // Flags.
        0,           // Start time; 0 is immediate.
        NULL,        // Pointer that receives segment state.
        NULL,        // Object to stop.
        NULL         // Audiopath, if not default.
    );
}

void CThunderView::OnDestroy() 
{
	m_nFlashStatus = FLASH_UNINITIALIZED;
	CView::OnDestroy();
	
	PauseGame();
	
	if(m_nGameState != GAME_UNINITIALIZED)
		Cleanup3DEnvironment();
	//UnloadGameObjects();
	
}

// This function has been abandoned (never called through OnTimer but OnIdle)
void CThunderView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent == TIMER_THUNDER)
	{
		//RenderScene();
	}
	CView::OnTimer(nIDEvent);
}

HRESULT CThunderView::ReloadPlane()
{
	for(int i=0; i<(int)m_dwNumShipTypes; i++)
	{
		if(m_pPlaneMesh[i])
		{
			m_pPlaneMesh[i]->Destroy();
			SAFE_DELETE( m_pPlaneMesh[i] );
			m_pPlaneMesh[i] = NULL;
		}
		// Create new object
		m_pPlaneMesh[i] = new CD3DMesh();
	
		LPDIRECT3DVERTEXBUFFER8 pVB;
		DWORD        dwNumVertices;
		MODELVERTEX* pVertices;
		D3DXVECTOR3  vCenter;
		FLOAT        fRadius;
    
		CString path = m_strSearchPath + _T("\\media\\") + m_strShipFiles[i];
    
		if( FAILED( m_pPlaneMesh[i]->Create( m_pd3dDevice,
												path.GetBuffer(100) ) ) )
			return E_FAIL;
		
		path.ReleaseBuffer();
		// Set the FVF to a reasonable type
		m_pPlaneMesh[i]->SetFVF( m_pd3dDevice, D3DFVF_MODELVERTEX );

		// Gain access to the model's vertices
		m_pPlaneMesh[i]->GetSysMemMesh()->GetVertexBuffer( &pVB );
		dwNumVertices = m_pPlaneMesh[i]->GetSysMemMesh()->GetNumVertices();
		pVB->Lock( 0, 0, (BYTE**)&pVertices, 0 );

		// Scale the new object to a standard size  
		D3DXComputeBoundingSphere( pVertices, dwNumVertices,
								   D3DFVF_MODELVERTEX, &vCenter, &fRadius );
		for(int j=0; j<(int)dwNumVertices; j++ )
		{
			pVertices[j].p /= (fRadius/1); // so it's single wing width is 1.0f
		}

		// Done with the vertex buffer
		pVB->Unlock();
		pVB->Release();
    
		m_pPlaneMesh[i]->RestoreDeviceObjects( m_pd3dDevice );
	}
	return S_OK;
}

// this will clear any data of the current game, and set up a fresh new game
void CThunderView::Restart()
{
	m_pPlane->m_dwCurrentShipType = 0L;
	m_fViewSpeed = 0.1f;
	m_nScore = 0;

	// set terrain size
	/* now we donot set the size since we got the values from the users
 	m_terrain.m_fWidth = 20.0f;
	m_terrain.m_fLength = 600.0f;
	m_terrain.m_nSegment = 30;
	m_terrain.m_fMaxHeight = 15.0f;
	m_terrain.m_fMinSegLength = 10.0f;
	m_terrain.m_fRadius = 2.0f;
	*/

	// set plane position
	m_pPlane->m_vPos = D3DXVECTOR3(10.0f, 10.0f, - 1.0f);
	m_pPlane->m_dwMark = 0;
	m_pPlane->m_fAngleY = 0.0f;
	m_pPlane->m_nHealth = 10;
	m_pPlane->m_fSize = 0.5f; // smaller
	m_pPlane->m_fVel = 0.29f;

	
	// Set movable region
	m_fCurrentLinePos = m_pPlane->m_vPos.y - 1.0f;
	m_fMovementRange = 10.0f;

	// delete the enemy plane and all missiles if any
	SafeReleaseList(&m_pEnemyList);
	SafeReleaseList(&m_pMissileList);
	

	// set camera pos
	m_Camera.vPos = m_pPlane->m_vPos;

}

void CThunderView::UserMark(const char buffer[])
{
	// 1. check to see if any missiles hit the user plane
	CBaseObject* pMissile = m_pMissileList;

	while( pMissile )
	{
		if( (((CMissile*)pMissile)->m_nManufactory == ENEMY ) && IsOverlapped(m_pPlane, pMissile) )
		{
			HitMarks(m_pPlane, pMissile);
		}
		pMissile = pMissile->m_pNext;
	}

	// 2. check to see if user hits a enemy plane
	CBaseObject* pEnemy = m_pEnemyList;

	while( pEnemy )
	{
		float nDistance = GetDistance(m_pPlane, pEnemy);
		if( nDistance < (m_pPlane->m_fSize + pEnemy->m_fSize*0.5f))
		{
			m_pPlane->m_dwMark = MARK_DEAD;
		}
		pEnemy = pEnemy->m_pNext;
	}

	// 2. Move the spaceship accrodingly
	// Clear the movement marks in the userplane, for we will generating new ones 
	// accroding to the user input
	m_pPlane->m_dwMark = CLEAR_PLANEMARK(m_pPlane->m_dwMark);

	// Turn the spaceship right or left 
	if (KEYDOWN(buffer, DIK_RIGHT))
	{
        // Turn right.
		m_pPlane->m_dwMark |= MARK_RIGHT;
	}
    else if(KEYDOWN(buffer, DIK_LEFT))
	{
        // Turn left.
		m_pPlane->m_dwMark |= MARK_LEFT;	
	}
	else
	{
		// the plane is flying flat
		
		// we donot need any marks here, because
		// If neither of the above mark is set, the controller knows that the plane is flying flat 
	}
    // Thrust or stop the spaceship within the movable region
    if (KEYDOWN(buffer, DIK_UP))
	{
        // Move the spaceship forward. 
		if(m_pPlane->m_vPos.y < (m_fCurrentLinePos + m_fMovementRange))
		{
			m_pPlane->m_dwMark |= MARK_FORWARD;
	
		}
	}
	else if (KEYDOWN(buffer, DIK_DOWN))
	{
        // backward the spaceship.
		if(m_pPlane->m_vPos.y > m_fCurrentLinePos)
		{
			m_pPlane->m_dwMark |= MARK_BACKWARD;
		}
	}
	else
	{
		// let the plane have a constant velocity when on idle
		
		// Actually, we donot need any marks here, because
		// if neither of the above mark is set, the controller knows that 
		// the plane have a constant velocity when on idle 
		// however, we do used a mark here for clearity.
		m_pPlane->m_dwMark |= MARK_GLIDING;
	}
		
	// fire missile
	if(KEYDOWN(buffer, DIK_SPACE))
	{
		m_pPlane->m_dwMark |= MARK_FIRE;
	}
	
	// change plane type 
	if(KEYDOWN(buffer, DIK_TAB))
	{
		static DWORD dwLastCallTime = 0;
		if((timeGetTime()-dwLastCallTime) >= 300)
		{
			dwLastCallTime = timeGetTime();
			m_pPlane->m_dwCurrentShipType++;
			if(m_pPlane->m_dwCurrentShipType >= m_dwNumShipTypes)
				m_pPlane->m_dwCurrentShipType = 0L;
		}
	}
	
}

void CThunderView::EnemyMark()
{
	// create strategy for exsiting planes 
	CBaseObject* pObject = m_pEnemyList;
	
    while( pObject )
    {
		// Universal marks
		
		/*
		// the enemy is flying to the back of the user plane for a certain DISTANCE defined nefore
        if( (m_pPlane->m_vPos.y - pObject->m_vPos.y) > DISTANCE/4 )
		{
			pObject->m_dwMark = MARK_DEAD;
			pObject = pObject->m_pNext;
			continue;
		}
		*/
		
		// the object has flown over the movable region
		// so let it die and bomb itself(also a threaten to the user)
		if(pObject->m_vPos.y < m_fCurrentLinePos)
		{
			pObject->m_dwMark = MARK_DEAD;
			pObject = pObject->m_pNext;
			continue;
		}
		else if((m_fCurrentLinePos + m_fMovementRange + DISTANCE) > m_terrain.m_fLength)
		{
			// if the user has come into the end of the scenario, all object should be removed 
			// so the user plane come to an end with no enemy on screen
			pObject->m_dwMark = MARK_DEAD;
			pObject = pObject->m_pNext;
			continue;
		}
		
		// strategy for PLANE_ENEMY1
		if(pObject->m_dwType == PLANE_ENEMY1)
		{
			// check the enemy
			
			// condition 1: the enemy expired
			
			// condition 2: it is being hit by an object
			
			// hit missile
			CBaseObject* pMissile = m_pMissileList;
	
			while( pMissile )
			{
				if( (((CMissile*)pMissile)->m_nManufactory == USER ) && IsOverlapped(pObject, pMissile) )
				{
					HitMarks(pObject, pMissile);
					AddUserBonus(1, 10);
				}
				pMissile = pMissile->m_pNext;
			}
						
			// Clear the movement marks , for we will generating new ones 
			pObject->m_dwMark = CLEAR_PLANEMARK(pObject->m_dwMark);

			// move the enemy

			pObject->m_dwMark |= MARK_FORWARD;

			// fire if possible
			// we just fire for no reason for ENEMY1
			pObject->m_dwMark |= MARK_FIRE;
       	}
		else if (pObject->m_dwType == PLANE_ENEMY2)
		{
			CEnemyTrack enemy(this);
			enemy.GenerateMark(pObject);
		}

		pObject = pObject->m_pNext;
    }
}

void CThunderView::FireMissile(CPlane *pPlane)
{
	// check the recharge time to see if it's ready to fire a missile
	if( (timeGetTime() - pPlane->m_fLastFireTime) > pPlane->m_fRechargeTime )
	{
		pPlane->m_fLastFireTime = timeGetTime();
	}
	else
		return;
	
	float fVel = 0.4f;
	if(pPlane->m_dwType == PLANE_USER)
	{
		fVel = 0.4f;
		// new missiles accroding to its type
		if(pPlane->m_dwBulletType == 0x00000001)
		{ // fire single normal missile
			CMissile* pMissile = new CMissile();
			pMissile->m_nManufactory = USER;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_fVel = fVel;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.y += pMissile->m_fRange;

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			PlaySound(SOUND_FIRE_SINGLE);
		}
		else if(pPlane->m_dwBulletType == 0x00000002)
		{ // fire double normal missiles
			CMissile* pMissile = new CMissile();
			pMissile->m_nManufactory = USER;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_fVel = fVel;
			
			const float tween = 0.4f;// distance between two parallel missile
			pMissile->m_vPos.x -= tween/2;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.y += pMissile->m_fRange;

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			pMissile = new CMissile();
			pMissile->m_nManufactory = USER;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_vPos.x += tween/2;
			pMissile->m_fVel = fVel;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.y += pMissile->m_fRange;

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			PlaySound(SOUND_FIRE_DOUBLE);
		}
		else if(pPlane->m_dwBulletType == 0x00000003)
		{ // fire triple normal missile
			CMissile* pMissile = new CMissile();
			pMissile->m_nManufactory = USER;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			const float tween = 0.4f;// distance between three  missiles
			pMissile->m_vPos.x -= tween/2;
			pMissile->m_fVel = fVel;
			
			// set target
			const float fAngle = D3DX_PI/6.0f; // angle between two missiles
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.x += pMissile->m_fRange*((float)sin(-fAngle));
			pMissile->m_vTarget.y += pMissile->m_fRange*((float)cos(-fAngle));

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			pMissile = new CMissile();
			pMissile->m_nManufactory = USER;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_fVel = fVel;
			
			//pMissile->m_vPos.x += tween/2;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.y += pMissile->m_fRange;

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			pMissile = new CMissile();
			pMissile->m_nManufactory = USER;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_vPos.x += tween/2;
			pMissile->m_fVel = fVel;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.x += pMissile->m_fRange*((float)sin(fAngle));
			pMissile->m_vTarget.y += pMissile->m_fRange*((float)cos(fAngle));

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			PlaySound(SOUND_FIRE_DOUBLE);
		}
		else if(pPlane->m_dwBulletType == 0x00000010)
		{ // fire single track missile
			CMissile* pMissile = new CMissile();
			pMissile->m_nManufactory = USER;
			pMissile->m_dwType = MSIL_TRACK; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_fVel = fVel;
			
			// set target
			pMissile->m_fRange = 17.0f;
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.y += pMissile->m_fRange;

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			PlaySound(SOUND_FIRE_SINGLE);
		}
	}
	else if((pPlane->m_dwType == PLANE_ENEMY1) || (pPlane->m_dwType == PLANE_ENEMY2))
	{
		fVel = 0.3f;
		// new missiles accroding to its type
		if(pPlane->m_dwBulletType == 0x00000001)
		{ // fire single normal missile
			CMissile* pMissile = new CMissile();
			pMissile->m_nManufactory = ENEMY;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_fVel = fVel;
			
			// set target
			
			// use a pattern to make the missile path more diverse
			static int nPattern = 0;
			if((++nPattern)>3)
			{
				nPattern = 0;
			}
			if(nPattern == 0)
			{
				pMissile->m_vTarget = m_pPlane->m_vPos;
				pMissile->m_vTarget.y += m_fViewSpeed;
			}
			else if(nPattern == 1)
			{
				pMissile->m_vTarget = pMissile->m_vPos;
				pMissile->m_vTarget.y -= pMissile->m_fRange;
			}
			else if(nPattern == 2)
			{
				pMissile->m_vTarget = pMissile->m_vPos;
				pMissile->m_vTarget.y -= pMissile->m_fRange;
				pMissile->m_vTarget.x += pMissile->m_fRange/2;
			}
			else // if(nPattern == 3)
			{
				pMissile->m_vTarget = pMissile->m_vPos;
				pMissile->m_vTarget.y -= pMissile->m_fRange;
				pMissile->m_vTarget.x -= pMissile->m_fRange/2;
			}
			
			
			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			//PlaySound(FIRE_SINGLE);
		}
		else if(pPlane->m_dwBulletType == 0x00000002)
		{ // fire double normal missiles
			CMissile* pMissile = new CMissile();
			pMissile->m_nManufactory = ENEMY;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			const float tween = 0.4f;// distance between two parallel missile
			pMissile->m_vPos.x -= tween/2;
			pMissile->m_fVel = fVel;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.y -= pMissile->m_fRange;

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			pMissile = new CMissile();
			pMissile->m_nManufactory = ENEMY;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_vPos.x += tween/2;
			pMissile->m_fVel = fVel;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.y -= pMissile->m_fRange;

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			// PlaySound(FIRE_DOUBLE);
		}
		else if(pPlane->m_dwBulletType == 0x00000003)
		{ // fire triple normal missile
			CMissile* pMissile = new CMissile();
			pMissile->m_nManufactory = ENEMY;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			const float tween = 0.4f;// distance between three  missiles
			pMissile->m_vPos.x -= tween/2;
			pMissile->m_fVel = fVel;
			
			// set target
			const float fAngle = D3DX_PI/6.0f; // angle between two missiles
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.x += pMissile->m_fRange*((float)sin(-fAngle));
			pMissile->m_vTarget.y -= pMissile->m_fRange*((float)cos(-fAngle));

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			pMissile = new CMissile();
			pMissile->m_nManufactory = ENEMY;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_fVel = fVel;
			
			//pMissile->m_vPos.x += tween/2;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.y -= pMissile->m_fRange;

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
			pMissile = new CMissile();
			pMissile->m_nManufactory = ENEMY;
			pMissile->m_dwType = MSIL_NORMAL; // we now have only one kind of missile to fire
			pMissile->m_vPos = pPlane->m_vPos;
			pMissile->m_vPos.x += tween/2;
			pMissile->m_fVel = fVel;
			
			// set target
			pMissile->m_vTarget = pMissile->m_vPos;
			pMissile->m_vTarget.x += pMissile->m_fRange*((float)sin(fAngle));
			pMissile->m_vTarget.y -= pMissile->m_fRange*((float)cos(fAngle));

			AddToList((CBaseObject*)(pMissile), (CBaseObject**)(&m_pMissileList));
			
		}
	}
	else if(pPlane->m_dwType == PLANE_ENEMY2)
	{
	}
}

// for simplicity, some other millicellious functions is also included here
void CThunderView::GenerateMarks(const char buffer[])
{
	// 1. buffer stores the keyboard status
	
	
	// 5. generating Missile marks
	MissileMark();
	// 6. generating Enemy Strategy (Marks only)
	EnemyMark();
	// 7. generating user plane marks
	UserMark(buffer);

}

void CThunderView::ApplyMarks(const char buffer[])
{
	// 1. buffer stores the keyboard status
	
	/* the sequence of user and camera appliance cannot be altered
		bacause camera is dependant on the user's postion */
	// 2. Move the user spaceship accrodingly
	
	ApplyPlaneMark(m_pPlane);

	// 2.1. Move the controlling camera 
	CameraApply(buffer);
	
	// 3. we have come to the end of the scene, so restart the game 
	// // Never reach the edge, but 10.0 cm prior to it
	if(m_terrain.m_fLength<(m_pPlane->m_vPos.y + 10.0f))
	{
		Restart();
		AnnounceVictory();
		return;
	}

	// 4. set weapon
	SetWeapon(buffer);
		
	// 5. for missile 
	MissileApplyMark();
	// 6. for enemy
	EnemyApplyMark();
	
	// 7. this should be evaluated last, for in it, the game may be over 
	//due to the deadth of the user plane

	if (GET_MARK(m_pPlane->m_dwMark, MARK_DEAD))
	{
		// the user is crashed
		Restart();
		if(m_nGameState != GAME_UNINITIALIZED)
			m_nGameState = USER_CRASHED;
	}
	
}

/*
void CThunderView::OnGameTest() 
{
	// test mark -----------succeeded
	DWORD mask = 0;
	mask = mask | MARK_BACKWARD | MARK_DEAD| MARK_GLIDING;
	HRESULT hr = false;
	if(GET_MARK(mask, MARK_BACKWARD))
	{
		hr = true;
	}
	if(GET_MARK(mask, MARK_GLIDING))
	{
		hr = true;
	}
	if(GET_MARK(mask, MARK_RIGHT))
	{
		hr = true;
	}
	mask = CLEAR_PLANEMARK(mask);
	if(GET_MARK(mask, MARK_BACKWARD))
	{
		hr = true;
	}
	if(GET_MARK(mask, MARK_GLIDING))
	{
		hr = true;
	}
	if(GET_MARK(mask, MARK_DEAD))
	{
		hr = true;
	}

	hr= false;
}
*/

//Set the object on its 3d terrain
void CThunderView::Set3DPositionOf(CBaseObject *pObject)
{
	float fTanA = m_terrain.GetSlope(pObject->m_vPos.y);
	float fCosA = 1.0f/(float)sqrt(1+(fTanA*fTanA));
	pObject->m_vPos.z = -(m_terrain.GetHeightFromY(pObject->m_vPos.y) + pObject->m_fHeight/fCosA);
	m_terrain.GetLookingAngle(pObject->m_vPos.y, &pObject->m_fAngleX); 
}

void CThunderView::MissileMark()
{
	// Check the missile list to see if any missile should be deleted from list
	CBaseObject* pObject = m_pMissileList;
	
    CMissileTrack msil(this);
			
	while( pObject )
    {
		/*
		// For MSIL_NORMAL the only range determined the lifetime
		if(pObject->m_dwType == MSIL_NORMAL)
		{
			// check the missile
			
			// condition 1: the range expired
        	if( ((CMissile*)pObject)->m_fTransition >= 1.0f )
			{
				pObject->m_dwMark = MARK_DEAD;
			}
       	}
		else if(pObject->m_dwType == MSIL_TRACK)
		{
			msil.GenerateMark(pObject);
		}
		*/
		// check the missile no matter what it kind is
		
		// condition 1: the range expired
        if( ((CMissile*)pObject)->m_fTransition >= 1.0f )
		{
			pObject->m_dwMark = MARK_DEAD;
		}
    
		pObject = pObject->m_pNext;
    }
}

int CThunderView::GetListNum(CBaseObject *pObject)
{
	int number = 0; 
	while( pObject )
    {
		number++;
		pObject = pObject->m_pNext;
    }
	return number;
}

void CThunderView::ApplyPlaneMark(CPlane* pPlane)
{
	// Turn the spaceship right or left 
	const float ANGLE_INCREASE=0.05f; // amount in angle in everyframe when turning
	const float ANGLE_MAX=0.5f; // maxisum angle when turning

	// store the mark of the plane
	DWORD mark = pPlane->m_dwMark;

	if (GET_MARK(mark, MARK_RIGHT))
	{
        // Turn right.
		if(pPlane->m_dwType == PLANE_USER)
		{
			pPlane->m_vPos.x += pPlane->m_fVel;
			if(pPlane->m_fAngleY > -ANGLE_MAX)
			{
				pPlane->m_fAngleY -= ANGLE_INCREASE;
			}
		}
		else
		{
			pPlane->m_vPos.x -= pPlane->m_fVel;
			if((pPlane->m_fAngleY) < ANGLE_MAX)
			{
				pPlane->m_fAngleY += ANGLE_INCREASE;
			}
		}
	}
    else if(GET_MARK(mark, MARK_LEFT))
	{
		// Turn left.
		if(pPlane->m_dwType == PLANE_USER)
		{
			// Turn left.
			pPlane->m_vPos.x -= pPlane->m_fVel;
			if((pPlane->m_fAngleY) < ANGLE_MAX)
			{
				pPlane->m_fAngleY += ANGLE_INCREASE;
			}
			
		}
		else
		{
			pPlane->m_vPos.x += pPlane->m_fVel;
			if(pPlane->m_fAngleY > -ANGLE_MAX)
			{
				pPlane->m_fAngleY -= ANGLE_INCREASE;
			}
		}
   	}
	else
	{
		// the plane is flying flat
		if(pPlane->m_fAngleY != 0.0f)
		{
			if(pPlane->m_fAngleY < 0.0f)
			{
				pPlane->m_fAngleY = ((pPlane->m_fAngleY + ANGLE_INCREASE) < 0.0f) ?
					(pPlane->m_fAngleY + ANGLE_INCREASE) : 0.0f;
			}
			else // when "pPlane->m_fAngleY > 0.0f"
			{
				pPlane->m_fAngleY = ((pPlane->m_fAngleY - ANGLE_INCREASE) > 0.0f) ?
					(pPlane->m_fAngleY - ANGLE_INCREASE) : 0.0f;
			}
		}
	}
    // Thrust or stop the spaceship 
    // notice the sematics here. this allows you to thrust and turn left at the same time
	float fTanA = m_terrain.GetSlope(pPlane->m_vPos.y);
	float fCosA = 1.0f/(float)sqrt(1+(fTanA*fTanA));
	if (GET_MARK(mark, MARK_FORWARD))
	{
		// Move the spaceship forward. 
			
		if(pPlane->m_dwType == PLANE_USER)
		{
			pPlane->m_vPos.y += pPlane->m_fVel*fCosA;
		}
		else
		{
			pPlane->m_vPos.y -= pPlane->m_fVel*fCosA;
		}
	}
	else if (GET_MARK(mark, MARK_BACKWARD))
	{
        // backward the spaceship.
		if(pPlane->m_dwType == PLANE_USER)
		{
			pPlane->m_vPos.y -= pPlane->m_fVel*fCosA;
		}
		else
		{
			pPlane->m_vPos.y += pPlane->m_fVel*fCosA;		
		}
	}
	else
	{
		// let the plane have a constant velocity when on idle
		if(pPlane->m_dwType == PLANE_USER)
		{
			pPlane->m_vPos.y += m_fViewSpeed*fCosA;
			if(m_fCurrentLinePos > pPlane->m_vPos.y)
			{
				// if the plane is behind the back line, we should align it to the back line 
				pPlane->m_vPos.y = m_fCurrentLinePos;
			}
			
		}
		else
		{
			//pPlane->m_vPos.y -= m_fViewSpeed*fCosA;		
		}
	}
	// set z value and orientation of the plane
	Set3DPositionOf(pPlane);
	
	// fire missile
	if(GET_MARK(mark, MARK_FIRE))
	{
		FireMissile(pPlane);
	}	
}

void CThunderView::EnemyApplyMark()
{
	// 7. For enemy 
	
	// this is the natural laws to create new planes
	static DWORD dwLastTime = 0;
	const DWORD INTERVAL = 2000; // the time interval that a new plane is created
	const int MAX_ENEMY_NUM = 7; // the maxisum enemy numbers on stage

	// we will create a new enemy for every INTERVAl time
	if((timeGetTime()-dwLastTime) > INTERVAL)
	{
		dwLastTime = timeGetTime();
		
		// create only when there aren't too many. and before the back line
		if ((GetListNum(m_pEnemyList) < MAX_ENEMY_NUM) && 
			((m_fCurrentLinePos + m_fMovementRange + DISTANCE) < m_terrain.m_fLength))
		{
			// create a new enemy
			// Just create enemy1
			
			CEnemy* pEnemy = new CEnemy();
			
			static DWORD tempType=0;
			tempType++;
			if(tempType >= m_dwNumShipTypes)
				tempType = 0L;

			pEnemy->m_dwCurrentShipType = tempType;
			pEnemy->m_vPos = m_pPlane->m_vPos;
			pEnemy->m_vPos.y += DISTANCE; 
			
			if(tempType == 0)
			{
				// PLANE_ENEMY1 is big monstor
				pEnemy->m_dwType = PLANE_ENEMY1; 
				pEnemy->m_fSize = 5.0f;
				pEnemy->m_nHealth = 12;
				
				pEnemy->m_dwBulletType = 0x00000001;
				pEnemy->m_fRechargeTime = 100;
				pEnemy->m_fVel = 0.04f;

			}
			else if(tempType == 2)
			{
				// PLANE_ENEMY1 is big monstor
				pEnemy->m_dwType = PLANE_ENEMY1; 
				pEnemy->m_fSize = 5.0f;
				pEnemy->m_nHealth = 12;
				
				pEnemy->m_dwBulletType = 0x00000002;
				pEnemy->m_fRechargeTime = 300;
				pEnemy->m_fVel = 0.04f;

			}
			else if(tempType == 4)
			{
				// PLANE_ENEMY1 is big monstor
				pEnemy->m_dwType = PLANE_ENEMY1; 
				pEnemy->m_fSize = 5.0f;
				pEnemy->m_nHealth = 12;
				
				pEnemy->m_dwBulletType = 0x00000003;
				pEnemy->m_fRechargeTime = 200;
				pEnemy->m_fVel = 0.04f;

			}
			else if(tempType == 1)
			{
				// Enemy2 is light plane
				pEnemy->m_dwType = PLANE_ENEMY2;
				
				pEnemy->m_dwBulletType = 0x00000001;
				pEnemy->m_fRechargeTime = 1000;
				pEnemy->m_fVel = 0.16f;

			}
			else if(tempType == 3)
			{
				// Enemy2 is light plane
				pEnemy->m_dwType = PLANE_ENEMY2;
				
				pEnemy->m_dwBulletType = 0x00000002;
				pEnemy->m_fRechargeTime = 500;
				pEnemy->m_fVel = 0.16f;

			}
			else
			{
				// Enemy2 is light plane
				pEnemy->m_dwType = PLANE_ENEMY2;
				
				pEnemy->m_dwBulletType = 0x00000003;
				pEnemy->m_fRechargeTime = 700;
				pEnemy->m_fVel = 0.16f;

			}

			AddToList(pEnemy, &m_pEnemyList);
		}
	}
	// now we will respond to the marks in the enmey objects

	CBaseObject* pObject = m_pEnemyList;

	while( pObject )
    {
		// any object regardless of its type should be deleted if MARK_DEAD
		if( GET_MARK(pObject->m_dwMark, MARK_DEAD) )
		{
			// so we will start checking the next object
			CBaseObject* pTempObj = pObject->m_pNext;

			// add a large explosion
			ApplyExplosion(pObject);

			DeleteFromList(pObject, &m_pEnemyList);
			
			pObject = pTempObj;
			continue;
		}
		// apply plane mark
		ApplyPlaneMark((CPlane*)pObject);

		pObject = pObject->m_pNext;
    }
}

void CThunderView::MissileApplyMark()
{
	// 5. Move and Check the missile list to see if any missile should be deleted from list
	CBaseObject* pObject = m_pMissileList;
    CMissileTrack msil_track(this);
	CExplosion explosion(this);
    
	while( pObject )
    {
		// any missile regardless of its type should be deleted if MARK_DEAD, or out of terrain
		if( GET_MARK(pObject->m_dwMark, MARK_DEAD) ||
			(pObject->m_vPos.y>=(m_terrain.m_fLength-1.0f)))
		{
			// so we will start checking the next object
			CBaseObject* pTempObj = pObject->m_pNext;

			DeleteFromList(pObject, &m_pMissileList);
			
			pObject = pTempObj;
			continue;
		}
		
		// movement for the MSIL_NORMAL 
		if(pObject->m_dwType == MSIL_NORMAL)
		{
			// move the missile towards the target at a constant velocity
			float rx = ( ((CMissile*)pObject)->m_vTarget.x - ((CMissile*)pObject)->m_vPos.x );
			float ry = ( ((CMissile*)pObject)->m_vTarget.y - ((CMissile*)pObject)->m_vPos.y ); 
			float rs = (float)sqrt(rx*rx + ry*ry);
			
			// set the m_fTransition to 1.0 when missile has nearly reached its target
			// so we can delete the missile later in the mark generating funtion
			if(rs < ((CMissile*)pObject)->m_fVel) 
				((CMissile*)pObject)->m_fTransition = 1.0f;
			
			pObject->m_vPos.x += (rx/rs) * pObject->m_fVel;
			pObject->m_vPos.y += (ry/rs) * pObject->m_fVel;
			
			// Set the object on its 3d terrain 
			Set3DPositionOf(pObject);
		}
		else if(pObject->m_dwType == MSIL_TRACK)
		{
			msil_track.ApplyMark(pObject);
		}
		else if(pObject->m_dwType == EXPLOSION_LARGE)
		{
			explosion.ApplyMark(pObject);
		}

		pObject = pObject->m_pNext;
    }
}

void CThunderView::CameraApply(const char buffer[])
{
	// 3. Move the controlling camera (Notice that this should goes after the user plane model is changed)
	//		no mark is generated in camera, 
	//		indeed we are instantly changing the camera model here
	
	// vShift is a relative vector for the postion of the camera
	// the initials are default shift values of the camera
	static D3DXVECTOR3 vShift(0.0f, -14.5f, -10.5f);
	static D3DXVECTOR3 vAutoShift;
	
	// In auto cameta mode, the height of the eyes changes accroding to the terrain
	if(m_bAutoCamera)
	{

#define OFF_CAMERA_Y	14.5f//7.5f
#define OFF_CAMERA_Z	10.5f//4.5f

		//float fTanA = m_terrain.GetSlope(m_pPlane->m_vPos.y);
		//float fCosA = 1.0f/(float)sqrt(1+(fTanA*fTanA));
		//float fSinA = fTanA/(float)sqrt(1+(fTanA*fTanA));
	
		//vShift.z = -(OFF_CAMERA_Y*fSinA + OFF_CAMERA_Z*fCosA);
		//vShift.y = -(OFF_CAMERA_Y*fCosA - OFF_CAMERA_Z*fSinA);
		//vShift.x = 0.0f;

		float angle = -m_pPlane->m_fAngleX;
		vAutoShift.z = -(OFF_CAMERA_Y*(float)sin(angle) + OFF_CAMERA_Z*(float)cos(angle));
		vAutoShift.y = -(OFF_CAMERA_Y*(float)cos(angle) - OFF_CAMERA_Z*(float)sin(angle));
		vAutoShift.x = 0.0f;

		//set camrea postion
		m_Camera.vPos = vAutoShift + m_pPlane->m_vPos;

		/*		abandoned method
		// an arbitary object for the eye to look at
		CBaseObject obj;
		obj.m_vPos = m_pPlane->m_vPos;
		obj.m_fHeight = m_pPlane->m_fHeight;
		obj.m_vPos.y += VISION_LEN;
		Set3DPositionOf(&obj);
		*/
#define VISION_LEN	-10.0f

		vAutoShift.z = -VISION_LEN*(float)sin(angle);
		vAutoShift.y = -VISION_LEN*(float)cos(angle);

		// look at the obj created above
		m_Camera.vTarget = vAutoShift + m_pPlane->m_vPos;
	
	}
	else
	{
		if (KEYDOWN(buffer, DIK_D))
		{
			// Turn right.
			vShift.x += m_pPlane->m_fVel;
		}
		else if(KEYDOWN(buffer, DIK_A))
		{
			// Turn left.
			vShift.x -= m_pPlane->m_fVel;
		} 
		if (KEYDOWN(buffer, DIK_W))
		{
			// Move the camera forward. 
			vShift.y += m_pPlane->m_fVel;
		}
		else if (KEYDOWN(buffer, DIK_S))
		{
			// backward the camera.
			vShift.y -= m_pPlane->m_fVel;
		}
		if(KEYDOWN(buffer, DIK_X))
		{
			// move down
			vShift.z += m_pPlane->m_fVel;
		}
		//else if(vShift.z>-35.0f)
		else if(KEYDOWN(buffer, DIK_Z))
		{
			// //auto move to a height of 35.0f in negtive z aixs
			// move up 
			vShift.z -= m_pPlane->m_fVel;
		}
		

		//set camrea postion
		m_Camera.vPos = vShift + m_pPlane->m_vPos;
		
		// just look at the plane itself
		m_Camera.vTarget = m_pPlane->m_vPos;
	}

	// set camera orientation
	m_Camera.vUp.x = 0.0f; //(float)sin(m_pPlane->m_fAngleY);
	m_Camera.vUp.y = 1.0f; //(float)cos(m_pPlane->m_fAngleY);
	m_Camera.vUp.z = 0.0f;

}

void CThunderView::SetWeapon(const char buffer[])
{
	// for normal missile
	if(KEYDOWN(buffer, DIK_1))
	{
		m_pPlane->m_dwBulletType &= 0x11111110;
		m_pPlane->m_dwBulletType = 0; // this line should be eliminated later
		m_pPlane->m_dwBulletType |= 0x00000001;
	}
	else if(KEYDOWN(buffer, DIK_2))
	{
		m_pPlane->m_dwBulletType &= 0x11111110;
		m_pPlane->m_dwBulletType = 0; // this line should be eliminated later
		
		m_pPlane->m_dwBulletType |= 0x00000002;
	}
	else if(KEYDOWN(buffer, DIK_3))
	{
		m_pPlane->m_dwBulletType &= 0x11111110;
		m_pPlane->m_dwBulletType = 0; // this line should be eliminated later
		
		m_pPlane->m_dwBulletType |= 0x00000003;
	}

	// for track missile
	if(KEYDOWN(buffer, DIK_4))
	{
		m_pPlane->m_dwBulletType &= 0x11111101;
		m_pPlane->m_dwBulletType = 0; // this line should be eliminated later
		
		m_pPlane->m_dwBulletType |= 0x00000010;
	}
	else if(KEYDOWN(buffer, DIK_5))
	{
		m_pPlane->m_dwBulletType &= 0x11111101;
		m_pPlane->m_dwBulletType = 0; // this line should be eliminated later
		
		m_pPlane->m_dwBulletType |= 0x00000020;
	}
	else if(KEYDOWN(buffer, DIK_6))
	{
		m_pPlane->m_dwBulletType &= 0x11111101;
		m_pPlane->m_dwBulletType = 0; // this line should be eliminated later
		
		m_pPlane->m_dwBulletType |= 0x00000030;
	}
}

float CThunderView::GetDistance(CBaseObject *pObject1, CBaseObject *pObject2)
{
	D3DXVECTOR3 rv = pObject1->m_vPos - pObject2->m_vPos;
	return (float)sqrt(rv.x*rv.x + rv.y*rv.y + rv.z*rv.z);
}

BOOL CThunderView::IsOverlapped(CBaseObject *pObject1, CBaseObject *pObject2)
{
	if ( GetDistance(pObject1, pObject2) < (pObject1->m_fSize+pObject2->m_fSize) )
		return TRUE;
	else
		return FALSE;
}


void CAMERA::CaculateParam()
{
	D3DXMatrixLookAtLH( &matView, &vPos, &vTarget, &vUp );
	D3DXMatrixInverse( &matBillboard, NULL, &matView );
    matBillboard._41 = 0.0f;
    matBillboard._42 = 0.0f;
    matBillboard._43 = 0.0f;

}

void CThunderView::OnGameOption() 
{
	CDlgOption dlg;
	dlg.m_strTerrain = m_strTerrain;
	dlg.m_strMissile = m_strMissile;
	dlg.m_strParentPath = m_strSearchPath;
	dlg.m_bAutoCamera = m_bAutoCamera;
	dlg.m_fFPS = m_fMyFPS;
	
	if(m_fMyFPS == 0.0f)
	{
		dlg.m_bUnLimitedSpeed = TRUE;
	}
	else
	{
		dlg.m_bUnLimitedSpeed = FALSE;
	}
	
	if(dlg.DoModal()==IDOK)
	{
		m_strTerrain = dlg.m_strTerrain;
		m_strMissile = dlg.m_strMissile;
		m_strSearchPath = dlg.m_strParentPath;
		m_bAutoCamera = dlg.m_bAutoCamera;
		m_fMyFPS = dlg.m_fFPS;
		if(dlg.m_bUnLimitedSpeed)
		{
			m_fMyFPS = 0.0f;
		}
	}
}

//-----------------------------------------------------------------------------
// Name: D3DUtil_SetColorKey()
// Desc: Changes all texels matching the colorkey to transparent, black.
//-----------------------------------------------------------------------------
HRESULT CThunderView::D3DUtil_SetColorKey( LPDIRECT3DTEXTURE8 pTexture, DWORD dwColorKey )
{
    // Get colorkey's red, green, and blue components
    DWORD r = ((dwColorKey&0x00ff0000)>>16);
    DWORD g = ((dwColorKey&0x0000ff00)>>8);
    DWORD b = ((dwColorKey&0x000000ff)>>0);

    // Put the colorkey in the texture's native format
    D3DSURFACE_DESC d3dsd;
    pTexture->GetLevelDesc( 0, &d3dsd );
    if( d3dsd.Format == D3DFMT_A4R4G4B4 )
        dwColorKey = 0xf000 + ((r>>4)<<8) + ((g>>4)<<4) + (b>>4);
    else if( d3dsd.Format == D3DFMT_A1R5G5B5 )
        dwColorKey = 0x8000 + ((r>>3)<<10) + ((g>>3)<<5) + (b>>3);
    else if( d3dsd.Format != D3DFMT_A8R8G8B8 )
        return E_FAIL;

    // Lock the texture
    D3DLOCKED_RECT  d3dlr;
    if( FAILED( pTexture->LockRect( 0, &d3dlr, 0, 0 ) ) )
        return E_FAIL;

    // Scan through each pixel, looking for the colorkey to replace
    for( DWORD y=0; y<d3dsd.Height; y++ )
    {
        for( DWORD x=0; x<d3dsd.Width; x++ )
        {
            if( d3dsd.Format==D3DFMT_A8R8G8B8 )
            {
                // Handle 32-bit formats
                if( ((DWORD*)d3dlr.pBits)[d3dsd.Width*y+x] == dwColorKey )
                    ((DWORD*)d3dlr.pBits)[d3dsd.Width*y+x] = 0x00000000;
            }
            else
            {
                // Handle 16-bit formats
                if( ((WORD*)d3dlr.pBits)[d3dsd.Width*y+x] == dwColorKey )
                    ((WORD*)d3dlr.pBits)[d3dsd.Width*y+x] = 0x0000;
            }
        }
    }

    // Unlock the texture and return OK.
    pTexture->UnlockRect(0);
    return S_OK;
}

void CThunderView::SafeReleaseList(CBaseObject **ppList)
{
	CBaseObject * pObject = *ppList;
	while( pObject )
	{
		CBaseObject* pTempObj = pObject->m_pNext;

		DeleteFromList(pObject, ppList);
		
		pObject = pTempObj;
	}
}

int CThunderView::GetMissile(DWORD dwType)
{
	return 0;
}

// not only for enemy planes and user missiles derived from CPlane and CMissile respectively
// the return value is only used when the plane is the user plane
// , indicating whether the user is collapsed
BOOL CThunderView::HitMarks(CBaseObject *pPlane, CBaseObject *pMissile)
{
	// The missile hits the plane
	// the missile is dead no doubt
	pMissile->m_dwMark = MARK_DEAD;
	
	// the plane depends on its health after the damage
	if( (((CPlane*)pPlane)->m_nHealth -= ((CMissile*)pMissile)->m_nAttackPoint) <= 0)
	{
		pPlane->m_dwMark = MARK_DEAD;
		
	}
	else
	{
		// add a small bomb image here, since the plane is damaged but not dead

	}
	
	if(pPlane->m_dwType == PLANE_USER)
	{
		// it's the user who dead , so we will set the return value carefully
		if(pPlane->m_dwMark == MARK_DEAD)
		{
			return TRUE; // crashed
		}
		else
		{
			return FALSE; // duerable
		}
	}
	
	return FALSE;
}

void CThunderView::PauseGame()
{
	if(m_nGameState != GAME_UNINITIALIZED)
		m_nGameState = GAME_PAUSED;
	
	// show flash
	SetFlashStatus(FLASH_ABOUT);
}

void CThunderView::ResumeGame()
{
	// we hide the flash to allow normal rendering
	SetFlashStatus(FLASH_HIDE);
	
	if(m_nGameState != GAME_UNINITIALIZED)
		m_nGameState = GAME_RUNNING;

}

void CThunderView::ApplyExplosion(CBaseObject *pPlane)
{
	// add a large bomb image where the plane is collapsed
	CMissile* pExplosion = new CMissile();
	pExplosion->m_nManufactory = ENEMY;
	pExplosion->m_dwType = EXPLOSION_LARGE;
	pExplosion->m_vPos = pPlane->m_vPos;
	pExplosion->m_fSize = pPlane->m_fSize;
	
	AddToList((CBaseObject*)(pExplosion), (CBaseObject**)(&m_pMissileList));
	PlaySound(SOUND_BOMB);
}

void CThunderView::OnGameTerrainedit() 
{
	PauseGame();
	
	CDlgTerrainEdit dlg;
	dlg.m_strSearchPath = m_strSearchPath + _T("\\");
	dlg.m_pTerrain = &m_terrain;
	
	dlg.m_fWidth = m_terrain.m_fWidth;
	dlg.m_fLength = m_terrain.m_fLength;
	dlg.m_nSegment = m_terrain.m_nSegment;
	dlg.m_fMaxHeight  = m_terrain.m_fMaxHeight;
	
	dlg.DoModal();
	
	if( dlg.IsModified())
	{
		// Restart the game, since terrain has been modified 
		LoadTerrainBuffer();
		Restart();
	}
}

void CThunderView::OnGameEditmap() 
{
	CString str = m_strSearchPath + _T("\\editmap.exe");
	WinExec(str, SW_SHOWMAXIMIZED);	
}

HRESULT CThunderView::OneTimeSceneInit()
{
	// set plane original point
	if(m_pPlane == NULL)
		m_pPlane = new CPlane();
	m_pPlane->m_vPos = D3DXVECTOR3(10.0f, 1.0f, - 1.0f);
	m_pPlane->m_dwType = PLANE_USER;

	// init camera
	m_Camera.vPos = D3DXVECTOR3(10.0f, 1.0f, -35.0f);
	
	// 5. load enemy's plane
	m_pEnemyList = NULL;

	// 6. load terrian
	
	if(!m_terrain.m_pData)
	{
		m_terrain.CreateRandomTerrain();
	}

	// 7. load missile model
	m_pMissileList = NULL;
	////////////////////////////////////////////////////////////////////////////
	// 2. Initialize the DirectAudio stuff
	
	// I donot know why the directx doesnot offer a none COM style in Direct Audio
	CoInitialize(NULL);
    
    
	CoCreateInstance(CLSID_DirectMusicLoader, NULL, 
                     CLSCTX_INPROC, IID_IDirectMusicLoader8,
                     (void**)&m_pLoader);
	
	CoCreateInstance(CLSID_DirectMusicPerformance, NULL,
                     CLSCTX_INPROC, IID_IDirectMusicPerformance8,
                     (void**)&m_pPerformance );
	m_pPerformance->InitAudio( 
        NULL,                  // IDirectMusic interface not needed.
        NULL,                  // IDirectSound interface not needed.
        NULL,                  // Window handle.
        DMUS_APATH_SHARED_STEREOPLUSREVERB,  // Default audiopath type.
        64,                    // Number of performance channels.
        DMUS_AUDIOF_ALL,       // Features on synthesizer.
        NULL                   // Audio parameters; use defaults.
    );

	// CONVERT to WCHAR
	CString str = m_strSearchPath + _T("\\media");
	WCHAR strSearchPath[100];	
	MultiByteToWideChar( CP_ACP, 0, str, -1, 
                         strSearchPath, str.GetLength() );
    strSearchPath[str.GetLength()] = 0;


	m_pLoader->SetSearchDirectory( 
        GUID_DirectMusicAllTypes,   // Types of files sought.
        strSearchPath,             // Where to look.
        FALSE                       // Don't clear object data.
    );
	
	for(int i=0; i<END_SOUND; i++)
	{
		if (FAILED(m_pLoader->LoadObjectFromFile(
			CLSID_DirectMusicSegment,   // Class identifier.
			IID_IDirectMusicSegment8,   // ID of desired interface.
			m_strSoundFiles[i],               // Filename.
			(LPVOID*) &m_pSegment[i])))       // Pointer that receives interface.
		{
			::MessageBox( NULL, _T("Media not found, sample will now quit."), 
							  _T("TS"), MB_OK );
			return D3D_FAILED;
		}
		m_pSegment[i]->Download( m_pPerformance );

	}
	//PlaySound(BEGINLEVEL); // try one of the sound here
	
    // 3. Initialize the DirectInput stuff
	 
	if FAILED(DirectInput8Create(AfxGetInstanceHandle(), DIRECTINPUT_VERSION, 
			IID_IDirectInput8, (void**)&m_lpDI, NULL)) 
	{ 
		// DirectInput not available; take appropriate action 
		return D3D_FAILED;
	} 

	if FAILED(m_lpDI->CreateDevice(GUID_SysKeyboard, &m_lpDIDevice, NULL)) 
	{ 
		return D3D_FAILED; 
	} 

	if FAILED(m_lpDIDevice->SetDataFormat(&c_dfDIKeyboard)) 
	{ 
		return D3D_FAILED; 
	} 
	// Set the cooperative level 
	HRESULT hr = m_lpDIDevice->SetCooperativeLevel(GetSafeHwnd(), 
					   DISCL_FOREGROUND | DISCL_NONEXCLUSIVE); 
 
	if (FAILED(hr)) 
	{ 
		// we take no notice of the return value in this simple game
		//return D3D_FAILED; 
	} 
	
	if (m_lpDIDevice) m_lpDIDevice->Acquire(); 
    
	////////////////////////////////////////////////////////////////////////////////
	// 6. load terrian
	
	if(!m_terrain.m_pData)
	{
		m_terrain.CreateRandomTerrain();
	}
	
	LoadTerrainBuffer();

	/*  Old simple terrain generator
	const float col_height = 6.6f;
	const float col_width = m_fWidth/3.0f;
	const int num_col = (int)(m_fLength/(col_height*2));
	tarin_num = 4*num_col*2;
	
	m_pTerrainBuffer = new DEFAULTVERTEX[tarin_num];
	
	// use uniform color and on a flat plane
	for(i=0;i<tarin_num; i++)
	{
		m_pTerrainBuffer[i].color = D3DCOLOR_XRGB(0xff,0xff,0xff); //white
		m_pTerrainBuffer[i].z = 0.0f;
	}

	for(int col=0; col<num_col; col++)
	{
		m_pTerrainBuffer[4*col+0].x = 0.0f;
		m_pTerrainBuffer[4*col+0].y = 0.0f + col*(col_height*2);
		
		m_pTerrainBuffer[4*col+1].x = col_width;
		m_pTerrainBuffer[4*col+1].y = 0.0f + col*(col_height*2);

		m_pTerrainBuffer[4*col+2].x = col_width;
		m_pTerrainBuffer[4*col+2].y = 0.0f + col*(col_height*2)+col_height;

		m_pTerrainBuffer[4*col+3].x = 0.0f;
		m_pTerrainBuffer[4*col+3].y = 0.0f + col*(col_height*2)+col_height;
	}

	for(col=0; col<num_col; col++)
	{
		m_pTerrainBuffer[4*col+4*num_col+0].x = col_width*2;
		m_pTerrainBuffer[4*col+4*num_col+0].y = m_fLength - col*(col_height*2);
		
		m_pTerrainBuffer[4*col+4*num_col+1].x = col_width*3;
		m_pTerrainBuffer[4*col+4*num_col+1].y = m_fLength -col*(col_height*2);

		m_pTerrainBuffer[4*col+4*num_col+2].x = col_width*3;
		m_pTerrainBuffer[4*col+4*num_col+2].y = m_fLength -(col*(col_height*2)+col_height);

		m_pTerrainBuffer[4*col+4*num_col+3].x = col_width*2;
		m_pTerrainBuffer[4*col+4*num_col+3].y = m_fLength -(col*(col_height*2)+col_height);
	}

	Old simple terrain generator*/

	/*
	hr = D3DXCreateBox(m_pd3dDevice, 1.1f, 1.1f, 1.1f, &m_pMissileMesh, NULL);
	if FAILED(hr) { 
		// we take no notice of the return value in this simple game
		return D3D_FAILED; 
	} 
	*/
	
	// this is another way to load missile buffer
	float width = 1.0f/nCol;
	float height = 1.0f/nRow;

	// we create a texture buffer for each unit
	m_pMissileBuffer = new TEXTVERTEX[msil_num*nCol*nRow];

	// for normal missles of the user and the enemy
	const int nKindOfMisl = 2; // all in the first row
	for(i=0; i<nKindOfMisl; i++ )
	{
		m_pMissileBuffer[i*msil_num+0].x = -0.1f;
		m_pMissileBuffer[i*msil_num+0].y = -0.1f;
		m_pMissileBuffer[i*msil_num+0].z = 0.0f;
		
		m_pMissileBuffer[i*msil_num+1].x = 0.1f;
		m_pMissileBuffer[i*msil_num+1].y = -0.1f;
		m_pMissileBuffer[i*msil_num+1].z = 0.0f;
		
		m_pMissileBuffer[i*msil_num+2].x = -0.1f;
		m_pMissileBuffer[i*msil_num+2].y = 0.1f;
		m_pMissileBuffer[i*msil_num+2].z = 0.0f;
		
		
		m_pMissileBuffer[i*msil_num+3].x = 0.1f;
		m_pMissileBuffer[i*msil_num+3].y = 0.1f;
		m_pMissileBuffer[i*msil_num+3].z = 0.0f;
	
		// texture coordinates at (0, i)
		m_pMissileBuffer[i*msil_num+0].tu = i *width;
		m_pMissileBuffer[i*msil_num+0].tv = 1 *height;

		m_pMissileBuffer[i*msil_num+1].tu = width*(i+1);
		m_pMissileBuffer[i*msil_num+1].tv = 1 *height;

		m_pMissileBuffer[i*msil_num+2].tu = width*i;
		m_pMissileBuffer[i*msil_num+2].tv = 0 *height;
	
		m_pMissileBuffer[i*msil_num+3].tu = width*(i+1);
		m_pMissileBuffer[i*msil_num+3].tv = 0 *height;

		for(int j=0;j<msil_num; j++)
		{
			m_pMissileBuffer[i*msil_num+j].color = 0xffffffff;
		}
	}

	// for explosion 
	int nOffSet = nCol*msil_num;
	
	for(i=0; i<EXPLOSION_FRAMES; i++ )
	{
		m_pMissileBuffer[nOffSet + i*msil_num+0].x = -1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+0].y = -1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+0].z = 0.0f;
		
		m_pMissileBuffer[nOffSet + i*msil_num+1].x = 1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+1].y = -1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+1].z = 0.0f;
		
		m_pMissileBuffer[nOffSet + i*msil_num+2].x = -1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+2].y = 1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+2].z = 0.0f;
		
		
		m_pMissileBuffer[nOffSet + i*msil_num+3].x = 1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+3].y = 1.0f;
		m_pMissileBuffer[nOffSet + i*msil_num+3].z = 0.0f;
	
		// texture coordinates at (1, i)
		m_pMissileBuffer[nOffSet + i*msil_num+0].tu = i *width;
		m_pMissileBuffer[nOffSet + i*msil_num+0].tv = 2 *height;

		m_pMissileBuffer[nOffSet + i*msil_num+1].tu = width*(i+1);
		m_pMissileBuffer[nOffSet + i*msil_num+1].tv = 2 *height;

		m_pMissileBuffer[nOffSet + i*msil_num+2].tu = width*i;
		m_pMissileBuffer[nOffSet + i*msil_num+2].tv = 1 *height;
	
		m_pMissileBuffer[nOffSet + i*msil_num+3].tu = width*(i+1);
		m_pMissileBuffer[nOffSet + i*msil_num+3].tv = 1 *height;

		for(int j=0;j<msil_num; j++)
		{
			m_pMissileBuffer[nOffSet + i*msil_num+j].color = 0xffffffff;
		}
	}

	return S_OK;	
}

HRESULT CThunderView::InitDeviceObjects()
{
	// Initialize the font's internal textures
    m_pFont->InitDeviceObjects( m_pd3dDevice );

	
	return S_OK;
}

HRESULT CThunderView::FrameMove()
{
	Controller();
	
	return S_OK;
}

HRESULT CThunderView::DeleteDeviceObjects()
{
    m_pFont->DeleteDeviceObjects();

	// destory the user plane object
	
	for(int i=0; i<(int)m_dwNumShipTypes; i++)
	{
		if(m_pPlaneMesh[i])
		{
			m_pPlaneMesh[i]->Destroy();
			SAFE_DELETE( m_pPlaneMesh[i] );
		}
	}
	
	// release texture
	SAFE_RELEASE( m_pTexture1 );
	SAFE_RELEASE( m_pTexture2 );
	
	
	return S_OK;
}

HRESULT CThunderView::FinalCleanup()
{
	SAFE_DELETE( m_pFont );
    
	// destroy terrian buffer
	SAFE_DELETE(m_pTerrainBuffer);
	
	// destroy the missile objects
	SAFE_DELETE(m_pMissileBuffer);

	// release all missiles and planes
	SAFE_DELETE( m_pPlane);
	
	SafeReleaseList(&m_pEnemyList);
	SafeReleaseList(&m_pMissileList);

	// Release all the directinput objects
	if (m_lpDI) 
    { 
        if (m_lpDIDevice) 
        { 
        // Always unacquire device before calling Release(). 
            m_lpDIDevice->Unacquire(); 
            m_lpDIDevice->Release();
            m_lpDIDevice = NULL; 
        } 
        m_lpDI->Release();
        m_lpDI = NULL; 
    } 

	// destory sound object
	if(m_pPerformance)
	{
		m_pPerformance->Stop(
			NULL,   // Stop all segments.
			NULL,   // Stop all segment states.
			0,      // Do it immediately.
			0       // Flags.
		);
 
		m_pPerformance->CloseDown();
 
		m_pLoader->Release(); 
		m_pPerformance->Release();
		for(int i=0; i<END_SOUND; i++)
			m_pSegment[i]->Release();
 
		CoUninitialize();
	}		
	return S_OK;
}

//-----------------------------------------------------------------------------
// Name: FullScreenWndProc()
// Desc: The WndProc funtion used when the app is in fullscreen mode. This is
//       needed simply to trap the ESC key.
//-----------------------------------------------------------------------------
LRESULT CALLBACK FullScreenWndProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    if( msg == WM_CLOSE )
    {
        // User wants to exit, so go back to windowed mode and exit for real
        //::MessageBox(NULL, "FullScreenWndProc WM_CLOSE is called once", NULL, MB_OK); //lxz
	
		g_AppView->OnToggleFullscreen();
        AfxGetMainWnd()->PostMessage( WM_CLOSE, 0, 0 );
    }

    else if( msg == WM_SETCURSOR )
    {
        SetCursor( NULL );
    }

    /* Since MFC use HOOK technoledge, the MAINFRAME will also reveice 
		a copy of keystrokes even if the message is dispatched to the POP window
		when running in FullScreen, therefore we donot manage the 
		menu triggling here.

	else if( msg == WM_KEYUP && wParam == VK_ESCAPE )
    {
        // User wants to leave fullscreen mode
        g_AppView->OnToggleFullscreen();
    }
	else if( msg == WM_KEYUP && wParam == VK_F2 )
    {
        // User wants to leave fullscreen mode
        g_AppView->OnGameBegin();
    }
	*/
    return DefWindowProc( hWnd, msg, wParam, lParam );
}


void CThunderView::OnToggleFullscreen()
{
	// we will hide the flash window regardless of whether we are toggling fullscreen or not
	SetFlashStatus(FLASH_HIDE);
	
	if(m_nGameState != GAME_UNINITIALIZED)
		ToggleFullscreen();
}

void CThunderView::RenderScene()
{
	Render3DEnvironment();
}

void CThunderView::OnGameDevice() 
{
	// we will hide the flash window regardless of settings
	SetFlashStatus(FLASH_HIDE);

	if(m_nGameState != GAME_UNINITIALIZED)
		UserSelectNewDevice();
}

void CThunderView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// Register a class for a fullscreen window
	WNDCLASS wndClass = { CS_HREDRAW | CS_VREDRAW, FullScreenWndProc, 0, 0, NULL,
						  NULL, NULL, (HBRUSH)GetStockObject(WHITE_BRUSH), NULL,
						  _T("Fullscreen Window") };
	RegisterClass( &wndClass );

	// We create the fullscreen window (not visible) at startup, so it can
	// be the focus window.  The focus window can only be set at CreateDevice
	// time, not in a Reset, so ToggleFullscreen wouldn't work unless we have
	// already set up the fullscreen focus window.
	m_hwndRenderFullScreen = CreateWindow( _T("Fullscreen Window"), NULL,
										   WS_POPUP, CW_USEDEFAULT,
										   CW_USEDEFAULT, 100, 100,
										   GetTopLevelParent()->GetSafeHwnd(), 0L, NULL, 0L );

	m_hwndRenderWindow = CWnd::m_hWnd;
	CD3DApplication::m_hWnd = m_hwndRenderWindow;
	CD3DApplication::m_hWndFocus = m_hwndRenderFullScreen;
	HRESULT hr = CD3DApplication::Create( AfxGetInstanceHandle() );
	if(FAILED(hr))
	{
		::MessageBox( NULL, _T("You computer doesn't support some of the directx 8.0 features needed by this game."), 
			_T("Thunder Storm"), MB_ICONERROR|MB_OK );
	}
	else
	{
		// we have successfully created the game
		m_nGameState = GAME_INIT;
		// turn the following line on,when you want to jump to FULLSCREEN at startup
		//OnGameToggleView();
	}
	
	// play flash
	
	// add show flash window here
	CRect rect;
	GetClientRect(&rect);
	m_wndFlashShow.Create(NULL, NULL, WS_CHILD|WS_VISIBLE, rect, this, 777);
	m_nFlashStatus = FLASH_HIDE;
	
	SetFlashStatus(FLASH_INIT);
}

HRESULT CThunderView::AdjustWindowForChange()
{
	if( m_bWindowed )
    {
        ::ShowWindow( m_hwndRenderFullScreen, SW_HIDE );
        CD3DApplication::m_hWnd = m_hwndRenderWindow;
    }
    else
    {
        if( ::IsIconic( m_hwndRenderFullScreen ) )
            ::ShowWindow( m_hwndRenderFullScreen, SW_RESTORE );
        ::ShowWindow( m_hwndRenderFullScreen, SW_SHOW );
        CD3DApplication::m_hWnd = m_hwndRenderFullScreen;
    }
    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device intialization, this code checks the device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CThunderView::ConfirmDevice( D3DCAPS8* pCaps, DWORD dwBehavior,
                                          D3DFORMAT Format )
{
    // This sample uses alpha textures and/or straight alpha. Make sure the
    // device supports them
    if( pCaps->TextureCaps & D3DPTEXTURECAPS_ALPHAPALETTE )
        return S_OK;
    if( pCaps->TextureCaps & D3DPTEXTURECAPS_ALPHA )
        return S_OK;

    return E_FAIL;
}

//-----------------------------------------------------------------------------
// Name: CheckForLostFullscreen()
// Desc: If fullscreen and device was lost (probably due to alt-tab), 
//       automatically switch to windowed mode
//-----------------------------------------------------------------------------
HRESULT CThunderView::CheckForLostFullscreen()
{
    HRESULT hr;

    if( m_bWindowed )
        return S_OK;

    if( FAILED( hr = m_pd3dDevice->TestCooperativeLevel() ) )
        ForceWindowed();

    return S_OK;
}


BOOL CThunderView::IsReady()
{
	if(m_nGameState != GAME_UNINITIALIZED)
		return TRUE;
	return FALSE;
}

void CThunderView::OnGameToggleView() 
{
	OnToggleFullscreen();	
}

HRESULT CThunderView::RestoreDeviceObjects()
{
	m_pFont->RestoreDeviceObjects();

	// 4.1 Load texture from file
	CString path =  m_strSearchPath + _T("\\Media\\") + m_strMissile;
	
	if( FAILED( D3DXCreateTextureFromFile( m_pd3dDevice, path.GetBuffer(100),
                                       &m_pTexture1 ) ) )
		return E_FAIL;
	path.ReleaseBuffer();

	//D3DUtil_SetColorKey(m_pTexture1, 0x00000000);

	path =  m_strSearchPath + _T("\\Media\\") + m_strTerrain;
	if( FAILED( D3DXCreateTextureFromFile( m_pd3dDevice, path.GetBuffer(100),
                                       &m_pTexture2 ) ) )
		return E_FAIL;
	path.ReleaseBuffer();

	// 4.2 load user's plane 

	ReloadPlane();

	// set a directional light
	D3DXVECTOR3 vecDir;
	D3DLIGHT8 light;
	ZeroMemory( &light, sizeof(D3DLIGHT8) );
	light.Type       = D3DLIGHT_DIRECTIONAL;

	light.Diffuse.r  = 1.0f;
	light.Diffuse.g  = 1.0f;
	light.Diffuse.b  = 1.0f;

	vecDir = D3DXVECTOR3(1.0f, -1.0f, 1.0f);
	D3DXVec3Normalize( (D3DXVECTOR3*)&light.Direction, &vecDir );
	light.Range       = 1000.0f;
	HRESULT hr = m_pd3dDevice->SetLight( 0, &light );
    m_pd3dDevice->LightEnable( 0, TRUE );
	if FAILED(hr) { 
		// we take no notice of the return value in this simple game
		return D3D_FAILED; 
	} 
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_AMBIENT, 0x33333333 );
	m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

	return S_OK;
}

HRESULT CThunderView::InvalidateDeviceObjects()
{
    m_pFont->InvalidateDeviceObjects();

	// destory the user plane object
	
	for(int i=0; i<(int)m_dwNumShipTypes; i++)
	{
		if(m_pPlaneMesh[i])
		{
			m_pPlaneMesh[i]->Destroy();
			SAFE_DELETE( m_pPlaneMesh[i] );
		}
	}
	
	// release texture
	SAFE_RELEASE( m_pTexture1 );
	SAFE_RELEASE( m_pTexture2 );
	
	return S_OK;
}

void CThunderView::AddUserBonus(int nHealth, int nScore)
{
	m_pPlane->m_nHealth += nHealth;
	m_nScore += nScore;
}

void CThunderView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// resize the flash window
	if(m_nFlashStatus != FLASH_UNINITIALIZED)
	{
		m_wndFlashShow.SetWindowPos(NULL, 0, 0, cx, cy, SWP_NOMOVE|SWP_NOZORDER );
	}

	if( m_bActive && m_bWindowed )
	{
		HRESULT hr;
	
		RECT rcClientOld;
		rcClientOld = m_rcWindowClient;

		// Update window properties
		::GetWindowRect( CWnd::m_hWnd, &m_rcWindowBounds );
		::GetClientRect( CWnd::m_hWnd, &m_rcWindowClient );

		if( rcClientOld.right - rcClientOld.left !=
			m_rcWindowClient.right - m_rcWindowClient.left ||
			rcClientOld.bottom - rcClientOld.top !=
			m_rcWindowClient.bottom - m_rcWindowClient.top)
		{
			// A new window size will require a new backbuffer
			// size, so the 3D structures must be changed accordingly.
			m_bReady = FALSE;

			m_d3dpp.BackBufferWidth  = m_rcWindowClient.right - m_rcWindowClient.left;
			m_d3dpp.BackBufferHeight = m_rcWindowClient.bottom - m_rcWindowClient.top;

			// Resize the 3D environment
			if( FAILED( hr = Resize3DEnvironment() ) )
			{
				DisplayErrorMsg( D3DAPPERR_RESIZEFAILED, MSGERR_APPMUSTEXIT );
				return;
			}

			m_bReady = TRUE;
		}
	}
}

void CThunderView::OnAppExit() 
{
	//MessageBox("exit th code");
}

// check m_fMyFPS to see whether we have waited long enough to render the next scene, by now
BOOL CThunderView::IsTimeToRender()
{
	static float fElapsedTime = 0;
	
	if(m_nFlashStatus != FLASH_HIDE)
	{
		// we render directx only when the flash show is hidden
		return FALSE;
	}
	// Unlimited speed
	if(m_fMyFPS == 0.0f)
	{
		return TRUE;
	}
	
	// limited speed
	float fCurrentTime = (float)timeGetTime();
	
	if( (fCurrentTime-fElapsedTime) > (1000/m_fMyFPS))
	{
		fElapsedTime = fCurrentTime;
		return TRUE;
	}
	else
	{
		return FALSE;
	};
}

HRESULT CThunderView::LoadTerrainBuffer()
{
	if(m_pTerrainBuffer)
		delete m_pTerrainBuffer;
	m_pTerrainBuffer = NULL;

	m_pTerrainBuffer = new TEXTVERTEX[(m_terrain.m_nSegment+1)*2];
	
	// there is #(m_nSegment+1)# lines
	LINE* pData = m_terrain.m_pData;
	for(int i=0; i<(m_terrain.m_nSegment+1); i++)
	{
		m_pTerrainBuffer[i*2].color = pData[i].dwColor;
		m_pTerrainBuffer[i*2].x = 0.0f;
		m_pTerrainBuffer[i*2].y = pData[i].fY;
		m_pTerrainBuffer[i*2].z = -pData[i].fHeight;
		
		m_pTerrainBuffer[i*2+1].color = pData[i].dwColor;
		m_pTerrainBuffer[i*2+1].x = m_terrain.m_fWidth;
		m_pTerrainBuffer[i*2+1].y = pData[i].fY;
		m_pTerrainBuffer[i*2+1].z = -pData[i].fHeight;

		if((float)i/2.0f-i/2 == 0.0f)
		{
			m_pTerrainBuffer[i*2].tu = 0.0f;
			m_pTerrainBuffer[i*2].tv = 0.0f;

			m_pTerrainBuffer[i*2+1].tu = 1.0f;
			m_pTerrainBuffer[i*2+1].tv = 0.0f;
		}
		else
		{
			m_pTerrainBuffer[i*2].tu = 0.0f;
			m_pTerrainBuffer[i*2].tv = 1.0f;

			m_pTerrainBuffer[i*2+1].tu = 1.0f;
			m_pTerrainBuffer[i*2+1].tv = 1.0f;
		}

	}
	return TRUE;
}

void CThunderView::AnnounceVictory()
{
	if(m_nGameState != GAME_UNINITIALIZED)
		m_nGameState = GAME_VICTORY;	
}

BOOL CThunderView::TryRender()
{
	if( IsReady() && IsTimeToRender())
    {
		// normal directx render
		CheckForLostFullscreen();
        RenderScene();
		return TRUE;
	}
	else
	{
		// render flash show
		return FALSE;
		//TryFlash();
	}
	
}

BOOL CThunderView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	
	return CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
}

void CThunderView::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CView::OnKeyUp(nChar, nRepCnt, nFlags);
}

void CThunderView::TryFlash()
{
	if(m_nFlashStatus != FLASH_UNINITIALIZED)
	{
		// the flash is ready to render
		if(m_nFlashStatus != FLASH_HIDE)
		{
			if( ! m_wndFlashShow.IsPlaying() )
			{
				//------------------------------------------------
				// Since the flash isn't playing, we will start playing a segment
				// according to its status
				//------------------------------------------------
				switch (m_nFlashStatus)
				{
				case FLASH_INIT:
					break;
				case FLASH_ABOUT:
					break;
				}
			}
		}
	}
}

void CThunderView::SetFlashStatus(int nStatus)
{
	// this would take no effect if the flash movie hasn't been initialized,
	// or we are running under fullscreen
	if((m_nFlashStatus == FLASH_UNINITIALIZED) ||
		(!m_bWindowed) )
		return;

	// stop the current flash show, since we are loading new ones or none
	m_wndFlashShow.Stop();
	
	CString path =  m_strSearchPath + _T("\\Media\\");
	path += _T("54.bos");
	m_wndFlashShow.SetMovie(path);
	m_wndFlashShow.Play();
	m_wndFlashShow.Stop();
	
	m_nFlashStatus = nStatus;
	
	if(m_nFlashStatus == FLASH_HIDE)
	{
		return;
	}
	
	// updateWindow
	m_wndFlashShow.InvalidateRect(NULL);
	m_wndFlashShow.UpdateWindow();

	path =  m_strSearchPath + _T("\\Media\\");
	switch (m_nFlashStatus)
	{
	case FLASH_INIT:
		{
			path += _T("init.bos");
			m_wndFlashShow.SetMovie(path);
			m_wndFlashShow.SetLoop(TRUE);
			m_wndFlashShow.Play();
			break;
		}
	case FLASH_ABOUT:
		{
			path += _T("daojishi.bos");
			m_wndFlashShow.SetMovie(path);
			m_wndFlashShow.SetLoop(TRUE);
			m_wndFlashShow.Play();
			break;
		}
	case FLASH_BONUS:
		{
			/* the following are the old way
			//-------------------------------------------------
			// play next flash movies stored in a the media path.
			// the file sould follow certain standard: 
			// they must be 00.swf,01.swf, 02.swf, ...., 99.swf
			// in increasing order, without any gap in between
			//-------------------------------------------------

			// this designate the nInJ.swf 
			static int nI = 0;
			static int nJ = 0;
			
			// move to the next file
			
			// decimal(10) is assumed
			if((nJ+1) >= 10)
			{
				nI++;
				nJ = (nJ+1) - 10;
			}

			TCHAR fileName[20];
			FORMAT_TEXT(fileName, _T("%d%d.swf"), nI, nJ);
			path =  m_strSearchPath + _T("\\Media\\") + fileName;
			
			// try open the file
			CFile file;
			if(file.Open(path, CFile::modeRead))
			{
				// successfully opened the file
				file.Close();
			}
			else
			{
				// we have come past the last file, so rewind to 00.swf
				nI = nJ = 0;
				FORMAT_TEXT(fileName, _T("%d%d.swf"), nI, nJ);
				path =  m_strSearchPath + _T("\\Media\\") + fileName;
				
				if(file.Open(path, CFile::modeRead))
				{
					// successfully opened the file
					file.Close();
				}
				else
					// failed to open the file
					path = _T("");
			}

			if(path != _T(""))
			{
				// we set and play the movie
				m_wndFlashShow.SetMovie(path);
				m_wndFlashShow.SetLoop(TRUE);
				m_wndFlashShow.Play();
			}
			*/
			
			static BOOL bRestart = TRUE;
			
			if( bRestart )
			{
				path =  m_strSearchPath + _T("\\Media\\*.bos"); 
				bRestart = (m_fileFlash.FindFile(path)) ? FALSE:TRUE;
			}

			BOOL bIsLastFile = (m_fileFlash.FindNextFile() ==0)?TRUE:FALSE;
			
			// we have found a flash show. so play it
			// we set and play the movie
			m_wndFlashShow.SetMovie(m_fileFlash.GetFileURL());
			m_wndFlashShow.SetLoop(TRUE);
			m_wndFlashShow.Play();

			if(bIsLastFile)
			{
				// we will restart the search next time if this is the last match
				m_fileFlash.Close();
				bRestart = TRUE;
			}
		}
	}
}

void CThunderView::OnHelpInstructions() 
{
	if(m_nGameState != GAME_UNINITIALIZED)
		m_nGameState = GAME_INIT;	
	SetFlashStatus(FLASH_HIDE);
}

void CThunderView::OnBonusNext() 
{
	SetFlashStatus(FLASH_BONUS);	
}

//---------------------------------------------
// Encode method:
//	1.Mask off the *.swf file extension by *.bos(designating Bonus)
//	2.Mask off the first few segments(BYTES) of each file by the value 
//		stored in FlashCode[CODE_LEN]
//	3.add end code to the end of the file
//----------------------------------------------
#define CODE_LEN	4
BYTE FlashMaskCode[CODE_LEN] = {0x12,0x34,0x56,0x78};
BYTE FlashEndCode[CODE_LEN] = {0xff,0x00,0x00,0xff};

void CThunderView::EncodeFlashFile()
{
	// change any *.swf to *.bos
	CString path =  m_strSearchPath + _T("\\Media\\*.swf"); 
	if( m_fileFlash.FindFile(path) )
	{
		// we have discoveryed at least one *.swf file, so convert it to *.bos
		BOOL bIsLastFile = FALSE;
		do
		{
			bIsLastFile = (m_fileFlash.FindNextFile() ==0)?TRUE:FALSE;
			
			// we will convert the name
			CString name = m_fileFlash.GetFilePath();
			name.Replace(_T(".swf"), _T(".bos"));
				
			CFile::Rename(m_fileFlash.GetFilePath(), name);
			
		}while(!bIsLastFile);
	}
	m_fileFlash.Close();

	// now we will encrept the file
	path =  m_strSearchPath + _T("\\Media\\*.bos"); 
	if( m_fileFlash.FindFile(path) )
	{
		BOOL bIsLastFile = FALSE;
		do
		{
			bIsLastFile = (m_fileFlash.FindNextFile() == 0)?TRUE:FALSE;
			
			CFile file;
			if(file.Open(m_fileFlash.GetFilePath(), CFile::modeReadWrite|CFile::shareDenyNone))
			{
				// first check whether the file has been encrpted
				BYTE segment[CODE_LEN];
				file.Seek(-CODE_LEN, CFile::end );
				file.Read(segment, CODE_LEN);
				BOOL bMatched = TRUE;
				for(int i = 0; i<CODE_LEN; i++)
				{
					if(segment[i] != FlashEndCode[i])
					{
						bMatched = FALSE;
						break;
					}
				}
				
				if(!bMatched)
				{
					// encode the file
					// here we mask something off from the head of the file
					BYTE segment[CODE_LEN];
					file.SeekToBegin();
					file.Read(segment, CODE_LEN);
					// do the mask
					for(int i = 0; i<CODE_LEN; i++)
					{
						segment[i] ^= FlashMaskCode[i];
					}
					// write back
					file.SeekToBegin();
					file.Write(segment, CODE_LEN);
					// finally we will set a mark at the end of the encrypted file
					// indicating that this file has been encrypted.
					file.SeekToEnd();
					file.Write(FlashEndCode, CODE_LEN);
				}
				file.Close();
			
			}
			
		}while(!bIsLastFile);
	}
	m_fileFlash.Close();

}

void CThunderView::DecodeFlashFile()
{
	// now we will decode the encrpted file
	CString path =  m_strSearchPath + _T("\\Media\\*.bos"); 
	if( m_fileFlash.FindFile(path) )
	{
		BOOL bIsLastFile = FALSE;
		do
		{
			bIsLastFile = (m_fileFlash.FindNextFile() == 0)?TRUE:FALSE;
			
			CFile file;
			if(file.Open(m_fileFlash.GetFilePath(), CFile::modeReadWrite|CFile::shareDenyNone))
			{
				// first check whether the file has been encrpted
				BYTE segment[CODE_LEN];
				file.Seek(-CODE_LEN, CFile::end );
				file.Read(segment, CODE_LEN);
				BOOL bMatched = TRUE;
				for(int i = 0; i<CODE_LEN; i++)
				{
					if(segment[i] != FlashEndCode[i])
					{
						bMatched = FALSE;
						break;
					}
				}
				if(bMatched)
				{
					// this is an encrepted file, we will now decode it
					file.SeekToBegin();
					file.Read(segment, CODE_LEN);
					// do the mask
					for(int i = 0; i<CODE_LEN; i++)
					{
						segment[i] ^= FlashMaskCode[i];
					}
					// write back
					file.SeekToBegin();
					file.Write(segment, CODE_LEN);

					// remove the end mark
					file.SetLength(file.GetLength() - CODE_LEN);
				}
				file.Close();
			}
			
		}while(!bIsLastFile);
	}
	m_fileFlash.Close();
		
}

// DlgTerrainEdit.cpp : implementation file
//

#include "stdafx.h"
#include "Thunder.h"
#include "DlgTerrainEdit.h"

#include "Terrain.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgTerrainEdit dialog


CDlgTerrainEdit::CDlgTerrainEdit(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgTerrainEdit::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgTerrainEdit)
	m_strTerrainName = _T("");
	m_fLength = 0.0f;
	m_fMaxHeight = 0.0f;
	m_nSegment = 0;
	m_fWidth = 0.0f;
	//}}AFX_DATA_INIT
}


void CDlgTerrainEdit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgTerrainEdit)
	DDX_Text(pDX, IDC_PATH, m_strTerrainName);
	DDX_Text(pDX, IDC_LENGTH, m_fLength);
	DDV_MinMaxFloat(pDX, m_fLength, 100.f, 2000.f);
	DDX_Text(pDX, IDC_MAXHEIGHT, m_fMaxHeight);
	DDV_MinMaxFloat(pDX, m_fMaxHeight, 0.f, 50.f);
	DDX_Text(pDX, IDC_SEGMENT, m_nSegment);
	DDV_MinMaxInt(pDX, m_nSegment, 1, 200);
	DDX_Text(pDX, IDC_WIDTH, m_fWidth);
	DDV_MinMaxFloat(pDX, m_fWidth, 10.f, 100.f);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgTerrainEdit, CDialog)
	//{{AFX_MSG_MAP(CDlgTerrainEdit)
	ON_BN_CLICKED(IDC_LOAD, OnLoad)
	ON_BN_CLICKED(IDC_CREATE_RANDOM, OnCreateRandom)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgTerrainEdit message handlers

void CDlgTerrainEdit::OnLoad() 
{
	UpdateData(TRUE);
	m_pTerrain->LoadTerrain(m_strSearchPath + m_strTerrainName);	
	m_bIsModified = TRUE;
}

void CDlgTerrainEdit::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CDlgTerrainEdit::OnCreateRandom() 
{
	// retrieve data from dialog
	UpdateData(TRUE);
	
	m_pTerrain->m_fWidth = m_fWidth;
	m_pTerrain->m_fLength = m_fLength;
	m_pTerrain->m_nSegment = m_nSegment;
	m_pTerrain->m_fMaxHeight = m_fMaxHeight;
	
	m_pTerrain->CreateRandomTerrain();
	m_bIsModified = TRUE;

	AfxMessageBox(_T("New terrain has been created successfully. Restart the game to experience it."));

	// some value may be changed, so update it
	m_nSegment = m_pTerrain->m_nSegment;
	
	UpdateData(FALSE);
	
}

BOOL CDlgTerrainEdit::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_strTerrainName = _T("Noname.thm");
	
	m_bIsModified = FALSE;

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgTerrainEdit::IsModified()
{
	return m_bIsModified;
}

// ThunderDoc.cpp : implementation of the CThunderDoc class
//

#include "stdafx.h"
#include "Thunder.h"

#include "ThunderDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CThunderDoc

IMPLEMENT_DYNCREATE(CThunderDoc, CDocument)

BEGIN_MESSAGE_MAP(CThunderDoc, CDocument)
	//{{AFX_MSG_MAP(CThunderDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CThunderDoc construction/destruction

CThunderDoc::CThunderDoc()
{
	// TODO: add one-time construction code here

}

CThunderDoc::~CThunderDoc()
{
}

BOOL CThunderDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CThunderDoc serialization

void CThunderDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CThunderDoc diagnostics

#ifdef _DEBUG
void CThunderDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CThunderDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CThunderDoc commands

// ThunderView.h : interface of the CThunderView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_THUNDERVIEW_H__0E9AC604_91E6_4ECA_A2B5_FBD119FB139B__INCLUDED_)
#define AFX_THUNDERVIEW_H__0E9AC604_91E6_4ECA_A2B5_FBD119FB139B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "d3dapp.h"
#include "d3dfont.h"
#include "Displayobject.h"
#include "terrain.h"
// for flash show
#include "shockwaveflash.h"

// for direct sound
#define INITGUID
#include <dmusici.h>
// for direct input
#include <dinput.h>
#include "shockwaveflash.h"	// Added by ClassView

const float DISTANCE = 20.0f; // the distance between the user plane and the newly created enemy plane

// rect used in the 1.0 by 1.0f plane
typedef struct fRect {
  float left, top, right, bottom;
}fRect;
//////////////// cited LiXizhi add-in

//-----------------------------------------------------------------------------
// Custom Direct3D vertex type used in this game
//-----------------------------------------------------------------------------
struct MODELVERTEX
{
    D3DXVECTOR3 p;
    D3DXVECTOR3 n;
};

#define D3DFVF_MODELVERTEX  (D3DFVF_XYZ|D3DFVF_NORMAL)

struct TEXTVERTEX
{
    float x,y,z;
	D3DCOLOR    color;    // The color.
    float       tu, tv;   // The texture coordinates.
};

#define D3DFVF_TEXTVERTEX  (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)

// for the camera of the game
#define TRACK_VIEW	0
struct CAMERA
{
	BYTE nType;// = TRACK_VIEW;
	float fViewTransition;//  = 0.0f;  // Amount used to transittion views(in percentage)
	BOOL bAnimatingViewChange;// = FALSE; // Whether view is transitioning
	D3DXVECTOR3 vPos;// Eye position only used in controlling mode
	D3DXVECTOR3 vTarget;// target that Eye Looking at
	D3DXVECTOR3 vUp;// that defines the current world's up, usually [0, 1, 0]. 
	

public:
	void CaculateParam();
	D3DXMATRIX matBillboard;
	D3DXMATRIX matView;
};

enum {GAME_UNINITIALIZED, GAME_INIT, GAME_PAUSED, GAME_VICTORY, GAME_RUNNING, USER_CRASHED};
enum {FLASH_UNINITIALIZED, FLASH_HIDE, FLASH_BONUS, FLASH_INIT, FLASH_ABOUT, FLASH_VICTORY, FLASH_DEAD};

class CD3DMesh;
class CThunderDoc;
class CThunderView : public CView, CD3DApplication
{
protected: // create from serialization only
	CThunderView();
	DECLARE_DYNCREATE(CThunderView)

// Attributes
public:
	// Font for drawing text
    CD3DFont* m_pFont;

	int                m_nLevel;//        = 0;      // Current game level
	int                m_nScore;//        = 0;      // Current game score

	CAMERA m_Camera; // camera--------the eye
	
	
	// Display list and player ship ////////////////////////////////////////
	CBaseObject* m_pMissileList;// = NULL;          // Missile list
	CBaseObject* m_pEnemyList; // Enemy plane's list
	CPlane* m_pPlane;// = NULL;          // Player's object

	// We donot use a class to encapasulate these classes for simplicity
	// you may want to do so in the futher
	// DirectMusic objects
	IDirectMusicLoader8*      m_pLoader;//       = NULL;
	IDirectMusicPerformance8* m_pPerformance;//  = NULL;
	IDirectMusicSegment8*     m_pSegment[15];
	static WCHAR*               m_strSoundFiles[];
	// DirectInput objects
	LPDIRECTINPUT8  m_lpDI;
	LPDIRECTINPUTDEVICE8   m_lpDIDevice;// = NULL; // Class for managing DInput devices

	
	// Support for the plane Mesh model
	CD3DMesh*           m_pPlaneMesh[10];//   = NULL;      // Geometry model of player's ship
	//LPD3DXBUFFER m_pPlaneMaterials; // materials used in this plane model 
	//DWORD m_dwPlaneNumMaterials; // number of materials
	DWORD                m_dwNumShipTypes;//    = 10L;
	static TCHAR*               m_strShipFiles[];
	static TCHAR*               m_strShipNames[];

	// Missile Mesh Obects
	LPD3DXMESH m_pMissileMesh;
	TEXTVERTEX* m_pMissileBuffer;

	// terrain objects
	CTerrain m_terrain;
	TEXTVERTEX* m_pTerrainBuffer;

	// other game varibles and constants
	BOOL                 m_bPaused;//         = FALSE;
	float	m_fViewSpeed; // the speed of view scrolling per second 
	fRect m_rcVisibleRect; // the size and position of the region that is visible
	void DeleteFromList(CBaseObject* pObject, CBaseObject **pList);
	void AddToList( CBaseObject* pObject, CBaseObject **pList );
	
	CThunderDoc* GetDocument();

// Operations
public:
	// MVC functions
	HRESULT          LoadGameObjects(); // the model module
	void             UnloadGameObjects();
	virtual HRESULT Render(); // the view module
	void Controller(); // the controller module, see reference
	// there is a subset of the controller functions
	void MissileMark();
	void MissileApplyMark();
	
	void EnemyMark();
	void EnemyApplyMark();
	
	void UserMark(const char buffer[]);
	
	void CameraApply(const char buffer[]);
	void SetWeapon(const char buffer[]);

	void ApplyPlaneMark(CPlane* pPlane);
	
	static HRESULT D3DUtil_SetColorKey( LPDIRECT3DTEXTURE8 pTexture, DWORD dwColorKey );

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThunderView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	//}}AFX_VIRTUAL

// Implementation
public:
	HWND m_hwndRenderWindow;
	virtual HRESULT ConfirmDevice( D3DCAPS8* pCaps, DWORD dwBehavior, D3DFORMAT Format );
	virtual HRESULT AdjustWindowForChange();
	void RenderScene();
	void OnToggleFullscreen();
	HWND m_hwndRenderFullScreen;
	virtual HRESULT FinalCleanup();
	virtual HRESULT DeleteDeviceObjects();
	virtual HRESULT FrameMove();
	virtual HRESULT InitDeviceObjects();
	virtual HRESULT OneTimeSceneInit();
	CString m_strSearchPath;
	float m_fMovementRange;
	void ApplyExplosion(CBaseObject* pPlane);
	int m_nGameState;
	void ResumeGame();
	void PauseGame();
	BOOL	 HitMarks(CBaseObject* pPlane, CBaseObject* pMissile);
	int GetMissile(DWORD dwType);
	void SafeReleaseList(CBaseObject** pObject);
	CString m_strMissile;
	CString m_strTerrain;
	LPDIRECT3DTEXTURE8 m_pTexture1;
	LPDIRECT3DTEXTURE8 m_pTexture2;
	
	BOOL IsOverlapped(CBaseObject *pObject1, CBaseObject *pObject2);
	float GetDistance(CBaseObject* pObject1, CBaseObject* pObject2);
	int GetListNum(CBaseObject * pObject);
	void Set3DPositionOf(CBaseObject* pObject);
	void ApplyMarks(const char buffer[]);
	void GenerateMarks(const char buffer[]);
	void FireMissile(CPlane* pPlane);
	
	int m_nVisibleSegmentNum;
	float m_fCurrentLinePos; // the back line of the movable rangion of the user plane
	int tarin_num; // this is a temporary constant used to draw simply terrian
	void Restart();
	HRESULT ReloadPlane();

	void PlaySound(int index);
	virtual ~CThunderView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
public:
	void MaskName();
	CFileFind m_fileFlash;
	void DecodeFlashFile();
	void EncodeFlashFile();
	void SetFlashStatus(int nStatus);
	void TryFlash();
	int m_nFlashStatus;
	CShockwaveFlash m_wndFlashShow;
	BOOL TryRender();
	void AnnounceVictory();
	HRESULT LoadTerrainBuffer();
	BOOL m_bAutoCamera;
	BOOL IsTimeToRender();
	float m_fMyFPS;
	void AddUserBonus(int nHealth, int nScore);
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT RestoreDeviceObjects();
	BOOL IsReady();
	HRESULT CheckForLostFullscreen();
	//{{AFX_MSG(CThunderView)
	afx_msg void OnGameBegin();
	afx_msg void OnGamePause();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnGameOption();
	afx_msg void OnGameTerrainedit();
	afx_msg void OnGameEditmap();
	afx_msg void OnGameDevice();
	afx_msg void OnGameToggleView();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnAppExit();
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnHelpInstructions();
	afx_msg void OnBonusNext();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ThunderView.cpp
inline CThunderDoc* CThunderView::GetDocument()
   { return (CThunderDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THUNDERVIEW_H__0E9AC604_91E6_4ECA_A2B5_FBD119FB139B__INCLUDED_)

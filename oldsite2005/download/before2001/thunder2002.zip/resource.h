//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Thunder.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TSTYPE                      129
#define IDD_DLG_D3D_PROPERTIES          132
#define IDD_OPTIONS                     133
#define IDD_TERRAIN_EDIT                134
#define IDD_FLASH_LLX                   135
#define IDD_SELECTDEVICE                144
#define IDC_HAL                         1000
#define IDC_DEVICE_COMBO                1000
#define IDC_SOFTWARE_SIM                1001
#define IDC_Z_BUFFER                    1002
#define IDC_ADAPTER_COMBO               1002
#define IDC_WIDTH                       1003
#define IDC_FULLSCREENMODES_COMBO       1003
#define IDC_HEIGHT                      1004
#define IDC_TERRAIN                     1004
#define IDC_REF                         1005
#define IDC_MISSILE                     1005
#define IDC_PATH                        1005
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_LOAD                        1006
#define IDC_PARENT_PATH                 1006
#define IDC_CREATE_RANDOM               1007
#define IDC_FULL_SCREEN                 1008
#define IDC_FPS                         1010
#define IDC_UNLIMITED                   1011
#define IDC_AUTO_CAMERA                 1012
#define IDC_LENGTH                      1014
#define IDC_SHOCKWAVEFLASH1             1014
#define IDC_SEGMENT                     1015
#define IDC_SHOW_FLASH                  1015
#define IDC_WINDOW                      1016
#define IDC_MAXHEIGHT                   1016
#define IDC_FULLSCREEN                  1018
#define IDC_BONUS_NAME                  1018
#define ID_GAME_BEGIN                   32771
#define ID_GAME_PAUSE                   32772
#define ID_GAME_CLOSE                   32773
#define ID_GAME_OPTIONS                 32774
#define ID_GAME_TEST                    32775
#define ID_GAME_OPTION                  32776
#define ID_GAME_TERRAINEDIT             32777
#define ID_GAME_EDITMAP                 32778
#define ID_GAME_DEVICE                  32779
#define ID_GAME_TOGGLE_VIEW             32780
#define ID_HELP_INSTRUCTIONS            32781
#define ID_BONUS_NEXT                   32782
#define ID_SELECT_BONUS                 32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

#if !defined(AFX_DLGFLASH_H__56E1FE59_7B81_4806_85AC_056C40A4A08D__INCLUDED_)
#define AFX_DLGFLASH_H__56E1FE59_7B81_4806_85AC_056C40A4A08D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgFlash.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgFlash dialog

class CDlgFlash : public CDialog
{
// Construction
public:
	CDlgFlash(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgFlash)
	enum { IDD = IDD_FLASH_LLX };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgFlash)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgFlash)
	afx_msg void OnOnReadyStateChangeShockwaveflash1(long newState);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGFLASH_H__56E1FE59_7B81_4806_85AC_056C40A4A08D__INCLUDED_)

// friendobjects.h: interface for the CEnemyTrack class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FRIENDOBJECTS_H__4762D24D_944A_4916_875A_8B4374096DD6__INCLUDED_)
#define AFX_FRIENDOBJECTS_H__4762D24D_944A_4916_875A_8B4374096DD6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define EXPLOSION_FRAMES	5 // number of frames animated in a explosion

class CThunderView;
class CEnemyTrack  
{
public:
	CThunderView* m_pView;
	void ApplyMark(CBaseObject *pObject);
	void GenerateMark(CBaseObject* pObject);
	CEnemyTrack(CThunderView* pView);
	virtual ~CEnemyTrack();

};


class CMissileTrack : public CEnemyTrack
{
public:
	CMissileTrack(CThunderView* pView);
	void ApplyMark(CBaseObject *pObject);
	void GenerateMark(CBaseObject* pObject);

	virtual ~CMissileTrack();

};


class CExplosion : public CEnemyTrack  
{
public:
	void GenerateMark(CBaseObject *pObject);
	void ApplyMark(CBaseObject *pObject);
	CExplosion(CThunderView* pView);
	virtual ~CExplosion();

};

#endif // !defined(AFX_FRIENDOBJECTS_H__4762D24D_944A_4916_875A_8B4374096DD6__INCLUDED_)

// Terrain.cpp: implementation of the CTerrain class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Thunder.h"
#include "Terrain.h"

#include <d3dx8.h> // LINK d3dx8.lib


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTerrain::CTerrain()
{
	m_pData = NULL;

	m_fLength = 600.0f;
	m_fWidth = 20.0f;

	m_nSegment = 30;
	
	m_fMaxHeight = 15.0f;
	m_fMinSegLength = 10.0f;
	m_fRadius = 2.0f;

}

CTerrain::~CTerrain()
{
	if(m_pData)
		delete m_pData;

}

// the result is in m_pData
HRESULT CTerrain::CreateRandomTerrain()
{
	// clear m_pData;
	if(m_pData)
		delete m_pData;
	m_pData = NULL;
	// Build randomly a terrain according to the specified data
	
	// Create a data that is in a fit size
	// 3.0f is just something you need care
	if( (m_fMinSegLength+3.0f) > (m_fLength/m_nSegment))
	{
		// there are too many segments that the average length is too small
		// so we will automatically shrink the segments to an allowed value.
		m_nSegment = (int)(m_fLength/(m_fMinSegLength+3.0f));
		AfxMessageBox(_T("there are too many segments that the average length is too small so we will automatically shrink the segments to an allowed value"));

	}

	
	m_pData = new LINE[m_nSegment+1];

	// set the seed
	srand( (unsigned)time( NULL ) );
	
	// there is #(m_nSegment+1)# lines
	for(int i=0; i<(m_nSegment+1); i++)
	{
		float fRandom = ((float)rand())/RAND_MAX; // in percentage
		if(i==0)
		{ // the first element
			m_pData[i].fHeight = 0.0f;
			m_pData[i].fY = 0.0f;
			m_pData[i].dwColor = D3DCOLOR_XRGB(0xff,0xff,0xff); // White
	
		}
		else if(i == m_nSegment)
		{ // the last element
			m_pData[i].fHeight = 0.0f;
			m_pData[i].fY = m_fLength;
			m_pData[i].dwColor = D3DCOLOR_XRGB(0xff,0xff,0xff); // White
			LowerHeight(i);
		}
		else
		{
			m_pData[i].fHeight = fRandom*m_fMaxHeight;
			m_pData[i].fY = (m_fLength/m_nSegment)*i + 
				((m_fLength/m_nSegment)-m_fMinSegLength)*(fRandom-0.5f);
			m_pData[i].dwColor = D3DCOLOR_XRGB(0xff,0xff,0xff); // White
			
			// here we will lower the height if the angle between two ajacent segments are too sharp
			LowerHeight(i);
		}
	}

	
	return TRUE;
}

HRESULT CTerrain::SaveTerrain(LPCTSTR pPath)
{
	return TRUE;
}

HRESULT CTerrain::LoadTerrain(LPCTSTR pPath)
{
	// Open the terrain file
	CFile file;
	if(! file.Open(pPath, CFile::modeRead))
		return FALSE;
	
	// load data from file into m_pData

	// clear m_pData;
	if(m_pData)
		delete m_pData;
	m_pData = NULL;
	// Build randomly a terrain according to the specified data
	
	// Create a data that is in a fit size
	int nHeight, nLength;
	file.Read(&nLength, sizeof(nLength));
	file.Read(&nHeight, sizeof(nHeight));
	file.Read(&m_nSegment, sizeof(m_nSegment));

	m_pData = new LINE[m_nSegment+1];

	// there is #(m_nSegment+1)# lines
	for(int i=0; i<(m_nSegment+1); i++)
	{
		if(i==0)
		{ // the first element
			m_pData[i].fHeight = 0.0f;
			m_pData[i].fY = 0.0f;
			m_pData[i].dwColor = D3DCOLOR_XRGB(0xff,0xff,0xff); // White
	
		}
		else if(i == m_nSegment)
		{ // the last element
			m_pData[i].fHeight = 0.0f;
			m_pData[i].fY = m_fLength;
			m_pData[i].dwColor = D3DCOLOR_XRGB(0xff,0xff,0xff); // White
		}
		else
		{
			int nY, height;
			file.Read(&nY, sizeof(nY));
			file.Read(&height, sizeof(height));
			
			m_pData[i].fHeight = ((float)height/(float)nHeight) * m_fMaxHeight;
			m_pData[i].fY = ((float)nY/(float)nLength) * m_fLength;
			m_pData[i].dwColor = D3DCOLOR_XRGB(0xff,0xff,0xff); // White
			
		}
	}
	return TRUE;
}

void CTerrain::GetLookingAngle(int nIndex, float fPosRY, float *pAngle)
{
	
}

void CTerrain::GetLookingAngle(float fPosY, float *pAngle)
{
	// get the segment that contains fPosY;
	int nSegment = GetSegmentFromY(fPosY);
	
	if((m_pData[nSegment].fY - fPosY) < m_fRadius)
	{
		(*pAngle) = ((float)atan(GetSegmentSlope(nSegment) * 
			( (float)fabs((float)(m_pData[nSegment].fY - fPosY) )/m_fRadius)));
				
	}
	else if((fPosY - m_pData[nSegment-1].fY) < m_fRadius)
	{
		(*pAngle) = ((float)atan(GetSegmentSlope(nSegment) * 
			( (float)fabs((float)(m_pData[nSegment-1].fY - fPosY) )/m_fRadius)));
		
	}
	else
	{
		(*pAngle) = ((float)atan(GetSegmentSlope(nSegment)));
	}
}

float CTerrain::GetSegmentSlope(int nSegment)
{
	return (m_pData[nSegment].fHeight - m_pData[nSegment-1].fHeight) /
			(m_pData[nSegment].fY - m_pData[nSegment-1].fY);
}

float CTerrain::GetSlope(float fPosY)
{
	return GetSegmentSlope(GetSegmentFromY(fPosY));
}

int CTerrain::GetSegmentFromY(float fPosY)
{
	// get the segment that near fPosY;
	int nSegment; // the result
	nSegment = (int)floor(fPosY / (m_fLength/m_nSegment));
	
	if((m_pData[nSegment].fY >= fPosY) ||
		(m_pData[++nSegment].fY >= fPosY) ||
		(m_pData[++nSegment].fY >= fPosY))
	{
		return nSegment;
	}
	return -1;// Failure
}


float CTerrain::GetHeightFromY(float fPosY)
{
	int i = GetSegmentFromY(fPosY);
	return m_pData[i-1].fHeight + GetSegmentSlope(i)*(fPosY - m_pData[i-1].fY); 

}

float CTerrain::LowerHeight(int i)
{

#define MAX_INTER_SEG_SLOPE	0.1f
	
	// we don't check the height if the maxsium angle between two segment is smaller that the max angle
	if((atan(m_fMaxHeight/(m_fLength/m_nSegment))*2.0f) < atan(MAX_INTER_SEG_SLOPE))
	{
		// no change is made
	}
	else
	{// there is a possiblity, we should check
		if(i == 0 )
		{
			// no change is made
		}
		else if(i == 1)
		{
			if(fabs(GetSegmentSlope(i)) < MAX_INTER_SEG_SLOPE)
			{
				// height is OK
			}
			else
			{
				// height need resetting
				m_pData[i].fHeight = (m_pData[i].fY - m_pData[i-1].fY)*MAX_INTER_SEG_SLOPE;
			}
		}
		else
		{
			if(fabs(atan(GetSegmentSlope(i)) - atan(GetSegmentSlope(i-1))) < atan(MAX_INTER_SEG_SLOPE))
			{
				// no change is made	
			}
			else
			{
				// height need resetting
				float fSlope = GetSegmentSlope(i-1);
				if(fSlope >= 0.0f)
				{
					m_pData[i].fHeight = (m_pData[i].fY - m_pData[i-1].fY)*
						(float)tan(atan(fSlope)-atan(MAX_INTER_SEG_SLOPE));
				}
				else
				{
					m_pData[i].fHeight = (m_pData[i].fY - m_pData[i-1].fY)*
						(float)tan(atan(fSlope)+atan(MAX_INTER_SEG_SLOPE));
				}
			}
		}
	}

	return m_pData[i].fHeight;
}


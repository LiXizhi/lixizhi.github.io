// DlgD3DProperties.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h" // included for ID values used in the dialog

#include "DlgD3DProperties.h"
#include "D3Dapp.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgD3DProperties dialog


CDlgD3DProperties::CDlgD3DProperties(CD3DApplication* pD3dWnd, CWnd* pParent /*=NULL*/)
	: CDialog(CDlgD3DProperties::IDD, pParent)
{
	m_pD3dWnd = pD3dWnd;
	//{{AFX_DATA_INIT(CDlgD3DProperties)
	m_bZbuffer = FALSE;
	m_nDevice = 0;
	m_dwHeight = 640;
	m_dwWidth = 480;
	m_bIsFullScreen = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgD3DProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgD3DProperties)
	DDX_Check(pDX, IDC_Z_BUFFER, m_bZbuffer);
	DDX_Radio(pDX, IDC_HAL, m_nDevice);
	DDX_Text(pDX, IDC_HEIGHT, m_dwHeight);
	DDV_MinMaxDWord(pDX, m_dwHeight, 50, 1000);
	DDX_Text(pDX, IDC_WIDTH, m_dwWidth);
	DDV_MinMaxDWord(pDX, m_dwWidth, 50, 2000);
	DDX_Check(pDX, IDC_FULL_SCREEN, m_bIsFullScreen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgD3DProperties, CDialog)
	//{{AFX_MSG_MAP(CDlgD3DProperties)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgD3DProperties message handlers

void CDlgD3DProperties::OnOK() 
{
	UpdateData(TRUE);
	
	/*
	m_pD3dWnd->m_nDevice = m_nDevice;
	m_pD3dWnd->m_bDepthBuffer = m_bZbuffer;
	m_pD3dWnd->m_dwCreationWidth = m_dwWidth;
	m_pD3dWnd->m_dwCreationHeight = m_dwHeight;
	m_pD3dWnd->m_bWindowed = !m_bIsFullScreen;
*/
	CDialog::OnOK();
}

BOOL CDlgD3DProperties::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
/*	
	m_nDevice = m_pD3dWnd->m_nDevice;
	m_bZbuffer = m_pD3dWnd->m_bDepthBuffer;
	m_dwWidth = m_pD3dWnd->m_dwCreationWidth;
	m_dwHeight = m_pD3dWnd->m_dwCreationHeight;
	m_bIsFullScreen = !m_pD3dWnd->m_bWindowed;


*/	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

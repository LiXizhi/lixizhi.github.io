// DlgOption.cpp : implementation file
//

#include "stdafx.h"
#include "Thunder.h"
#include "DlgOption.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgOption dialog


CDlgOption::CDlgOption(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOption::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgOption)
	m_strMissile = _T("");
	m_strParentPath = _T("");
	m_strTerrain = _T("");
	m_fFPS = 0.0f;
	m_bUnLimitedSpeed = FALSE;
	m_bAutoCamera = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgOption::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgOption)
	DDX_Text(pDX, IDC_MISSILE, m_strMissile);
	DDX_Text(pDX, IDC_PARENT_PATH, m_strParentPath);
	DDX_Text(pDX, IDC_TERRAIN, m_strTerrain);
	DDX_Text(pDX, IDC_FPS, m_fFPS);
	DDV_MinMaxFloat(pDX, m_fFPS, 0.f, 100.f);
	DDX_Check(pDX, IDC_UNLIMITED, m_bUnLimitedSpeed);
	DDX_Check(pDX, IDC_AUTO_CAMERA, m_bAutoCamera);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgOption, CDialog)
	//{{AFX_MSG_MAP(CDlgOption)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgOption message handlers

void CDlgOption::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	
	CDialog::OnOK();
}

BOOL CDlgOption::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

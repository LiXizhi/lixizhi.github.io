// DlgFlash.cpp : implementation file
//

#include "stdafx.h"
#include "Thunder.h"
#include "DlgFlash.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgFlash dialog


CDlgFlash::CDlgFlash(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgFlash::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgFlash)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgFlash::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgFlash)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgFlash, CDialog)
	//{{AFX_MSG_MAP(CDlgFlash)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgFlash message handlers

BEGIN_EVENTSINK_MAP(CDlgFlash, CDialog)
    //{{AFX_EVENTSINK_MAP(CDlgFlash)
	ON_EVENT(CDlgFlash, IDC_SHOCKWAVEFLASH1, -609 /* OnReadyStateChange */, OnOnReadyStateChangeShockwaveflash1, VTS_I4)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

void CDlgFlash::OnOnReadyStateChangeShockwaveflash1(long newState) 
{
	// TODO: Add your control notification handler code here
	
}

This is demo of OpenGL, working with mfc class.
A 3D game.
Source code is offered in mathsrc.zip

You will first see a teapot to test your screen.
Press any of the following keys to skip.

Here are the function keys:

Tab:	Change directions
q, w, e:	Change group. each represent a line of arrow(3)
s:	change High-lighted item in a group.
Space:	Do the rotation.

Keypad(arrow keys): change the viewport.
ins & num5:	save and retore a scene.

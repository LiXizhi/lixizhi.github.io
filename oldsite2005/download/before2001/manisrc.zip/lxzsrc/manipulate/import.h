/* Cause warning messages so...
#ifdef _EXPORTING   
	#define CLASS_DECLSPEC    __declspec(dllexport)
#else
	#define CLASS_DECLSPEC    __declspec(dllimport)
#endif
*/

const UINT	WM_PACKAGE_RECEIVED	= WM_USER+666;	// the Message sent to the calling window indicates a received msg

#define CLASS_DECLSPEC    __declspec(dllimport)

typedef struct {
	DWORD	name;	// the name of the message to be transfered
	int		len; // size ofthe package not including name and len. only the size of the date of the pointer below
	char*	buf; // the pointer to the data(package)
} PACKAGE, *LPPACKAGE;


CLASS_DECLSPEC int FirstStartCom(HINSTANCE hInstance, HWND hWnd);
CLASS_DECLSPEC void LastEndCom();
CLASS_DECLSPEC void SendPackage(LPPACKAGE pkg, BOOL bGuaranteed = FALSE);

// for test
CLASS_DECLSPEC void RunTestDlg();
CLASS_DECLSPEC int RunConnectDlg(HINSTANCE hInstance);
CLASS_DECLSPEC void DllTestMe();

#include "stdafx.h"

#include "dialogpad.h"
#include "interact.h"


void DoMessage(LPDPLAYINFO lpDPInfo, SENDNETCONENTS* lpConents, DPID idFrom, DPID idTo);
void DoSend(LPDPLAYINFO lpDPInfo, SENDNETCONENTS* lpConents);



void DoMessage(LPDPLAYINFO lpDPInfo, SENDNETCONENTS* lpConents, DPID idFrom, DPID idTo)
{
	if (idFrom == DPID_SYSMSG) return;

	switch (lpConents->cmd)
	{
	case cmdChat:
		{
			CString str = lpConents->cChat;
			::MessageBox(NULL,str, "OK", MB_OK);
			break;
		}
		break;
	}
}

void DoSend(LPDPLAYINFO lpDPInfo, SENDNETCONENTS* lpConents)
{
	lpDPInfo->lpDirectPlay3A->Send(lpDPInfo->dpidPlayer, DPID_ALLPLAYERS,
		DPSEND_GUARANTEED, (LPVOID)lpConents, sizeof(SENDNETCONENTS));
}
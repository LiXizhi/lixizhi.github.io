// manipulateDlg.cpp : implementation file
//

#include "stdafx.h"

#include "manipulate.h"
#include "manipulateDlg.h"
#include "DlgOption.h"

// For pic transfer use
CManipulateDlg* CManipulateDlg::m_pMain = NULL;
BOOL bStartThread = FALSE;
int nStartX = 0;
int nStartY = 0;
int nWidth = 800;
int nHeight = 600;


#include <afxsock.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CManipulateDlg dialog

CManipulateDlg::CManipulateDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CManipulateDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CManipulateDlg)
	m_bIsGuaranteed = FALSE;
	m_strStatus = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CManipulateDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CManipulateDlg)
	DDX_Check(pDX, IDC_GUARANTEED, m_bIsGuaranteed);
	DDX_Text(pDX, IDC_STATUS, m_strStatus);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CManipulateDlg, CDialog)
	//{{AFX_MSG_MAP(CManipulateDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_FETCHSCREEN, OnFetchscreen)
	ON_BN_CLICKED(IDC_SELECTION, OnSelection)
	ON_BN_CLICKED(IDC_GETANYWAY, OnGetanyway)
	ON_BN_CLICKED(IDC_TEST, OnTest)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_OPTION, OnOption)
	ON_BN_CLICKED(IDC_CURSOR2, OnCursor2)
	ON_BN_CLICKED(IDC_CUTSOR1, OnCutsor1)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_SETCURSOR()
	ON_BN_CLICKED(IDC_CHAT_NOW, OnChatNow)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CManipulateDlg message handlers

BOOL CManipulateDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// all is presumed
	m_xSize = 200;
	m_ySize = 150;
	m_screenX = 800;
	m_screenY = 600;
	m_nMyScrX = 800;
	m_nMyScrY = 600;

	m_bIsBegin = FALSE;
	m_bBusyPort = TRUE;
	m_strStatus = "OK";
	m_bIsGuaranteed = FALSE;

	// get the bouder in which I should put the picture
	CWnd* pBouder = GetDlgItem(IDC_BOUDER);
	CRect rect;
	pBouder->GetWindowRect(&rect);
	ScreenToClient(&rect);
//	ScreenTo
	m_nPicLeft = rect.left;
	m_nPicTop = rect.top;
	VERIFY(pBouder->DestroyWindow());
	
	CClientDC dc(this);
	m_bmpScreen.CreateCompatibleBitmap(&dc, m_xSize, m_ySize);
	
	UpdateData(FALSE);
	OnCutsor1();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CManipulateDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CManipulateDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
//		CDialog::OnPaint();
		CPaintDC dc(this); // device context for painting

		CDC dcMem;
		dcMem.CreateCompatibleDC(&dc);
		
		CBitmap* oldBmp = dcMem.SelectObject(&m_bmpScreen);

		dc.StretchBlt(m_nPicLeft, m_nPicTop, m_xSize, m_ySize, &dcMem, 
			0, 0, m_xSize, m_ySize, SRCCOPY);
			
		dcMem.SelectObject(oldBmp);
	}
	
	
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CManipulateDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

LRESULT CALLBACK KeyboardProc(  int code,       // hook code
  WPARAM wParam,  // virtual-key code
  LPARAM lParam   // keystroke-message information
);

HHOOK ghKbrdHook;
int CManipulateDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	//ghKbrdHook = SetWindowsHookEx(WH_KEYBOARD, KeyboardProc, NULL, 0);
    m_pMain = this;
	//CreateChat(NULL);
	
	return 0;
}


LRESULT CALLBACK KeyboardProc(  int iCode,       // hook code
  WPARAM wParam,  // virtual-key code
  LPARAM lParam   // keystroke-message information
)
{
	static BOOL bLock = TRUE;
	if (iCode < 0 || iCode != HC_ACTION)
		return CallNextHookEx(ghKbrdHook, iCode, wParam, lParam);

	if (wParam == VK_PAUSE)
	{
		bLock = !bLock;
		MessageBeep(-1);
	}
	if (!bLock)
	{
		return CallNextHookEx(ghKbrdHook, iCode, wParam, lParam);
	}
	else
	{
		int nDegree = 3;
		switch(wParam)
		{
			case VK_LEFT:
			{
				mouse_event(MOUSEEVENTF_MOVE, -nDegree, 0, 0, 0);
				break;
			}
			case VK_UP:
			{
				mouse_event(MOUSEEVENTF_MOVE, 0, -nDegree, 0, 0);
				break;
			}
			case VK_RIGHT:
			{
				mouse_event(MOUSEEVENTF_MOVE, nDegree, 0, 0, 0);
				break;
			}
			case VK_DOWN:
			{
				mouse_event(MOUSEEVENTF_MOVE, 0, nDegree, 0, 0);
				break;
			}
			case VK_HOME:
			{
				mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
				break;
			}
			case VK_PRIOR:
			{
				mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
				break;
			}
			default:
			{
				return CallNextHookEx(ghKbrdHook, iCode, wParam, lParam);
			}
		}
		return 10;
	}
}

void CManipulateDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	//UnhookWindowsHookEx(ghKbrdHook);
}

int CManipulateDlg::OnPackageReceived(LPPACKAGE pkg)
{
	switch(pkg->name)
	{
		case 2: // reveives a picturc of remoute
		{
			// enable the fetch screen button
			m_pMain->m_bBusyPort = FALSE;
			
			LPPICPACKAGE lpPic = (LPPICPACKAGE)pkg->buf;
			
			m_pMain->ShowPicture(lpPic);
			break;
		}
		case 3: // a request of getting a picture.
		{
			LPFETCHPIC lpPic = (LPFETCHPIC)pkg->buf;
			m_pMain->SendPic(lpPic);
			break;
		}
		case 5: // a event you must carried out
		{
			LpMyEvent lpEvent = (LpMyEvent)pkg->buf;
			m_pMain->ReceiveEvent(lpEvent);
			break;
		}
	}

	return TRUE;
}


void CManipulateDlg::OnOK() 
{
	LastEndCom();
	
	CDialog::OnOK();
}

void CManipulateDlg::OnCancel() 
{
	LastEndCom();
	
	CDialog::OnCancel();
}

void CManipulateDlg::OnFetchscreen() 
{
	if (m_bBusyPort) 
		return;
	//CClientDC dc(NULL);
	//int nColorBits = dc.GetDeviceCaps(BITSPIXEL);
	//pkg.len = sizeof(nColorBits);
	//pkg.buf = (char*)nColorBits;
	FETCHPIC fetchPic;
	fetchPic.x = 0;
	fetchPic.y = 0;
	fetchPic.width = m_screenX;
	fetchPic.height = m_screenY;

	FetchPic(&fetchPic);

	UpdateData(TRUE);
	
	m_bBusyPort = TRUE;
}

void CManipulateDlg::OnSelection() 
{
	AddStatus("clear");
	CreateChat(NULL);
	FirstStartCom(this, CManipulateDlg::OnPackageReceived);
	m_bBusyPort = FALSE;
	m_bIsBegin = TRUE;
	
	AddStatus("Started");
}

void CManipulateDlg::ShowPicture(LPPICPACKAGE lpPic)
{
	// obtain the picture
	CClientDC dc(this);

	int nPlanes = dc.GetDeviceCaps(PLANES);
	int nPixel = dc.GetDeviceCaps(BITSPIXEL);

	CBitmap bmp;
	bmp.CreateBitmap(lpPic->width, lpPic->height, nPlanes, nPixel, lpPic->buf);
	
	CDC dcMem;
	dcMem.CreateCompatibleDC(&dc);
	
	CBitmap* oldBmp = dcMem.SelectObject(&bmp);


	CDC dcMem2;
	dcMem2.CreateCompatibleDC(&dc);

	CBitmap* oldBmp2 = dcMem2.SelectObject(&m_bmpScreen);

	VERIFY(dcMem2.StretchBlt( lpPic->x, lpPic->y, lpPic->width, lpPic->height, &dcMem,
		0, 0, lpPic->width, lpPic->height, SRCCOPY));

	dc.StretchBlt(m_nPicLeft+lpPic->x, m_nPicTop+lpPic->y, lpPic->width, lpPic->height, &dcMem, 
		0, 0, lpPic->width, lpPic->height, SRCCOPY);


	dcMem2.SelectObject(oldBmp2);
	dcMem.SelectObject(oldBmp);
}

// Show the Status
void CManipulateDlg::AddStatus(char *str)
{
	CString match = "clear";
	if (match==str)
		m_strStatus = "OK";
	else
	{
		m_strStatus += str;
		m_strStatus += "\r\n";
	}
	UpdateData(FALSE);
}

void CManipulateDlg::OnGetanyway() 
{
	m_bBusyPort = FALSE;
	OnFetchscreen();	
}

void CManipulateDlg::SendPic(LPFETCHPIC pPic)
{
	CClientDC dc(NULL);
	nStartX = pPic->x;
	nStartY = pPic->y;
	nWidth = pPic->width;
	nHeight = pPic->height;

	if(bStartThread)
	{
		bStartThread = FALSE;
		DWORD result;
		while(GetExitCodeThread(m_pSendThread->m_hThread, &result) && (result == STILL_ACTIVE))
		{
			MessageBeep(-1);
		}
	}
	m_pSendThread = AfxBeginThread(CManipulateDlg::SendPicThread, 0);
}

UINT CManipulateDlg::SendPicThread( LPVOID pParam )
{
	bStartThread = TRUE;
	// create a memdc to generate a stretched bitmap

	TRY
	{
		CClientDC dc(NULL);
		CClientDC *pDC = &dc;
		
		CDC dcMem;
		dcMem.CreateCompatibleDC(pDC);

		int xSize = GetSystemMetrics(SM_CXSCREEN);
		int ySize = GetSystemMetrics(SM_CYSCREEN);
		double dVx = (double)(m_pMain->m_xSize)/(double)xSize;
		double dVy = (double)(m_pMain->m_ySize)/(double)ySize;
		
		int nRows = int((double)ySize/(double)(m_pMain->m_ySize));
		int n = int((double)nHeight/(double)nRows);

		int i=0;
		do
		{
			// get the piece of picture
			CBitmap bmp;
			int xbegin = nStartX;
			int ybegin = nStartY + (nRows*i);
			int width = nWidth;
			int height;
			if(i == (n-1))
				height = (nHeight - nRows*i);
			else
				height = nRows;

			// s means strenched dacolations
			int sw = (int)(dVx*(double)width);
			int sh = (int)(dVy*(double)height);
			int sx = (int)(dVx*(double)xbegin);
			int sy = (int)(dVy*(double)ybegin);
			bmp.CreateCompatibleBitmap(pDC, sw, sh);
			dcMem.SelectObject(&bmp);
			dcMem.StretchBlt(0,0, sw, sh, pDC, 
				xbegin, ybegin, width, height, SRCCOPY);
			// now fill the stucture

			PACKAGE pkg;
			pkg.name = 2;
			LPPICPACKAGE lpPic;
			int preSize = sizeof(lpPic->x)+sizeof(lpPic->y)+sizeof(lpPic->width)+sizeof(lpPic->height);
			pkg.len = preSize + sw*sh;
			// add enhanced code here but now 256 colors is assumed
			lpPic = (LPPICPACKAGE)new BYTE[pkg.len + 16];
			lpPic->x = sx;
			lpPic->y = sy;
			lpPic->width = sw;
			lpPic->height = sh;
			bmp.GetBitmapBits(sw*sh, lpPic->buf);
			pkg.buf = (char*)lpPic;
			//////send now
			SendPackage(&pkg, m_pMain->m_bIsGuaranteed);
			
			delete [] (BYTE*) pkg.buf;

			i++;
		}while((i<n) && (bStartThread) );
		
		bStartThread = FALSE;
	} // TRY
	CATCH_ALL(e)
	{
		ASSERT(FALSE);
	}
	END_CATCH_ALL

	return 1;
}

//pkg.buf = (char *)GlobalAllocPtr(GHND, pkg.len + 1);
//bmp.GetBitmapBits(pkg.len, pkg.buf);
	

void CManipulateDlg::OnTest() 
{
	/*
	VERIFY(AfxSocketInit());
	CAsyncSocket sock;
	VERIFY(sock.Create());
	CString strIP;
	UINT num;
	VERIFY(sock.GetSockName(strIP, num));
	TRACE(strIP+'\n');
	*/
	FETCHPIC fetchPic;
	fetchPic.x = 0;
	fetchPic.y = 0;
	fetchPic.width = m_screenX;
	fetchPic.height = m_screenY;
	SendPic (&fetchPic);
}

void CManipulateDlg::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CPoint pMy;
	pMy.x = point.x - m_nPicLeft;
	pMy.y = point.y - m_nPicTop;
	CRect rect(0, 0, m_xSize, m_ySize);
	if (rect.PtInRect(pMy))
	{
		if (m_nCursor==1) // manipulate
		{
			CClientDC dcdc(NULL);
			double dVx = (double)m_xSize/(double)m_screenX;
			double dVy = (double)m_ySize/(double)m_screenY;

			MyEvent myEvent;
			myEvent.nName = 1;
			myEvent.ParamX = int((double)pMy.x / (double)dVx);
			myEvent.ParamY = int((double)pMy.y / (double)dVy);
			
			SendEvents(&myEvent);
		}
	}
	CDialog::OnLButtonDblClk(nFlags, point);
}

void CManipulateDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_nMx = -1;
	m_nMy = -1;

	CPoint pMy;
	pMy.x = point.x - m_nPicLeft;
	pMy.y = point.y - m_nPicTop;
	CRect rect(0, 0, m_xSize, m_ySize);
	if (rect.PtInRect(pMy))
	{
		if (!m_bIsBegin) return;
		if (m_nCursor==2) // clip
		{
			m_nMx = pMy.x;
			m_nMy = pMy.y;
		}
		else if (m_nCursor==1) // manipulate
		{
			CClientDC dcdc(NULL);
			double dVx = (double)m_xSize/(double)m_screenX;
			double dVy = (double)m_ySize/(double)m_screenY;

			MyEvent myEvent;
			myEvent.nName = 1;
			myEvent.ParamX = int((double)pMy.x / (double)dVx);
			myEvent.ParamY = int((double)pMy.y / (double)dVy);
			
			SendEvents(&myEvent);
		}
	}
	else
	{
		OnCutsor1();
	}

	CDialog::OnLButtonDown(nFlags, point);
}

void CManipulateDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CPoint pMy;
	pMy.x = point.x - m_nPicLeft;
	pMy.y = point.y - m_nPicTop;
	CRect rect(0, 0, m_xSize, m_ySize);
	if (rect.PtInRect(pMy))
	{
		if (!m_bIsBegin) return;

		if (m_nCursor==2) // clip
		{
			if ((m_nMx!=-1) && (m_nMy!=-1))
			{
				double dVx = (double)m_xSize/(double)m_screenX;
				double dVy = (double)m_ySize/(double)m_screenY;
				CRect rect;
				rect.left = int((double)m_nMx / (double)dVx);
				rect.top = int((double)m_nMy / (double)dVy);
				rect.right = int((double)pMy.x / (double)dVx);
				rect.bottom = int((double)pMy.y / (double)dVy);
				
				if ((rect.Width()>0) && (rect.Height()>0))
				{
					FETCHPIC fetchPic;
					fetchPic.x = rect.left;
					fetchPic.y = rect.top;
					fetchPic.width = rect.Width();
					fetchPic.height = rect.Height();

					FetchPic(&fetchPic);
				}
			}
			
		}
		else if (m_nCursor==1) // manipulate
		{
			CClientDC dcdc(NULL);
			double dVx = (double)m_xSize/(double)m_screenX;
			double dVy = (double)m_ySize/(double)m_screenY;
			MyEvent myEvent;
			myEvent.nName = 2;
			myEvent.ParamX = int((double)pMy.x / (double)dVx);
			myEvent.ParamY = int((double)pMy.y / (double)dVy);
			
			SendEvents(&myEvent);
		}
		
	}
	
	CDialog::OnLButtonUp(nFlags, point);
}

void CManipulateDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	CPoint pMy;
	pMy.x = point.x - m_nPicLeft;
	pMy.y = point.y - m_nPicTop;
	CRect rect(0, 0, m_xSize, m_ySize);
	if (rect.PtInRect(pMy))
	{
		if (!m_bIsBegin) return;
		if (m_nCursor==1) // manipulate
		{
			CClientDC dcdc(NULL);
			double dVx = (double)m_xSize/(double)m_screenX;
			double dVy = (double)m_ySize/(double)m_screenY;

			MyEvent myEvent;
			myEvent.nName = 3;
			myEvent.ParamX = int((double)pMy.x / (double)dVx);
			myEvent.ParamY = int((double)pMy.y / (double)dVy);
			
			SendEvents(&myEvent);
		}
	}

	CDialog::OnMouseMove(nFlags, point);

}

void CManipulateDlg::SendEvents(MyEvent *myEvent)
{
	if (myEvent == NULL || !m_bIsBegin) return;
	PACKAGE pkg;
	pkg.name = 5;
	pkg.len = sizeof(MyEvent);
	pkg.buf = (char*)myEvent;
	SendPackage(&pkg, m_bIsGuaranteed);
}

void CManipulateDlg::ReceiveEvent(MyEvent *myEvent)
{
	switch(myEvent->nName)
	{
	case 1:
		{
			CPoint point;
			point.x = int(((double)65535/(double)m_nMyScrX)*(double)(myEvent->ParamX));
			point.y = int(((double)65535/(double)m_nMyScrY)*(double)(myEvent->ParamY));
			mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN, point.x, point.y, 0, 0);
			
			break;
		}
	case 2:
		{
			CPoint point;
			point.x = int(((double)65535/(double)m_nMyScrX)*(double)(myEvent->ParamX));
			point.y = int(((double)65535/(double)m_nMyScrY)*(double)(myEvent->ParamY));
			mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTUP, point.x, point.y, 0, 0);

			break;
		}
	case 3:
		{
			CPoint point;
			point.x = int(((double)65535/(double)m_nMyScrX)*(double)(myEvent->ParamX));
			point.y = int(((double)65535/(double)m_nMyScrY)*(double)(myEvent->ParamY));
			mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE, point.x, point.y, 0, 0);
		
			break;
		}
	}
}

void CManipulateDlg::OnOption() 
{
	CDlgOption dlg;
	dlg.m_nWidth = m_xSize;
	dlg.m_nHeight = m_ySize;
	if (dlg.DoModal()==IDOK)
	{
		m_xSize = dlg.m_nWidth;
		m_ySize = dlg.m_nHeight;
		CClientDC dc(this);
		VERIFY(m_bmpScreen.DeleteObject());
		m_bmpScreen.CreateCompatibleBitmap(&dc, m_xSize, m_ySize);
	}
}

void CManipulateDlg::OnCursor2() 
{
	m_nCursor = 2;
}

void CManipulateDlg::OnCutsor1() 
{
	m_nCursor = 1;
}

BOOL CManipulateDlg::DestroyWindow() 
{
	OnCutsor1();
	DestroyChat();
	return CDialog::DestroyWindow();
}

void CManipulateDlg::FetchPic(LPFETCHPIC fetchPic)
{
	PACKAGE pkg;
	pkg.name = 3;
	pkg.len = sizeof(FETCHPIC);
	pkg.buf = (char*)fetchPic;
	//////send now
	SendPackage(&pkg, m_bIsGuaranteed);
}

/*
void CManipulateDlg::OnEnter() 
{
	if (!m_bIsBegin) return;
	UpdateData();
	m_strChat += "Local: ";
	m_strChat += m_strInput + "\r\n";
	
	PACKAGE pkg;
	pkg.name = 1;
	pkg.len = m_strInput.GetLength();
	pkg.buf = (char*)m_strInput.GetBuffer(pkg.len);
	m_strInput.ReleaseBuffer();
	//////send now
	SendPackage(&pkg, m_bIsGuaranteed);
	UpdateData(FALSE);

	CEdit* pWndEdit = (CEdit*)GetDlgItem(IDC_CHAT);
	int nLines = pWndEdit->GetLineCount();
	pWndEdit->LineScroll(nLines);

	//pWndEdit->SetSel(30000, 30000);
	//int a = pWndEdit->GetLineCount();
	//int b = pWndEdit->GetScrollPos(SB_VERT);
	//pWndEdit->SetScrollPos(SB_VERT, a/4);//
	//b = pWndEdit->GetScrollPos(SB_VERT);
}
*/
BOOL CManipulateDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	switch(m_nCursor)
	{
	case 1:
		return CDialog::OnSetCursor(pWnd, nHitTest, message);
	case 2:
		{
			HCURSOR hCursor = ::LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDC_POSITION));
			::SetCursor(hCursor);
			return TRUE;;
		}
	default:
		ASSERT(FALSE);
	}

	return TRUE;;
}

void CManipulateDlg::OnChatNow() 
{
	ShowChatWnd(SW_SHOW);
}

void CManipulateDlg::OnButton1() 
{
	//CreateChat(NULL);
}

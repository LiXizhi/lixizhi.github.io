
enum NECCOMMAND {cmdLogin, cmdLogout, cmdResponse, cmdTransport, cmdTellStop, cmdReDrawNetWnd, cmdExitThread, cmdChat};
struct SENDNETCONENTS
{
	NECCOMMAND cmd;
	char cChat[32];
	//char name[16];
	//int nRow;
	//BYTE addRows[SHAPEROW][TOTALCOL];
	//char SendNetName[MAX_MENCOUNT][16];
	//BYTE map[TOTALROW][TOTALCOL];
};

extern void DoSend(LPDPLAYINFO lpDPInfo, SENDNETCONENTS* lpConents);
extern void DoMessage(LPDPLAYINFO lpDPInfo, SENDNETCONENTS* lpConents, DPID idFrom, DPID idTo);
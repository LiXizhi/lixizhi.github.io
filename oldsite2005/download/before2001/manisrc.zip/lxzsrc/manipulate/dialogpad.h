#define IDIRECTPLAY2_OR_GREATER
#include <windows.h>
#include <windowsx.h>
#include <dplay.h>

// constants
const DWORD MAXPLAYERS = 10;			// max no. players in the session

// structure used to store DirectPlay information
typedef struct {
	LPDIRECTPLAY3A	lpDirectPlay3A;		// IDirectPlay3A interface pointer
	HANDLE			hPlayerEvent;		// player event to use
	DPID			dpidPlayer;			// ID of player created
	BOOL			bIsHost;			// TRUE if we are hosting the session
} DPLAYINFO, *LPDPLAYINFO;

// guid for this application
// {5BFDB060-06A4-11d0-9C4F-00A0C905425E}
DEFINE_GUID(MFCCHAT_GUID, 
0x5bfdb060, 0x6a4, 0x11d0, 0x9c, 0x4f, 0x0, 0xa0, 0xc9, 0x5, 0x42, 0x5e);

// prototypes
extern void			ErrorBox(LPSTR lpszErrorStr, HRESULT hr);
extern HRESULT			SetupConnection(CWnd* pParent, LPDPLAYINFO lpDPInfo);
extern HRESULT			ShutdownConnection(LPDPLAYINFO lpDPInfo);

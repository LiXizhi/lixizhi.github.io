// DlgChat.cpp : implementation file
//

#include "stdafx.h"
#include "manipulate.h"
#include "DlgChat.h"

#include "dialogpad.h"
#include "dialog.h"
#include "ManipulateDlg.h"
#include "interact.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgChat dialog


CDlgChat::CDlgChat(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgChat::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgChat)
	m_strSend = _T("");
	//}}AFX_DATA_INIT
}


void CDlgChat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgChat)
	DDX_Text(pDX, IDC_EDIT, m_strSend);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgChat, CDialog)
	//{{AFX_MSG_MAP(CDlgChat)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgChat message handlers

void CDlgChat::OnSend() 
{
	UpdateData();
	
	SENDNETCONENTS context;
	context.cmd = cmdChat;
	memcpy(context.cChat, m_strSend, sizeof(context.cChat));
	
	DoSend( &(((CManipulateDlg*)GetParent())->m_DPInfo), &context);
}

/////////////////////////////////////////////////////////////////////////////
// CDlgConnect dialog
//#include "dialogpad.h"
class CDlgConnect : public CDialog
{
// Construction
public:
	UINT m_idTimer;
	LPDIRECTPLAY3A m_lpDirectPlay3A;
	LPDPLAYINFO m_lpDPInfo;
	CDlgConnect(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgConnect)
	enum { IDD = IDD_CONNECTDIALOG };
	CComboBox	m_cbConnect;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgConnect)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgConnect)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSelchangeSpcombo();
	afx_msg void OnHostbutton();
	afx_msg void OnJoinbutton();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

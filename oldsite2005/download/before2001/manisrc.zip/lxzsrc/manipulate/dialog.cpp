/*==========================================================================
 *
 *  Copyright (C) 1996-1997 Microsoft Corporation.  All Rights Reserved.
 *
 *  File:       dialog.cpp
 *  Content:	Creates a dialog to query the user for connection settings
 *				and establish a connection.
 *
 ***************************************************************************/

#include "stdafx.h"
#include "resource.h"
#define INITGUID
#include <cguid.h>

#include "dialogpad.h"
#include "dialog.h"
#include "interact.h"

/////////////
HANDLE			ghReceiveThread = NULL;			// handle of receive thread
DWORD			gidReceiveThread = 0;			// id of receive thread
HANDLE			ghKillReceiveEvent = NULL;		// event used to kill receive thread

// constants
const DWORD MAXNAMELEN		= 200;		// max size of a session or player name
const UINT	TIMERID			= 1;		// timer ID to use
const UINT	TIMERINTERVAL	= 1000;		// timer interval
const DWORD	MAXSTRLEN			= 200;			// max size of a temporary string

// prototypes
DWORD WINAPI ReceiveThread(LPVOID lpThreadParameter);
HRESULT			ReceiveMessage(LPDPLAYINFO lpDPInfo);
void			ErrorBox(LPSTR lpszErrorStr, HRESULT hr);
HRESULT			SetupConnection(CWnd* pParent, LPDPLAYINFO lpDPInfo);
HRESULT			ShutdownConnection(LPDPLAYINFO lpDPInfo);

HRESULT			CreateDirectPlayInterface(LPDIRECTPLAY3A *lplpDirectPlay3A );
BOOL FAR PASCAL DirectPlayEnumConnectionsCallback(LPCGUID lpguidSP,
							LPVOID lpConnection, DWORD dwConnectionSize,
							LPCDPNAME lpName, DWORD dwFlags, LPVOID lpContext);
HRESULT			DestroyDirectPlayInterface(HWND hWnd, LPDIRECTPLAY3A lpDirectPlay3A);
HRESULT			HostSession(LPDIRECTPLAY3A lpDirectPlay3A,
							LPSTR lpszSessionName, LPSTR lpszPlayerName,
							LPDPLAYINFO lpDPInfo);
HRESULT			JoinSession(LPDIRECTPLAY3A lpDirectPlay3A,
							LPGUID lpguidSessionInstance, LPSTR lpszPlayerName,
							LPDPLAYINFO lpDPInfo);
HRESULT			EnumSessions(HWND hWnd, LPDIRECTPLAY3A lpDirectPlay3A);

HRESULT			GetConnection(HWND hWnd, LPVOID *lplpConnection);
void			DeleteConnectionList(HWND hWnd);
HRESULT			GetSessionInstanceGuid(HWND hWnd, LPGUID lpguidSessionInstance);
void			SelectSessionInstance(HWND hWnd, LPGUID lpguidSessionInstance);
void			DeleteSessionInstanceList(HWND hWnd);
void			EnableDlgButton(HWND hDlg, int nIDDlgItem, BOOL bEnable);
HRESULT			ConnectUsingDialog(CWnd* pParent, LPDPLAYINFO lpDPInfo);
void			ErrorBox(LPSTR lpszErrorStr, HRESULT hr);

//////////////////////
DWORD WINAPI ReceiveThread(LPVOID lpThreadParameter)
{
    LPDPLAYINFO	lpDPInfo = (LPDPLAYINFO) lpThreadParameter;
	HANDLE		eventHandles[2];

	eventHandles[0] = lpDPInfo->hPlayerEvent;
	eventHandles[1] = ghKillReceiveEvent;

	// loop waiting for player events. If the kill event is signaled
	// the thread will exit
	while (WaitForMultipleObjects(2, eventHandles, FALSE, INFINITE) == WAIT_OBJECT_0)
	{
		// receive any messages in the queue
		ReceiveMessage(lpDPInfo);
	}

	ExitThread(0);

	return (0);
}

HRESULT ReceiveMessage(LPDPLAYINFO lpDPInfo)
{
	DPID				idFrom, idTo;
	LPVOID				lpvMsgBuffer;
	DWORD				dwMsgBufferSize;
	HRESULT				hr;

	lpvMsgBuffer = NULL;
	dwMsgBufferSize = 0;
	
	SENDNETCONENTS* lpConents;

	// loop to read all messages in queue
	do
	{
		// loop until a single message is successfully read
		do
		{
			// read messages from any player, including system player
			idFrom = 0;
			idTo = 0;

			hr = lpDPInfo->lpDirectPlay3A->Receive(&idFrom, &idTo, DPRECEIVE_ALL,
												   lpvMsgBuffer, &dwMsgBufferSize);

			// not enough room, so resize buffer
			if (hr == DPERR_BUFFERTOOSMALL)
			{
				if (lpvMsgBuffer)
					GlobalFreePtr(lpvMsgBuffer);
				lpvMsgBuffer = GlobalAllocPtr(GHND, dwMsgBufferSize);
				if (lpvMsgBuffer == NULL)
					hr = DPERR_OUTOFMEMORY;
			}
		} while (hr == DPERR_BUFFERTOOSMALL);

		if ((SUCCEEDED(hr)) &&							// successfully read a message
			(dwMsgBufferSize >= sizeof(DPMSG_GENERIC)))	// and it is big enough
		{
			// check for system message
			if (idFrom == DPID_SYSMSG)
			{
			}
			else
			{
				lpConents = ((SENDNETCONENTS *)lpvMsgBuffer);
				DoMessage(lpDPInfo, lpConents, idFrom, idTo);
			}
		}
	} while (SUCCEEDED(hr));

	// free any memory we created
	if (lpvMsgBuffer)
		GlobalFreePtr(lpvMsgBuffer);

	return (DP_OK);
}

HRESULT ConnectUsingDialog(CWnd* pParent, LPDPLAYINFO lpDPInfo)
{
	CDlgConnect dlg(pParent);
	dlg.m_lpDPInfo = lpDPInfo;
	if (dlg.DoModal()==IDOK)
	{
		return (DP_OK);
	}
	else
	{
		return (DPERR_USERCANCEL);
	}
}

BOOL FAR PASCAL DirectPlayEnumConnectionsCallback(
						LPCGUID     lpguidSP,
						LPVOID		lpConnection,
						DWORD		dwConnectionSize,
						LPCDPNAME   lpName,
						DWORD 		dwFlags,
						LPVOID 		lpContext)
{

    HWND			hWnd = (HWND) lpContext;
    LRESULT			iIndex;
	LPVOID			lpConnectionBuffer;

	// store service provider name in combo box
	iIndex = SendDlgItemMessage(hWnd, IDC_SPCOMBO, CB_ADDSTRING, 0, 
									(LPARAM) lpName->lpszShortNameA);
	if (iIndex == CB_ERR)
		return (TRUE);

	// make space for connection shortcut
	lpConnectionBuffer = GlobalAllocPtr(GHND, dwConnectionSize);
	if (lpConnectionBuffer == NULL)
		return (TRUE);

	// store pointer to connection shortcut in combo box
	memcpy(lpConnectionBuffer, lpConnection, dwConnectionSize);
	SendDlgItemMessage(hWnd, IDC_SPCOMBO, CB_SETITEMDATA, (WPARAM) iIndex, 
									(LPARAM) lpConnectionBuffer);
	return (TRUE);
}


HRESULT CreateDirectPlayInterface( LPDIRECTPLAY3A *lplpDirectPlay3A )
{
	HRESULT				hr;
	LPDIRECTPLAY3A		lpDirectPlay3A = NULL;

	// Create an IDirectPlay3 interface
	hr = CoCreateInstance(	CLSID_DirectPlay, NULL, CLSCTX_INPROC_SERVER, 
							IID_IDirectPlay3A, (LPVOID*)&lpDirectPlay3A);

	// return interface created
	*lplpDirectPlay3A = lpDirectPlay3A;

	return (hr);
}

HRESULT DestroyDirectPlayInterface(HWND hWnd, LPDIRECTPLAY3A lpDirectPlay3A)
{
	HRESULT		hr = DP_OK;

	if (lpDirectPlay3A)
	{
		DeleteSessionInstanceList(hWnd);
		EnableDlgButton(hWnd, IDC_JOINBUTTON, FALSE);

		hr = lpDirectPlay3A->Release();
	}

	return (hr);
}

HRESULT HostSession(LPDIRECTPLAY3A lpDirectPlay3A,
					LPSTR lpszSessionName, LPSTR lpszPlayerName,
					LPDPLAYINFO lpDPInfo)
{
	DPID				dpidPlayer;
	DPNAME				dpName;
	DPSESSIONDESC2		sessionDesc;
	HRESULT				hr;

	// check for valid interface
	if (lpDirectPlay3A == NULL)
		return (DPERR_INVALIDOBJECT);

	// host a new session
	ZeroMemory(&sessionDesc, sizeof(DPSESSIONDESC2));
	sessionDesc.dwSize = sizeof(DPSESSIONDESC2);
    sessionDesc.dwFlags = DPSESSION_MIGRATEHOST | DPSESSION_KEEPALIVE;
    sessionDesc.guidApplication = MFCCHAT_GUID;
    sessionDesc.dwMaxPlayers = MAXPLAYERS;
	sessionDesc.lpszSessionNameA = lpszSessionName;

	hr = lpDirectPlay3A->Open(&sessionDesc, DPOPEN_CREATE);
	if FAILED(hr)
	{
		MessageBeep(MB_OK);
		lpDirectPlay3A->Close();
		return (hr);
	}

	// fill out name structure
	ZeroMemory(&dpName, sizeof(DPNAME));
	dpName.dwSize = sizeof(DPNAME);
	dpName.lpszShortNameA = lpszPlayerName;
	dpName.lpszLongNameA = NULL;

	// create a player with this name
	hr = lpDirectPlay3A->CreatePlayer(&dpidPlayer, &dpName, 
							lpDPInfo->hPlayerEvent, NULL, 0, 0);
	if FAILED(hr)
	{
		MessageBeep(MB_OK);
		lpDirectPlay3A->Close();
		return (hr);
	}

	// return connection info
	lpDPInfo->lpDirectPlay3A = lpDirectPlay3A;
	lpDPInfo->dpidPlayer = dpidPlayer;
	lpDPInfo->bIsHost = TRUE;

	return (DP_OK);
}

HRESULT JoinSession(LPDIRECTPLAY3A lpDirectPlay3A,
					LPGUID lpguidSessionInstance, LPSTR lpszPlayerName,
					LPDPLAYINFO lpDPInfo)
{
	DPID				dpidPlayer;
	DPNAME				dpName;
	DPSESSIONDESC2		sessionDesc;
	HRESULT				hr;

	// check for valid interface
	if (lpDirectPlay3A == NULL)
		return (DPERR_INVALIDOBJECT);

	// join existing session
	ZeroMemory(&sessionDesc, sizeof(DPSESSIONDESC2));
	sessionDesc.dwSize = sizeof(DPSESSIONDESC2);
    sessionDesc.guidInstance = *lpguidSessionInstance;

	hr = lpDirectPlay3A->Open(&sessionDesc, DPOPEN_JOIN);
	if FAILED(hr)
	{
		MessageBeep(MB_OK);
		lpDirectPlay3A->Close();
		return (hr);
	}

	// fill out name structure
	ZeroMemory(&dpName, sizeof(DPNAME));
	dpName.dwSize = sizeof(DPNAME);
	dpName.lpszShortNameA = lpszPlayerName;
	dpName.lpszLongNameA = NULL;

	// create a player with this name
	hr = lpDirectPlay3A->CreatePlayer(&dpidPlayer, &dpName, 
							lpDPInfo->hPlayerEvent, NULL, 0, 0);
	if FAILED(hr)
	{
		MessageBeep(MB_OK);
		lpDirectPlay3A->Close();
		return (hr);
	}

	// return connection info
	lpDPInfo->lpDirectPlay3A = lpDirectPlay3A;
	lpDPInfo->dpidPlayer = dpidPlayer;
	lpDPInfo->bIsHost = FALSE;

	return (DP_OK);
}

BOOL FAR PASCAL EnumSessionsCallback(
						LPCDPSESSIONDESC2	lpSessionDesc,
						LPDWORD				lpdwTimeOut,
						DWORD				dwFlags,
						LPVOID				lpContext)
{
	HWND			hWnd = (HWND) lpContext;
	LPGUID			lpGuid;
	LONG			iIndex;

	// see if last session has been enumerated
    if (dwFlags & DPESC_TIMEDOUT)
		return (FALSE);						

	// store session name in list
	iIndex = SendDlgItemMessage( hWnd, IDC_SESSIONLIST, LB_ADDSTRING, 
								(WPARAM) 0, (LPARAM) lpSessionDesc->lpszSessionNameA);

	if (iIndex == LB_ERR)
		return (TRUE);


	// make space for session instance guid
	lpGuid = (LPGUID) GlobalAllocPtr( GHND, sizeof(GUID) );
	if (lpGuid == NULL)
		return (TRUE);

	// store pointer to guid in list
	*lpGuid = lpSessionDesc->guidInstance;
	SendDlgItemMessage( hWnd, IDC_SESSIONLIST, LB_SETITEMDATA, (WPARAM) iIndex, (LPARAM) lpGuid);
	return (TRUE);
}

HRESULT EnumSessions(HWND hWnd, LPDIRECTPLAY3A lpDirectPlay3A)
{
	DPSESSIONDESC2	sessionDesc;
	GUID			guidSessionInstance;
	LONG			iIndex;
	HRESULT			hr;

	// check for valid interface
	if (lpDirectPlay3A == NULL)
		return (DPERR_INVALIDOBJECT);

	// get guid of currently selected session
	guidSessionInstance = GUID_NULL;
	hr = GetSessionInstanceGuid(hWnd, &guidSessionInstance);

	// delete existing session list
	DeleteSessionInstanceList(hWnd);

	// add sessions to session list
	ZeroMemory(&sessionDesc, sizeof(DPSESSIONDESC2));
	sessionDesc.dwSize = sizeof(DPSESSIONDESC2);
    sessionDesc.guidApplication = MFCCHAT_GUID;

	hr = lpDirectPlay3A->EnumSessions(&sessionDesc, 0, EnumSessionsCallback,
									  hWnd, DPENUMSESSIONS_AVAILABLE | DPENUMSESSIONS_ASYNC);

	// select the session that was previously selected
	SelectSessionInstance(hWnd, &guidSessionInstance);

	// hilite "Join" button only if there are sessions to join
	iIndex = SendDlgItemMessage(hWnd, IDC_SESSIONLIST, LB_GETCOUNT,
						   (WPARAM) 0, (LPARAM) 0);

	EnableDlgButton(hWnd, IDC_JOINBUTTON, (iIndex > 0) ? TRUE : FALSE);

	return (hr);
}

HRESULT GetConnection(HWND hWnd, LPVOID *lplpConnection)
{
	LONG	iIndex;

	// get index of the item currently selected in the combobox
	iIndex = SendDlgItemMessage(hWnd, IDC_SPCOMBO, CB_GETCURSEL,
								(WPARAM) 0, (LPARAM) 0);
	if (iIndex == CB_ERR)
		return (DPERR_GENERIC);

	// get the pointer to the connection shortcut associated with
	// the item
	iIndex = SendDlgItemMessage(hWnd, IDC_SPCOMBO, CB_GETITEMDATA,
								(WPARAM) iIndex, (LPARAM) 0);
	if (iIndex == CB_ERR)
		return (DPERR_GENERIC);

	*lplpConnection = (LPVOID) iIndex;

	return (DP_OK);
}

void DeleteConnectionList(HWND hWnd)
{
	WPARAM	i;
	LONG	lpData;
	
	// destroy the GUID's stored with each service provider name
	i = 0;
	while (TRUE)
	{
		// get data pointer stored with item
		lpData = SendDlgItemMessage(hWnd, IDC_SPCOMBO, CB_GETITEMDATA,
									(WPARAM) i, (LPARAM) 0);
		if (lpData == CB_ERR)		// error getting data
			break;

		if (lpData != 0)			// no data to delete
			GlobalFreePtr((LPVOID) lpData);

		i += 1;
	}

	// delete all items in combo box
	SendDlgItemMessage(hWnd, IDC_SPCOMBO, CB_RESETCONTENT,
								(WPARAM) 0, (LPARAM) 0);
}

HRESULT GetSessionInstanceGuid(HWND hWnd, LPGUID lpguidSessionInstance)
{
	LONG	iIndex;

	// get guid for session
	iIndex = SendDlgItemMessage(hWnd, IDC_SESSIONLIST, LB_GETCURSEL,
								(WPARAM) 0, (LPARAM) 0);
	if (iIndex == LB_ERR)
		return (DPERR_GENERIC);

	iIndex = SendDlgItemMessage(hWnd, IDC_SESSIONLIST, LB_GETITEMDATA,
								(WPARAM) iIndex, (LPARAM) 0);
	if ((iIndex == LB_ERR) || (iIndex == 0))
		return (DPERR_GENERIC);

	*lpguidSessionInstance = *((LPGUID) iIndex);

	return (DP_OK);
}

void DeleteSessionInstanceList(HWND hWnd)
{
	WPARAM	i;
	LONG	lpData;
	
	// destroy the GUID's stored with each session name
	i = 0;
	while (TRUE)
	{
		// get data pointer stored with item
		lpData = SendDlgItemMessage(hWnd, IDC_SESSIONLIST, LB_GETITEMDATA,
									(WPARAM) i, (LPARAM) 0);
		if (lpData == CB_ERR)		// error getting data
			break;

		if (lpData == 0)			// no data to delete
			continue;

		GlobalFreePtr((LPVOID) lpData);
		i += 1;
	}

	// delete all items in list
	SendDlgItemMessage(hWnd, IDC_SESSIONLIST, LB_RESETCONTENT,
								(WPARAM) 0, (LPARAM) 0);
}

void SelectSessionInstance(HWND hWnd, LPGUID lpguidSessionInstance)
{
	WPARAM	i, iIndex;
	LONG	lpData;
	
	// loop over the GUID's stored with each session name
	// to find the one that matches what was passed in
	i = 0;
	iIndex = 0;
	while (TRUE)
	{
		// get data pointer stored with item
		lpData = SendDlgItemMessage(hWnd, IDC_SESSIONLIST, LB_GETITEMDATA,
									(WPARAM) i, (LPARAM) 0);
		if (lpData == CB_ERR)		// error getting data
			break;

		if (lpData == 0)			// no data to compare to
			continue;

		// guid matches
		if (IsEqualGUID(*lpguidSessionInstance, *((LPGUID) lpData)))
		{
			iIndex = i;				// store index of this string
			break;
		}

		i += 1;
	}

	// select this item
	SendDlgItemMessage(hWnd, IDC_SESSIONLIST, LB_SETCURSEL, (WPARAM) iIndex, (LPARAM) 0);
}

void EnableDlgButton(HWND hDlg, int nIDDlgItem, BOOL bEnable)
{
	EnableWindow(GetDlgItem(hDlg, nIDDlgItem), bEnable);
}

void ErrorBox(LPSTR lpszErrorStr, HRESULT hr)
{
	char	szStr[MAXSTRLEN];

	wsprintf(szStr, lpszErrorStr, hr);

	MessageBox(NULL, szStr, "Error", MB_OK);
}

/////////////////////////SetupConnect//////////////////////////

HRESULT SetupConnection(CWnd* pParent, LPDPLAYINFO lpDPInfo)
{
	HRESULT		hr;

	ZeroMemory(lpDPInfo, sizeof(DPLAYINFO));

	// create event used by DirectPlay to signal a message has arrived
	lpDPInfo->hPlayerEvent = CreateEvent(NULL,		// no security
										 FALSE,		// auto reset
										 FALSE,		// initial event reset
										 NULL);		// no name
	if (lpDPInfo->hPlayerEvent == NULL)
	{
		hr = DPERR_NOMEMORY;
		MessageBeep(MB_OK);
	}

	// create event used to signal that the receive thread should exit
	ghKillReceiveEvent = CreateEvent(NULL,		// no security
									 FALSE,		// auto reset
									 FALSE,		// initial event reset
									 NULL);		// no name
	if (ghKillReceiveEvent == NULL)
	{
		hr = DPERR_NOMEMORY;
		MessageBeep(MB_OK);
	}

	// create thread to receive player messages
	ghReceiveThread = CreateThread(NULL,			// default security
								   0,				// default stack size
								   ReceiveThread,	// pointer to thread routine
								   lpDPInfo,		// argument for thread
								   0,				// start it right away
								   &gidReceiveThread);
	if (ghReceiveThread == NULL)
	{
		hr = DPERR_NOMEMORY;
		MessageBeep(MB_OK);
	}

	//ask the user for settings
	if(FAILED(ConnectUsingDialog(pParent, lpDPInfo)))
	{	
		MessageBeep(MB_OK);
		ShutdownConnection(lpDPInfo);
		return (DP_OK);
	}
	return (DP_OK);	
}

HRESULT ShutdownConnection(LPDPLAYINFO lpDPInfo)
{
	if (ghReceiveThread)
	{
		// wake up receive thread and wait for it to quit
		SetEvent(ghKillReceiveEvent);
		WaitForSingleObject(ghReceiveThread, INFINITE);

		CloseHandle(ghReceiveThread);
		ghReceiveThread = NULL;
	}

	if (ghKillReceiveEvent)
	{
		CloseHandle(ghKillReceiveEvent);
		ghKillReceiveEvent = NULL;
	}

	if (lpDPInfo->lpDirectPlay3A)
	{
		if (lpDPInfo->dpidPlayer)
		{
			lpDPInfo->lpDirectPlay3A->DestroyPlayer(lpDPInfo->dpidPlayer);
			lpDPInfo->dpidPlayer = 0;
		}
		lpDPInfo->lpDirectPlay3A->Close();
		lpDPInfo->lpDirectPlay3A->Release();
		lpDPInfo->lpDirectPlay3A = NULL;
	}

	if (lpDPInfo->hPlayerEvent)
	{
		CloseHandle(lpDPInfo->hPlayerEvent);
		lpDPInfo->hPlayerEvent = NULL;
	}

	return (DP_OK);
}

/////////////////////////////////////////////////////////////////////////////
// CDlgConnect dialog

CDlgConnect::CDlgConnect(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgConnect::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgConnect)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgConnect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgConnect)
	DDX_Control(pDX, IDC_SPCOMBO, m_cbConnect);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgConnect, CDialog)
	//{{AFX_MSG_MAP(CDlgConnect)
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_CBN_SELCHANGE(IDC_SPCOMBO, OnSelchangeSpcombo)
	ON_BN_CLICKED(IDC_HOSTBUTTON, OnHostbutton)
	ON_BN_CLICKED(IDC_JOINBUTTON, OnJoinbutton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgConnect message handlers

BOOL CDlgConnect::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	HRESULT					hr;
	
	// save the connection info pointer
    m_lpDirectPlay3A = NULL;

	// Create an IDirectPlay3 interface
	hr = CreateDirectPlayInterface(&m_lpDirectPlay3A);
	if (FAILED(hr))
	{
		MessageBeep(MB_OK);
		::MessageBox(NULL, "This application requires DirectX 5 or later.", NULL, MB_OK);
		CDialog::OnOK();
		return TRUE;
	}
	// set first item in the connections combo box
	::SendDlgItemMessage(m_hWnd, IDC_SPCOMBO, CB_ADDSTRING, (WPARAM) 0, (LPARAM) "<Select a service provider>");
	::SendDlgItemMessage(m_hWnd, IDC_SPCOMBO, CB_SETITEMDATA, (WPARAM) 0, (LPARAM) 0);
	::SendDlgItemMessage(m_hWnd, IDC_SPCOMBO, CB_SETCURSEL, (WPARAM) 0, (LPARAM) 0);

	// put all the available connections in a combo box
	m_lpDirectPlay3A->EnumConnections(&MFCCHAT_GUID, DirectPlayEnumConnectionsCallback, m_hWnd, 0);

	// setup initial button state
	EnableDlgButton(m_hWnd, IDC_HOSTBUTTON, FALSE);
	EnableDlgButton(m_hWnd, IDC_JOINBUTTON, FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgConnect::OnDestroy() 
{
	// delete information stored along with the lists
	DeleteConnectionList(m_hWnd);
	DeleteSessionInstanceList(m_hWnd);

	CDialog::OnDestroy();
}

void CDlgConnect::OnTimer(UINT nIDEvent) 
{
	// refresh the session list
	EnumSessions(m_hWnd, m_lpDirectPlay3A);
	CDialog::OnTimer(nIDEvent);
}

void CDlgConnect::OnSelchangeSpcombo() 
{
	HRESULT					hr;
	LPVOID					lpConnection = NULL;

	HWND hWnd = m_hWnd;
	
	// service provider changed, so rebuild display and
	// delete any existing DirectPlay interface
	::KillTimer(hWnd, m_idTimer); 
	hr = DestroyDirectPlayInterface(hWnd, m_lpDirectPlay3A);
	m_lpDirectPlay3A = NULL;

	// get pointer to the selected connection
	hr = GetConnection(hWnd, &lpConnection);
	if FAILED(hr)
	{
		MessageBeep(MB_OK);
		if (hr != DPERR_USERCANCEL)
		ErrorBox("Could not select service provider because of error 0x%08X", hr);
		return;
	}

	if (lpConnection)
	{
		/*
		 * Create a new DPlay interface.
		 */

		hr = CreateDirectPlayInterface( &m_lpDirectPlay3A );

		if ((FAILED(hr)) || (NULL == m_lpDirectPlay3A))
		{
			MessageBeep(MB_OK);
			if (hr != DPERR_USERCANCEL)
			ErrorBox("Could not select service provider because of error 0x%08X", hr);
			return;
		}

		// initialize the connection
		hr = m_lpDirectPlay3A->InitializeConnection(lpConnection, 0);
		if FAILED(hr)
		{
			MessageBeep(MB_OK);
			if (hr != DPERR_USERCANCEL)
			ErrorBox("Could not select service provider because of error 0x%08X", hr);
			return;
		}

		// OK to host now
		::EnableDlgButton(hWnd, IDC_HOSTBUTTON, TRUE);

		// start enumerating the sessions
		hr = EnumSessions(hWnd, m_lpDirectPlay3A);
		if FAILED(hr)
		{
			MessageBeep(MB_OK);
			if (hr != DPERR_USERCANCEL)
			ErrorBox("Could not select service provider because of error 0x%08X", hr);
			return;
		}
		// set a timer to refresh the session list
		m_idTimer = ::SetTimer(hWnd, TIMERID, TIMERINTERVAL, NULL);
	}
	else
	{
		// They've selected the generic option "<Select a service provider>"
		::EnableDlgButton(hWnd, IDC_HOSTBUTTON, FALSE);
		::EnableDlgButton(hWnd, IDC_JOINBUTTON, FALSE);
	}
	return;
}

void CDlgConnect::OnHostbutton() 
{
	HRESULT					hr;
	char					szSessionName[MAXNAMELEN];
	char					szPlayerName[MAXNAMELEN];
	DWORD					dwNameSize;

	LPVOID					lpConnection = NULL;
	HWND hWnd = m_hWnd;

	// should have an interface by now
	if (m_lpDirectPlay3A == NULL)
		return;

	::KillTimer(hWnd, m_idTimer ); 
	// use computer name for session name
	dwNameSize = MAXNAMELEN;
	if (!GetComputerName(szSessionName, &dwNameSize))
		lstrcpy(szSessionName, "Session");

	// use user name for player name
	dwNameSize = MAXNAMELEN;
	if (!GetUserName(szPlayerName, &dwNameSize))
		lstrcpy(szPlayerName, "unknown");

	// host a new session on this service provider
	hr = HostSession(m_lpDirectPlay3A, szSessionName, szPlayerName, m_lpDPInfo);
	if FAILED(hr)
	{
		MessageBeep(MB_OK);
		ErrorBox("Could not host session because of error 0x%08X", hr);
		return;
	}

	// dismiss dialog if we succeeded in hosting
	CDialog::OnOK();
	return;
}

void CDlgConnect::OnJoinbutton() 
{
	HWND hWnd = m_hWnd;
	HRESULT					hr;
	DWORD					dwNameSize;
	char					szPlayerName[MAXNAMELEN];
	GUID					guidSessionInstance;
	
	// should have an interface by now
	if (m_lpDirectPlay3A == NULL)
		return;

	::KillTimer(hWnd, m_idTimer ); 
	// get guid of selected session instance
	hr = GetSessionInstanceGuid(hWnd, &guidSessionInstance);
	if FAILED(hr)
	{
		MessageBeep(MB_OK);
		ErrorBox("Could not join session because of error 0x%08X", hr);
		return;
	}

	// use user name for player name
	dwNameSize = MAXNAMELEN;
	if (!GetUserName(szPlayerName, &dwNameSize))
		lstrcpy(szPlayerName, "unknown");

	// join this session
	hr = JoinSession(m_lpDirectPlay3A, &guidSessionInstance, szPlayerName, m_lpDPInfo);

	if FAILED(hr)
	{
		MessageBeep(MB_OK);
		ErrorBox("Could not join session because of error 0x%08X", hr);
		return;
	}
	// dismiss dialog if we succeeded in joining
	CDialog::OnOK();
    return;
}

void CDlgConnect::OnCancel() 
{
	HRESULT					hr;
	::KillTimer(m_hWnd, m_idTimer ); 
	// delete any interface created if cancelling
	hr = DestroyDirectPlayInterface(m_hWnd, m_lpDirectPlay3A);
	m_lpDirectPlay3A = NULL;

	CDialog::OnCancel();
}

#if !defined(AFX_DLGCHAT_H__6DEEB322_1A88_11D2_8FDD_444553540000__INCLUDED_)
#define AFX_DLGCHAT_H__6DEEB322_1A88_11D2_8FDD_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgChat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgChat dialog

class CDlgChat : public CDialog
{
// Construction
public:
	CDlgChat(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgChat)
	enum { IDD = IDD_CHAT };
	CString	m_strSend;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgChat)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgChat)
	afx_msg void OnSend();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCHAT_H__6DEEB322_1A88_11D2_8FDD_444553540000__INCLUDED_)

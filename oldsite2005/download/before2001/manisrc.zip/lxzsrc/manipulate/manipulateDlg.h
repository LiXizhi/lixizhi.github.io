// manipulateDlg.h : header file
//

#if !defined(AFX_MANIPULATEDLG_H__6110C588_5AE7_11D2_92B3_E36348BD1D08__INCLUDED_)
#define AFX_MANIPULATEDLG_H__6110C588_5AE7_11D2_92B3_E36348BD1D08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CManipulateDlg dialog

typedef struct {
	int x;
	int y;
	int width;
	int height;
	char buf[1]; // the pointer to the data(package)
} PICPACKAGE, *LPPICPACKAGE;

typedef struct {
	int x;
	int y;
	int width;
	int height;
} FETCHPIC, *LPFETCHPIC;

typedef struct {
	int nName;
	int ParamX;
	int ParamY;
} MyEvent, *LpMyEvent;

#include "cnntport.h"

class CManipulateDlg : public CDialog
{
// Construction
public:
	CWinThread* m_pSendThread;
	static CManipulateDlg* m_pMain;
	static int OnPackageReceived(LPPACKAGE pkg);
	static UINT SendPicThread( LPVOID pParam );

	void SendPic(LPFETCHPIC pPic);
	int m_nMy;
	int m_nMx;
	int m_nCursor;
	int m_nPicTop;
	int m_nPicLeft;
	BOOL m_bIsBegin;
	int m_nMyScrY;
	int m_nMyScrX;
	void ReceiveEvent(MyEvent *myEvent);
	int m_screenY;
	int m_screenX;
	void SendEvents(MyEvent* myEvent = NULL);
	void SendPicFromDC(CDC* pDC, int nStartX, int nStartY, int nWidth, int nHeight);
	void FetchPic(LPFETCHPIC fetchPic);
	void AddStatus(char * str);
	BOOL m_bBusyPort;
	CBitmap m_bmpScreen;
	int m_ySize;
	int m_xSize;
	void ShowPicture(LPPICPACKAGE lpPic);
	HWND m_hSrcWnd;
	CManipulateDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CManipulateDlg)
	enum { IDD = IDD_MANIPULATE_DIALOG };
	BOOL	m_bIsGuaranteed;
	CString	m_strStatus;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CManipulateDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CManipulateDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnFetchscreen();
	afx_msg void OnSelection();
	afx_msg void OnGetanyway();
	afx_msg void OnTest();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnOption();
	afx_msg void OnCursor2();
	afx_msg void OnCutsor1();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnChatNow();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MANIPULATEDLG_H__6110C588_5AE7_11D2_92B3_E36348BD1D08__INCLUDED_)

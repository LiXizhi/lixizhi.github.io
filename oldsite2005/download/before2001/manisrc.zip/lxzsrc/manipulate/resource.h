//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by manipulate.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MANIPULATE_DIALOG           102
#define IDC_POINTER                     104
#define IDR_MAINFRAME                   128
#define IDD_OPTION                      129
#define IDC_POSITION                    130
#define IDI_ICON1                       131
#define IDI_ICON2                       132
#define IDC_SELECTION                   1001
#define IDC_FETCHSCREEN                 1002
#define IDC_GUARANTEED                  1004
#define IDC_STATUS                      1005
#define IDC_GETANYWAY                   1006
#define IDC_TEST                        1007
#define IDC_BOUDER                      1009
#define IDC_WIDTH                       1010
#define IDC_HEIGHT                      1011
#define IDC_OPTION                      1011
#define IDC_CUTSOR1                     1013
#define IDC_CURSOR2                     1014
#define IDC_CHAT_NOW                    1018
#define IDC_BUTTON1                     1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

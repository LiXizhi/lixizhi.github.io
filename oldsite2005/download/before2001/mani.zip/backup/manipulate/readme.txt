This is a very useful software with which you can manipulate a remout computer dramatically. like "PC Anywhere".
This is also a demo of connect.dll .

Note: the connect.dll is a different version other than the one in the connect.zip.   However, the source code are also offered . 
Here to Download ----manisrc.zip.
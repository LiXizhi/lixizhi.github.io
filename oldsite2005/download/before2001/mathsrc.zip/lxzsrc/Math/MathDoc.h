// MathDoc.h : interface of the CMathDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATHDOC_H__018923C2_BAD9_11D2_92B3_DDAC4AC9C351__INCLUDED_)
#define AFX_MATHDOC_H__018923C2_BAD9_11D2_92B3_DDAC4AC9C351__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMathDoc : public CDocument
{
protected: // create from serialization only
	CMathDoc();
	DECLARE_DYNCREATE(CMathDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMathDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMathDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMathDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MATHDOC_H__018923C2_BAD9_11D2_92B3_DDAC4AC9C351__INCLUDED_)

// MathDoc.cpp : implementation of the CMathDoc class
//

#include "stdafx.h"
#include "Math.h"

#include "MathView.h"
#include "MathDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMathDoc

IMPLEMENT_DYNCREATE(CMathDoc, CDocument)

BEGIN_MESSAGE_MAP(CMathDoc, CDocument)
	//{{AFX_MSG_MAP(CMathDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMathDoc construction/destruction

CMathDoc::CMathDoc()
{
	// TODO: add one-time construction code here

}

CMathDoc::~CMathDoc()
{
}

BOOL CMathDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMathDoc serialization

void CMathDoc::Serialize(CArchive& ar)
{
	CMathView* pView = (CMathView*)((CFrameWnd*)AfxGetMainWnd())->GetActiveView();
	if (ar.IsStoring())
	{
		pView->OnSave(ar);
	}
	else
	{
		pView->OnLoad(ar);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMathDoc diagnostics

#ifdef _DEBUG
void CMathDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMathDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMathDoc commands

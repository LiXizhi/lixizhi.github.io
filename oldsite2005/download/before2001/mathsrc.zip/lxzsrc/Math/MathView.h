// MathView.h : interface of the CMathView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATHVIEW_H__018923C4_BAD9_11D2_92B3_DDAC4AC9C351__INCLUDED_)
#define AFX_MATHVIEW_H__018923C4_BAD9_11D2_92B3_DDAC4AC9C351__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "COpenGLView.h"
class CMathDoc;
class CMathView : public COpenGLView
{
protected: // create from serialization only
	CMathView();
	DECLARE_DYNCREATE(CMathView)

// my data starts here
public:
	BYTE m_map[6][9];
	int m_nCurrentHand;
	int m_nCurrentDirection;
	int m_nCurrentItem;
// My Functions
public:
	void DrawItem(int nPage, int nItem);
	void GetRotateMap(int nHand, int nItem, int nDirection, BYTE map[6][9]);
	void AnimateRotationFrame(GLfloat  wAngleX, GLfloat  wAngleY, GLfloat  wAngleZ, BYTE map[6][9]);
	BOOL RenderScene(GLfloat wAngleX=0.0f, GLfloat  wAngleY=0.0f, GLfloat  wAngleZ=0.0f);

	// Attributes
public:
	CMathDoc* GetDocument();
	

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMathView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual void DeleteExtra();
	virtual void InitExtra();
	void OnLoad(CArchive& ar);
	void OnSave(CArchive& ar);
	void DoRotate();
	void DrawHands();
	void ReSetMap(BYTE map[6][9]);
	virtual ~CMathView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMathView)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPlay();
	afx_msg void OnDestroy();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MathView.cpp
inline CMathDoc* CMathView::GetDocument()
   { return (CMathDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MATHVIEW_H__018923C4_BAD9_11D2_92B3_DDAC4AC9C351__INCLUDED_)

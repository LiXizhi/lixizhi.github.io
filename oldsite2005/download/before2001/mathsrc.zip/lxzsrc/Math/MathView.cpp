// MathView.cpp : implementation of the CMathView class
//

#include "stdafx.h"
#include "Math.h"

#include "MathDoc.h"
#include "MathView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////// some globles ///////////////
GLfloat nSize = 0.5f; //the width of an item square
const UINT VK_A = 0x41;
const UINT VK_S = 0x53;
const UINT VK_Q = 0x51;
const UINT VK_W = 0x57;
const UINT VK_E = 0x45;
const UINT VK_L = 0x4a;

/////////////////////////////////////////////////////////////////////////////
// CMathView

IMPLEMENT_DYNCREATE(CMathView, COpenGLView)

BEGIN_MESSAGE_MAP(CMathView, COpenGLView)
	//{{AFX_MSG_MAP(CMathView)
	ON_WM_TIMER()
	ON_COMMAND(ID_PLAY, OnPlay)
	ON_WM_DESTROY()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMathView construction/destruction

CMathView::CMathView()
{
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			m_map[i][j] = i;
		}
	}
	
	m_nCurrentHand = 0; // 0,1,2,
	m_nCurrentDirection = 0; //0, 1
	m_nCurrentItem = 0;  //0,1,2

}

CMathView::~CMathView()
{
}

BOOL CMathView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return COpenGLView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMathView drawing

void CMathView::OnDraw(CDC* pDC)
{
	// done inside COpenGLView::OnDraw(pDC)
	//CMathDoc* pDoc = GetDocument();
	//ASSERT_VALID(pDoc);
	COpenGLView::OnDraw(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CMathView diagnostics

#ifdef _DEBUG
void CMathView::AssertValid() const
{
	CView::AssertValid();
}

void CMathView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMathDoc* CMathView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMathDoc)));
	return (CMathDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMathView message handlers
void CMathView::OnTimer(UINT nIDEvent) 
{
	/*
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glPushMatrix();

	COpenGLView::RenderScene();
	
	glPopMatrix();

	glFinish();
	SwapBuffers(wglGetCurrentDC());
*/
	//RenderScene();

	COpenGLView::OnTimer(nIDEvent);
	
	// Eat spurious WM_TIMER messages
	MSG msg;
	while(::PeekMessage(&msg, m_hWnd, WM_TIMER, WM_TIMER, PM_REMOVE));
	
}

void CMathView::OnPlay() 
{
	static BOOL bActive = FALSE;
	bActive = !bActive;
	if (bActive)	
		SetTimer(1, 15, NULL);
	else
		KillTimer(1);
}

void CMathView::OnDestroy() 
{
	COpenGLView::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

BOOL CMathView::DestroyWindow() 
{
	KillTimer(1);	
	return COpenGLView::DestroyWindow();
}

BOOL CMathView::RenderScene(GLfloat  wAngleX, GLfloat  wAngleY, GLfloat  wAngleZ)
{
	static BOOL     bBusy = FALSE;

	if(bBusy)
		return TRUE;
	bBusy = TRUE;

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glPushMatrix();

		glRotatef(wAngleX, 1.0f, 0.0f, 0.0f);
		glRotatef(wAngleY, 0.0f, 1.0f, 0.0f);
		glRotatef(wAngleZ, 0.0f, 0.0f, 1.0f);

		for(int i=0; i<6; i++)
		{
			for(int j=0; j<9; j++)
			{
				DrawItem(i, j);
			}
		}
		DrawHands();
	glPopMatrix();

	glFinish();
	SwapBuffers(wglGetCurrentDC());

	bBusy = FALSE;
	return TRUE;
}


void CMathView::DrawItem(int nPage, int nItem)
{
	//GLfloat nLine = 0.005f; // the width of a line
	
	// define all vertices   X     Y     Z
	GLfloat v0[3], v1[3], v2[3], v3[3];
	
	// get the color
	GLfloat color[3] = { 0.0f, 0.0f, 0.0f };
	BYTE nColor = m_map[nPage][nItem];
	switch(nColor)
	{
	case 0: //red
		{
			color[0] = 1.0f;
			break;
		}
	case 1: //blue
		{
			color[2] = 1.0f;
			break;
		}
	case 2: // green
		{
			color[1] = 1.0f;
			break;
		}
	case 3: //pink
		{
			color[0] = 1.0f;
			color[2] = 1.0f;
			break;
		}
	case 4: //yellow
		{
			color[0] = 1.0f;
			color[1] = 1.0f;
			break;
		}
	case 5: // white
		{
			color[0] = 1.0f;
			color[1] = 1.0f;
			color[2] = 1.0f;
			break;
		}
	default:
		{
			ASSERT(FALSE);
		}
	}
	
	// Now get the vertice
	switch(nPage)
	{
	case 0:
		{
			int Row = nItem/3;
			v0[0] = 0.0f + nSize*(nItem%3);
			v0[1] = 0.0f - nSize*Row;
			v0[2] = 0.0f;
			
			v1[0] = v0[0] + nSize;
			v1[1] = v0[1];
			v1[2] = 0.0f;

			v2[0] = v0[0] + nSize;
			v2[1] = v0[1] - nSize;
			v2[2] = 0.0f;

			v3[0] = v0[0];
			v3[1] = v0[1] - nSize;
			v3[2] = 0.0f;

			break;
		}
	case 1:
		{
			int Row = nItem/3;
			v0[0] = 0.0f + nSize*(nItem%3);
			v0[1] = 0.0f;
			v0[2] = 0.0f - nSize*Row;
	
			v1[0] = v0[0] + nSize;
			v1[1] = 0.0f;
			v1[2] = v0[2];
			
			v2[0] = v0[0] + nSize;
			v2[1] = 0.0f;
			v2[2] = v0[2] - nSize;
			
			v3[0] = v0[0];
			v3[1] = 0.0f;
			v3[2] = v0[2] - nSize;
			
			break;
		}
	case 2:
		{
			int Row = nItem/3;
			v0[0] = 0.0f + nSize*(nItem%3);
			v0[1] = 0.0f - nSize*Row;
			v0[2] = 0.0f - nSize*3;
			
			v1[0] = v0[0] + nSize;
			v1[1] = v0[1];
			v1[2] = 0.0f - nSize*3;

			v2[0] = v0[0] + nSize;
			v2[1] = v0[1] - nSize;
			v2[2] = 0.0f - nSize*3;

			v3[0] = v0[0];
			v3[1] = v0[1] - nSize;
			v3[2] = 0.0f - nSize*3;


			break;
		}
	case 3:
		{
			int Row = nItem/3;
			v0[0] = 0.0f + nSize*(nItem%3);
			v0[1] = 0.0f - nSize*3;
			v0[2] = 0.0f - nSize*Row;
	
			v1[0] = v0[0] + nSize;
			v1[1] = 0.0f - nSize*3;
			v1[2] = v0[2];
			
			v2[0] = v0[0] + nSize;
			v2[1] = 0.0f - nSize*3;
			v2[2] = v0[2] - nSize;
			
			v3[0] = v0[0];
			v3[1] = 0.0f - nSize*3;
			v3[2] = v0[2] - nSize;

			break;
		}
	case 4:
		{
			int Row = nItem/3;
			v0[0] = 0.0f;
			v0[1] = 0.0f - nSize*Row;
			v0[2] = 0.0f - nSize*(nItem%3);
			
			v1[0] = 0.0f;
			v1[1] = v0[1];
			v1[2] = v0[2] - nSize;
			
			v2[0] = 0.0f;
			v2[1] = v0[1] - nSize;
			v2[2] = v0[2] - nSize;
			
			v3[0] = 0.0f;
			v3[1] = v0[1] - nSize;
			v3[2] = v0[2];

			break;
		}
	case 5:
		{
			int Row = nItem/3;
			v0[0] = 0.0f + nSize*3;
			v0[1] = 0.0f - nSize*Row;
			v0[2] = 0.0f - nSize*(nItem%3);
			
			v1[0] = 0.0f + nSize*3;
			v1[1] = v0[1];
			v1[2] = v0[2] - nSize;
			
			v2[0] = 0.0f + nSize*3;
			v2[1] = v0[1] - nSize;
			v2[2] = v0[2] - nSize;
			
			v3[0] = 0.0f + nSize*3;
			v3[1] = v0[1] - nSize;
			v3[2] = v0[2];

			break;
		}
	default:
		{
			ASSERT(FALSE);
		}
	}
	
	// change origin from 0,0,0 of the world system to rotate sub system
	// offSet maybe other value as it becomes more flexible
	// by modify offSet you can rotate by any lines, not only the origin
	GLfloat offSet = nSize*3/2;
	v0[0] -= offSet;
	v0[1] += offSet;
	v0[2] += offSet;

	v1[0] -= offSet;
	v1[1] += offSet;
	v1[2] += offSet;

	v2[0] -= offSet;
	v2[1] += offSet;
	v2[2] += offSet;

	v3[0] -= offSet;
	v3[1] += offSet;
	v3[2] += offSet;


	// draw the face
	glBegin(GL_QUADS);
		glColor3fv(color);
		glVertex3fv(v0);
		glVertex3fv(v1);
		glVertex3fv(v2);
		glVertex3fv(v3);
	glEnd();

	// then draw the frame using black lines
	glBegin(GL_LINE_STRIP);
		glColor3f(0.0f, 0.0f, 0.0f); //black
		glVertex3fv(v0);
		glVertex3fv(v1);
		glVertex3fv(v2);
		glVertex3fv(v3);
	glEnd();

}

void CMathView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (nChar == ' ')
	{
		DoRotate();
	} //if (nChar == ' ')
	else if(nChar == VK_RIGHT)
	{
		GLfloat  wAngleY = 0.0f;
		RenderScene();
		while(wAngleY <= 30.0f)
		{
			wAngleY += 5.0f;
			RenderScene(0, wAngleY, 0);
			Sleep(15);
		}
		glRotatef(wAngleY, 0.0f, 1.0f, 0.0f);
	}
	else if(nChar == VK_LEFT)
	{
		GLfloat  wAngleY = 0.0f;
		RenderScene();
		while(wAngleY >= -30.0f)
		{
			wAngleY -= 5.0f;
			RenderScene(0, wAngleY, 0);
			Sleep(15);
		}
		glRotatef(wAngleY, 0.0f, 1.0f, 0.0f);
	}
	else if(nChar == VK_DOWN)
	{
		GLfloat  wAngleX = 0.0f;
		RenderScene();
		while(wAngleX <= 30.0f)
		{
			wAngleX += 5.0f;
			RenderScene(wAngleX, 0, 0);
			Sleep(15);
		}
		glRotatef(wAngleX, 1.0f, 0.0f, 0.0f);
	}
	else if(nChar == VK_UP)
	{
		GLfloat  wAngleX = 0.0f;
		RenderScene();
		while(wAngleX >= -30.0f)
		{
			wAngleX -= 5.0f;
			RenderScene(wAngleX, 0, 0);
			Sleep(15);
		}
		glRotatef(wAngleX, 1.0f, 0.0f, 0.0f);
	}
	else if(nChar == VK_HOME)
	{
		GLfloat  wAngleZ = 0.0f;
		RenderScene();
		while(wAngleZ <= 30.0f)
		{
			wAngleZ += 5.0f;
			RenderScene(0, 0, wAngleZ);
			Sleep(15);
		}
		glRotatef(wAngleZ, 0.0f, 0.0f, 1.0f);
	}
	else if(nChar == VK_PRIOR)
	{
		GLfloat  wAngleZ = 0.0f;
		RenderScene();
		while(wAngleZ >= -30.0f)
		{
			wAngleZ -= 5.0f;
			RenderScene(0, 0, wAngleZ);
			Sleep(15);
		}
		glRotatef(wAngleZ, 0.0f, 0.0f, 1.0f);
	}
	else if (nChar == VK_CLEAR)
	{// load a screen
		GLint ndepth;
		glGetIntegerv(GL_MODELVIEW_STACK_DEPTH, &ndepth);

		if (ndepth == 1)
		{
			CString str;
			str.LoadString(IDS_NO_SAVED_PAGE);
			MessageBox(str);
		}
		else
		{
			glPopMatrix();
			RenderScene();
		}
	}
	else if (nChar == VK_INSERT)
	{// save a screen
		GLint ndepth;
		glGetIntegerv(GL_MODELVIEW_STACK_DEPTH, &ndepth);

		if (ndepth > 5)
		{
			CString str;
			str.LoadString(IDS_PAGE_FULL);
			MessageBox(str);
		}
		else
		{
			glPushMatrix();
			glGetIntegerv(GL_MODELVIEW_STACK_DEPTH, &ndepth);
		}
	}
	else if (nChar == VK_Q)// change hand 0
	{
		m_nCurrentHand = 0;
		RenderScene();
	}
	else if (nChar == VK_W)// change hand 1
	{
		m_nCurrentHand = 1;
		RenderScene();
	}
	else if (nChar == VK_E)// change hand 2
	{
		m_nCurrentHand = 2;
		RenderScene();
	}
	else if (nChar == VK_S)// change Item ++
	{
		m_nCurrentItem++;
		m_nCurrentItem = m_nCurrentItem%3;
		RenderScene();
	}
	else if (nChar == VK_TAB)// change Item ++
	{
		m_nCurrentDirection++;
		m_nCurrentDirection = m_nCurrentDirection%2;
		RenderScene();
	}
	else if (nChar == AUX_L)// change Item ++
	{
		//SetLight();
		glMatrixMode(GL_PROJECTION );
		// move bottom left, southwest of the red triangle 
		glColor3f(1.0F, 0.0F, 0.0F); 
		glRasterPos3f(-1.0f, 1.2f, 1.5f);
		//glListBase(1000);  // draw a string using font display lists 
		glCallLists(12, GL_UNSIGNED_BYTE, "Red Triangle");  
		glFinish(); 
		SwapBuffers(wglGetCurrentDC());
		glMatrixMode(GL_MODELVIEW );
	}

	COpenGLView::OnKeyDown(nChar, nRepCnt, nFlags);
}

// get the map
void CMathView::GetRotateMap(int nHand, int nItem, int nDirection, BYTE map[6][9])
{
	int nPage = -1;
	
	switch(nHand)
	{
		case 0:
			{
				if (nItem == 0) nPage = 1;
				else if (nItem == 2) nPage = 3;
				
				int nRow = nItem*3;

				if (nDirection == 0)
				{
					map[0][0+nRow] = m_map[4][2+nRow];
					map[0][1+nRow] = m_map[4][1+nRow];
					map[0][2+nRow] = m_map[4][0+nRow];
					
					map[4][0+nRow] = m_map[2][0+nRow];
					map[4][1+nRow] = m_map[2][1+nRow];
					map[4][2+nRow] = m_map[2][2+nRow];

					map[2][0+nRow] = m_map[5][2+nRow];
					map[2][1+nRow] = m_map[5][1+nRow];
					map[2][2+nRow] = m_map[5][0+nRow];

					map[5][0+nRow] = m_map[0][0+nRow];
					map[5][1+nRow] = m_map[0][1+nRow];
					map[5][2+nRow] = m_map[0][2+nRow];
				}
				else if (nDirection == 1)
				{
					map[4][2+nRow] = m_map[0][0+nRow];
					map[4][1+nRow] = m_map[0][1+nRow];
					map[4][0+nRow] = m_map[0][2+nRow];
					
					map[2][0+nRow] = m_map[4][0+nRow];
					map[2][1+nRow] = m_map[4][1+nRow];
					map[2][2+nRow] = m_map[4][2+nRow];

					map[5][2+nRow] = m_map[2][0+nRow];
					map[5][1+nRow] = m_map[2][1+nRow];
					map[5][0+nRow] = m_map[2][2+nRow];

					map[0][0+nRow] = m_map[5][0+nRow];
					map[0][1+nRow] = m_map[5][1+nRow];
					map[0][2+nRow] = m_map[5][2+nRow];
				}
				else
					ASSERT(FALSE);
				break;
					
			}
		case 1:
			{
				if (nItem == 0) nPage = 4;
				else if (nItem == 2) nPage = 5;
				int nRow = nItem;

				if (nDirection == 0)
				{
					map[0][0+nRow] = m_map[3][0+nRow];
					map[0][3+nRow] = m_map[3][3+nRow];
					map[0][6+nRow] = m_map[3][6+nRow];
					
					map[1][6+nRow] = m_map[0][0+nRow];
					map[1][3+nRow] = m_map[0][3+nRow];
					map[1][0+nRow] = m_map[0][6+nRow];

					map[2][0+nRow] = m_map[1][0+nRow];
					map[2][3+nRow] = m_map[1][3+nRow];
					map[2][6+nRow] = m_map[1][6+nRow];

					map[3][6+nRow] = m_map[2][0+nRow];
					map[3][3+nRow] = m_map[2][3+nRow];
					map[3][0+nRow] = m_map[2][6+nRow];
				}
				else if (nDirection == 1)
				{
					map[0][0+nRow] = m_map[1][6+nRow];
					map[0][3+nRow] = m_map[1][3+nRow];
					map[0][6+nRow] = m_map[1][0+nRow];
					
					map[1][6+nRow] = m_map[2][6+nRow];
					map[1][3+nRow] = m_map[2][3+nRow];
					map[1][0+nRow] = m_map[2][0+nRow];

					map[2][0+nRow] = m_map[3][6+nRow];
					map[2][3+nRow] = m_map[3][3+nRow];
					map[2][6+nRow] = m_map[3][0+nRow];

					map[3][6+nRow] = m_map[0][6+nRow];
					map[3][3+nRow] = m_map[0][3+nRow];
					map[3][0+nRow] = m_map[0][0+nRow];
				}
				else
					ASSERT(FALSE);
		
				break;
			}
		case 2:
			{
				if (nItem == 0) nPage = 0;
				else if (nItem == 2) nPage = 2;
				int nRow = nItem*3;

				if (nDirection == 0)
				{
					map[5][0+nItem] = m_map[1][0+nRow];
					map[5][3+nItem] = m_map[1][1+nRow];
					map[5][6+nItem] = m_map[1][2+nRow];
					
					map[1][0+nRow] = m_map[4][6+nItem];
					map[1][1+nRow] = m_map[4][3+nItem];
					map[1][2+nRow] = m_map[4][0+nItem];

					map[4][0+nItem] = m_map[3][0+nRow];
					map[4][3+nItem] = m_map[3][1+nRow];
					map[4][6+nItem] = m_map[3][2+nRow];

					map[3][0+nRow] = m_map[5][6+nItem];
					map[3][1+nRow] = m_map[5][3+nItem];
					map[3][2+nRow] = m_map[5][0+nItem];
				}
				else if (nDirection == 1)
				{
					map[1][0+nRow] = m_map[5][0+nItem];
					map[1][1+nRow] = m_map[5][3+nItem];
					map[1][2+nRow] = m_map[5][6+nItem];
					
					map[4][6+nItem] = m_map[1][0+nRow];
					map[4][3+nItem] = m_map[1][1+nRow];
					map[4][0+nItem] = m_map[1][2+nRow];

					map[3][0+nRow] = m_map[4][0+nItem];
					map[3][1+nRow] = m_map[4][3+nItem];
					map[3][2+nRow] = m_map[4][6+nItem];

					map[5][6+nItem] = m_map[3][0+nRow];
					map[5][3+nItem] = m_map[3][1+nRow];
					map[5][0+nItem] = m_map[3][2+nRow];
				}
				else
					ASSERT(FALSE);
		
				break;
			}
		default:
			{
				ASSERT(FALSE);
			}
	}
	if (nPage>=0)
	{
		for(int j=0; j<9; j++)
		{
			int offset = 0;
			if (j == 0) offset = 6;
			if (j == 1) offset = 2;
			if (j == 2) offset = -2;
			if (j == 3) offset = 4;
			if (j == 4) offset = 0;
			if (j == 5) offset = -4;
			if (j == 6) offset = 2;
			if (j == 7) offset = -2;
			if (j == 8) offset = -6;

			ASSERT(((j+offset)<9) && ((j+offset)>=0));
			if (nDirection == 0)
				map[nPage][j] = m_map[nPage][j+offset];
			else if (nDirection == 1)
				map[nPage][j+offset] = m_map[nPage][j];
			else
				ASSERT(FALSE);
		}
	}
} // void CMathView::GetRotateMap

void CMathView::AnimateRotationFrame(GLfloat  wAngleX, GLfloat  wAngleY, GLfloat  wAngleZ, BYTE map[6][9])
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glPushMatrix();
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			if (map[i][j] != 0xff)
			{
				ASSERT((map[i][j]<6) && (map[i][j]>=0));
				glPushMatrix();
					glRotatef(wAngleX, 1.0f, 0.0f, 0.0f);
					glRotatef(wAngleY, 0.0f, 1.0f, 0.0f);
					glRotatef(wAngleZ, 0.0f, 0.0f, 1.0f);

					DrawItem(i, j);
				glPopMatrix();
			}
			else
			{
				DrawItem(i, j);
			}
		}
	}
	glPopMatrix();

	glFinish();
	SwapBuffers(wglGetCurrentDC());
}

void CMathView::ReSetMap(BYTE map[][9])
{
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			if (map[i][j] != 0xff)
			{
				m_map[i][j] = map[i][j];
			}
		}
	}
}

// Load usually in RenderScene
void CMathView::DrawHands()
{
	//v0 v1 v2 is used to form a triAngle
	//v0 ans v3 is used to form a line
	//it will be like a array
	// define all vertices   X     Y     Z
	GLfloat v0[3], v1[3], v2[3], v3[3];
	
	
	// get the color
	GLfloat color[3] = { 0.0f, 0.0f, 0.0f };

	for (int i = 0 ; i<3; i++) //hand
	{
		for (int j = 0 ; j<3; j++) //Item
		{
			color[1] = 0.5f;
			if (i == 0)
			{
				v0[0] = -nSize;
				v0[1] = -nSize/2 - nSize*j;
				v0[2] = 0.0f;
				
				v1[0] = -nSize/2;
				v1[1] = v0[1];
				v1[2] = nSize;
				
				v2[0] = 0.0f;
				v2[1] = v0[1];
				v2[2] = nSize/2;
				
				v3[0] = 0.0f;
				v3[1] = v0[1];
				v3[2] = nSize;
			}
			else if(i==1)
			{
				v0[0] = nSize/2 + nSize*j;
				v0[1] = nSize/4;
				v0[2] = -v0[1] + nSize;
				
				v1[0] = nSize*j+ nSize/4;
				v1[1] = nSize/2;
				v1[2] = -v1[1] + nSize;
				
				v2[0] = v0[0] + nSize/4;
				v2[1] = v1[1];
				v2[2] = -v2[1] + nSize;
				
				v3[0] = v0[0];
				v3[1] = nSize/4*3;
				v3[2] = -v3[1] + nSize;
			}
			else if(i==2)
			{
				v0[0] = nSize*3;
				v0[1] = nSize;
				v0[2] = -nSize/2 - nSize*j;
				
				v1[0] = v0[0] + nSize/2;
				v1[1] = 0;
				v1[2] = - nSize*j - nSize/2;
				
				v2[0] = v0[0] + nSize;
				v2[1] = nSize/2;
				v2[2] = v1[2]; //- nSize*j - nSize/2
				
				v3[0] = v0[0] + nSize;
				v3[1] = 0.0f;
				v3[2] = v0[2];
			}
			// draw now
			if ((i == (m_nCurrentHand)) &&
				(j == (m_nCurrentItem)))
			{
				color[1] = 1.0f;
			}
			GLfloat offSet = nSize*3/2;
			v0[0] -= offSet;
			v0[1] += offSet;
			v0[2] += offSet;

			v1[0] -= offSet;
			v1[1] += offSet;
			v1[2] += offSet;

			v2[0] -= offSet;
			v2[1] += offSet;
			v2[2] += offSet;

			v3[0] -= offSet;
			v3[1] += offSet;
			v3[2] += offSet;

			if (m_nCurrentDirection == 0)
			{
				glBegin(GL_TRIANGLES);
					glColor3fv(color);
					glVertex3fv(v1);
					glVertex3fv(v2);
					glVertex3fv(v3);
				glEnd();
			}else if(m_nCurrentDirection == 1)
			{
				glBegin(GL_TRIANGLES);
					glColor3fv(color);
					glVertex3fv(v0);
					glVertex3fv(v1);
					glVertex3fv(v2);
				glEnd();
			}

			glBegin(GL_LINES);
				glColor3f(1.0f, 1.0f, 1.0f); //white
				glVertex3fv(v0);
				glVertex3fv(v3);
			glEnd();
		}
	}
}

void CMathView::DoRotate()
{
	//////////////////
	BYTE map[6][9];
	memset(map, 0xff, sizeof(map));
	// Now get map, the needed -rotated item, map [i][j] will
	// be filled with the value which it would been rotated to.
	GetRotateMap(m_nCurrentHand, m_nCurrentItem, m_nCurrentDirection, map);
	
	// now do different animation.
	switch(m_nCurrentHand)
	{
	case 0:
		{
			GLfloat  wAngleY = 0.0f;
			if (m_nCurrentDirection == 0)
			{
				while(wAngleY <= 90.0f)
				{
					wAngleY += 2.0f;
					AnimateRotationFrame(0, wAngleY, 0, map);
					Sleep(15);
				}
			}
			else if (m_nCurrentDirection == 1)
			{
				while(wAngleY >= -90.0f)
				{
					wAngleY -= 2.0f;
					AnimateRotationFrame(0, wAngleY, 0, map);
					Sleep(15);
				}
			}
			else{ASSERT(FALSE);}

			break;
		}
	case 1:
		{
			GLfloat  wAngleX = 0.0f;
			if (m_nCurrentDirection == 1)
			{
				while(wAngleX <= 90.0f)
				{
					wAngleX += 2.0f;
					AnimateRotationFrame(wAngleX, 0, 0, map);
					Sleep(15);
				}
			}
			else if (m_nCurrentDirection == 0)
			{
				while(wAngleX >= -90.0f)
				{
					wAngleX -= 2.0f;
					AnimateRotationFrame(wAngleX, 0, 0, map);
					Sleep(15);
				}
			}
			else{ASSERT(FALSE);}
			break;
		}
	case 2:
		{
			GLfloat  wAngleZ = 0.0f;
			if (m_nCurrentDirection == 1)
			{
				while(wAngleZ <= 90.0f)
				{
					wAngleZ += 2.0f;
					AnimateRotationFrame(0, 0, wAngleZ, map);
					Sleep(15);
				}
			}
			else if (m_nCurrentDirection == 0)
			{
				while(wAngleZ >= -90.0f)
				{
					wAngleZ -= 2.0f;
					AnimateRotationFrame(0, 0, wAngleZ, map);
					Sleep(15);
				}
			}
			else{ASSERT(FALSE);}
			break;
		}
	default:
		{
			ASSERT(FALSE);
		}
	}
	// Now reset the map
	ReSetMap(map);
	// now render one frame with the new map
	RenderScene();
				
}

void CMathView::OnSave(CArchive &ar)
{
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			ar<<m_map[i][j];
		}
	}
}

void CMathView::OnLoad(CArchive &ar)
{
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			ar>>m_map[i][j];
		}
	}
}

void CMathView::InitExtra()
{
	//SetLight();
	// create bitmaps for the device context font's first 256 glyphs 
	wglUseFontBitmaps(wglGetCurrentDC(), 0, 256, 1000); 
	glListBase(1000);
}

void CMathView::DeleteExtra()
{
	// delete our 256 glyph display lists 
	glDeleteLists(1000, 256); 
}

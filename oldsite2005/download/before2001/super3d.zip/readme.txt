This is a 3d game;
----------By LiXizhi

Drag your mourse over the tube with your left button down.
The buttons in the left helps you to change the circle. 
Press Do rotate to give it a rotation.

Source code included in sup3Dsrc.zip
build with mfc and directx 5.0 sdk and vc6.0
A DirectX template class derived from CWnd.  Here is a demo of it. With ease. Just a few lines of code. using the powerful toolkit. Comments? Please email me.

A 3d game. See super3d.zip for executable files.

Build with Directx 5.0 sdk , MFC and vc6.0.

this is a demo of using a template class called CDirect3d dirived from CWnd. Source code is in Direct3d.cpp Direct3d.h. Keep these two files, so when you want to enable direct3D support in your window, simply inherit this class. 

What functions should I inherit?  Just see MyWnd.cpp.




A DirectX template class derived from CWnd.  I think it's useful if you only want to develop a software like this tube game.
This is version 1.1 of CDirect3d Class. Email to litc611@public.hr.hl.cn to get the latest news or support. You can also visit my web site for more downloads about Visual C.

-----By LiXizhi,





















========================================================================
       MICROSOFT FOUNDATION CLASS LIBRARY : Super3D
========================================================================


AppWizard has created this Super3D application for you.  This application
not only demonstrates the basics of using the Microsoft Foundation classes
but is also a starting point for writing your application.

This file contains a summary of what you will find in each of the files that
make up your Super3D application.

Super3D.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

Super3D.h
    This is the main header file for the application.  It includes other
    project specific headers (including Resource.h) and declares the
    CSuper3DApp application class.

Super3D.cpp
    This is the main application source file that contains the application
    class CSuper3DApp.

Super3D.rc
    This is a listing of all of the Microsoft Windows resources that the
    program uses.  It includes the icons, bitmaps, and cursors that are stored
    in the RES subdirectory.  This file can be directly edited in Microsoft
	Visual C++.

Super3D.clw
    This file contains information used by ClassWizard to edit existing
    classes or add new classes.  ClassWizard also uses this file to store
    information needed to create and edit message maps and dialog data
    maps and to create prototype member functions.

res\Super3D.ico
    This is an icon file, which is used as the application's icon.  This
    icon is included by the main resource file Super3D.rc.

res\Super3D.rc2
    This file contains resources that are not edited by Microsoft 
	Visual C++.  You should place all resources not editable by
	the resource editor in this file.




/////////////////////////////////////////////////////////////////////////////

AppWizard creates one dialog class:

Super3DDlg.h, Super3DDlg.cpp - the dialog
    These files contain your CSuper3DDlg class.  This class defines
    the behavior of your application's main dialog.  The dialog's
    template is in Super3D.rc, which can be edited in Microsoft
	Visual C++.


/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named Super3D.pch and a precompiled types file named StdAfx.obj.

Resource.h
    This is the standard header file, which defines new resource IDs.
    Microsoft Visual C++ reads and updates this file.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

If your application uses MFC in a shared DLL, and your application is 
in a language other than the operating system's current language, you
will need to copy the corresponding localized resources MFC42XXX.DLL
from the Microsoft Visual C++ CD-ROM onto the system or system32 directory,
and rename it to be MFCLOC.DLL.  ("XXX" stands for the language abbreviation.
For example, MFC42DEU.DLL contains resources translated to German.)  If you
don't do this, some of the UI elements of your application will remain in the
language of the operating system.

/////////////////////////////////////////////////////////////////////////////

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Super3D.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SUPER3D_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON8                     1007
#define IDC_CHANGE_GROUP                1008
#define IDC_CHANGE_ITEM                 1009
#define IDC_CHANGE_DIRECTION            1010
#define IDC_Rotate                      1011
#define IDC_CHANGESIZE                  1012
#define IDC_RECT                        1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

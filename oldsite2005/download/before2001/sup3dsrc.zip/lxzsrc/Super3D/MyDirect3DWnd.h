// MyDirect3DWnd.h: interface for the CMyDirect3DWnd class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYDIRECT3DWND_H__D1456FA1_CC7E_11D2_8551_000021E2BB14__INCLUDED_)
#define AFX_MYDIRECT3DWND_H__D1456FA1_CC7E_11D2_8551_000021E2BB14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Direct3D.h"

class CMyDirect3DWnd : public CDirect3D  
{
// my data starts here
public:
	BYTE m_map[6][9];
	int m_nCurrentHand;
	int m_nCurrentDirection;
	int m_nCurrentItem;
// My Functions
public:
	void BuildItem(int nPage, int nItem);
	void GetRotateMap(int nHand, int nItem, int nDirection, BYTE map[6][9]);
	void ReSetMap(BYTE map[][9]);
	void AnimateRotationFrame(float  wAngleX, float  wAngleY, float  wAngleZ, BYTE map[6][9]);
	void DoRotate();
	//BOOL RenderScene(GLfloat wAngleX=0.0f, GLfloat  wAngleY=0.0f, GLfloat  wAngleZ=0.0f);


public:
	LPDIRECT3DRMTEXTURE2 m_lpMyTexture[6];
	LPDIRECT3DRMWRAP m_pMywrap;
	void SetCirclePosition();
	void UpdateAllColors();
	void UpdateItemColor(int nPage, int nItem);
	LPDIRECT3DRMFRAME2 m_rmParentFrame;
	LPDIRECT3DRMFRAME2 m_rmCircleFrame;
	


	virtual BOOL AddMoreFrames(LPDIRECT3DRMDEVICE2 dev, LPDIRECT3DRMVIEWPORT view,
		LPDIRECT3DRMFRAME2 scene, LPDIRECT3DRMFRAME2 camera);

	CMyDirect3DWnd();
	virtual ~CMyDirect3DWnd();

};

#endif // !defined(AFX_MYDIRECT3DWND_H__D1456FA1_CC7E_11D2_8551_000021E2BB14__INCLUDED_)

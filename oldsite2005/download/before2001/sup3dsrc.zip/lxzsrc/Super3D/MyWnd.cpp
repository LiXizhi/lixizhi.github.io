// MyWnd.cpp: implementation of the CMyDirect3DWnd class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Super3D.h"
#include "MyDirect3DWnd.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

float nSize = 0.5f; //the width of an item square
float GetAngle(float x)  {return x*(3.1415926535897f)/(180.0f);}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyDirect3DWnd::CMyDirect3DWnd()
{
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			m_map[i][j] = i;
		}
	}
	
	m_nCurrentHand = 0; // 0,1,2,
	m_nCurrentDirection = 0; //0, 1
	m_nCurrentItem = 0;  //0,1,2

}

CMyDirect3DWnd::~CMyDirect3DWnd()
{

}

void CMyDirect3DWnd::BuildItem(int nPage, int nItem)
{
	//float nLine = 0.005f; // the width of a line
	
	// define all vertices   X     Y     Z
	float v[4][3];
	// used in direct3d clockwise visible
	int indexVertice[4]={0, 1, 2, 3};
	
	// Now get the vertice
	switch(nPage)
	{
	case 0:
		{
			int Row = nItem/3;
			v[0][0] = 0.0f + nSize*(nItem%3);
			v[0][1] = 0.0f - nSize*Row;
			v[0][2] = 0.0f;
			
			v[1][0] = v[0][0] + nSize;
			v[1][1] = v[0][1];
			v[1][2] = 0.0f;

			v[2][0] = v[0][0] + nSize;
			v[2][1] = v[0][1] - nSize;
			v[2][2] = 0.0f;

			v[3][0] = v[0][0];
			v[3][1] = v[0][1] - nSize;
			v[3][2] = 0.0f;

			break;
		}
	case 1:
		{
			int Row = nItem/3;
			v[0][0] = 0.0f + nSize*(nItem%3);
			v[0][1] = 0.0f;
			v[0][2] = 0.0f - nSize*Row;
	
			v[1][0] = v[0][0] + nSize;
			v[1][1] = 0.0f;
			v[1][2] = v[0][2];
			
			v[2][0] = v[0][0] + nSize;
			v[2][1] = 0.0f;
			v[2][2] = v[0][2] - nSize;
			
			v[3][0] = v[0][0];
			v[3][1] = 0.0f;
			v[3][2] = v[0][2] - nSize;

			indexVertice[0] = 3;
			indexVertice[1] = 2;
			indexVertice[2] = 1;
			indexVertice[3] = 0;

			break;
		}
	case 2:
		{
			int Row = nItem/3;
			v[0][0] = 0.0f + nSize*(nItem%3);
			v[0][1] = 0.0f - nSize*Row;
			v[0][2] = 0.0f - nSize*3;
			
			v[1][0] = v[0][0] + nSize;
			v[1][1] = v[0][1];
			v[1][2] = 0.0f - nSize*3;

			v[2][0] = v[0][0] + nSize;
			v[2][1] = v[0][1] - nSize;
			v[2][2] = 0.0f - nSize*3;

			v[3][0] = v[0][0];
			v[3][1] = v[0][1] - nSize;
			v[3][2] = 0.0f - nSize*3;

			indexVertice[0] = 3;
			indexVertice[1] = 2;
			indexVertice[2] = 1;
			indexVertice[3] = 0;

			break;
		}
	case 3:
		{
			int Row = nItem/3;
			v[0][0] = 0.0f + nSize*(nItem%3);
			v[0][1] = 0.0f - nSize*3;
			v[0][2] = 0.0f - nSize*Row;
	
			v[1][0] = v[0][0] + nSize;
			v[1][1] = 0.0f - nSize*3;
			v[1][2] = v[0][2];
			
			v[2][0] = v[0][0] + nSize;
			v[2][1] = 0.0f - nSize*3;
			v[2][2] = v[0][2] - nSize;
			
			v[3][0] = v[0][0];
			v[3][1] = 0.0f - nSize*3;
			v[3][2] = v[0][2] - nSize;

			break;
		}
	case 4:
		{
			int Row = nItem/3;
			v[0][0] = 0.0f;
			v[0][1] = 0.0f - nSize*Row;
			v[0][2] = 0.0f - nSize*(nItem%3);
			
			v[1][0] = 0.0f;
			v[1][1] = v[0][1];
			v[1][2] = v[0][2] - nSize;
			
			v[2][0] = 0.0f;
			v[2][1] = v[0][1] - nSize;
			v[2][2] = v[0][2] - nSize;
			
			v[3][0] = 0.0f;
			v[3][1] = v[0][1] - nSize;
			v[3][2] = v[0][2];

			indexVertice[0] = 3;
			indexVertice[1] = 2;
			indexVertice[2] = 1;
			indexVertice[3] = 0;

			break;
		}
	case 5:
		{
			int Row = nItem/3;
			v[0][0] = 0.0f + nSize*3;
			v[0][1] = 0.0f - nSize*Row;
			v[0][2] = 0.0f - nSize*(nItem%3);
			
			v[1][0] = 0.0f + nSize*3;
			v[1][1] = v[0][1];
			v[1][2] = v[0][2] - nSize;
			
			v[2][0] = 0.0f + nSize*3;
			v[2][1] = v[0][1] - nSize;
			v[2][2] = v[0][2] - nSize;
			
			v[3][0] = 0.0f + nSize*3;
			v[3][1] = v[0][1] - nSize;
			v[3][2] = v[0][2];

			break;
		}
	default:
		{
			ASSERT(FALSE);
		}
	}
	
	// change origin from 0,0,0 of the world system to rotate sub system
	// offSet maybe other value as it becomes more flexible
	// by modify offSet you can rotate by any lines, not only the origin
	float offSet = nSize*3/2;
	v[0][0] -= offSet;
	v[0][1] += offSet;
	v[0][2] += offSet;

	v[1][0] -= offSet;
	v[1][1] += offSet;
	v[1][2] += offSet;

	v[2][0] -= offSet;
	v[2][1] += offSet;
	v[2][2] += offSet;

	v[3][0] -= offSet;
	v[3][1] += offSet;
	v[3][2] += offSet;

	LPDIRECT3DRMFRAME2 user = NULL;
	LPDIRECT3DRMMESHBUILDER2 builder = NULL;
	LPDIRECT3DRMMESH mesh = NULL;

	//HRESULT rval;

	// Add a new frame------user
	if (FAILED(lpD3DRM->CreateFrame(m_rmParentFrame, &user)))
		ASSERT(FALSE);
	// Add a new MeshBuilder into ------3D
	if (FAILED(lpD3DRM->CreateMeshBuilder(&builder)))
		ASSERT(FALSE);

	LPDIRECT3DRMFACE MyFace = NULL;
	if((builder->CreateFace(&MyFace) != D3DRM_OK))
		MessageBox("Failed!");
	
	MyFace->AddVertex(D3DVAL(v[indexVertice[0]][0]), D3DVAL(v[indexVertice[0]][1]), D3DVAL(-v[indexVertice[0]][2]));
	MyFace->AddVertex(D3DVAL(v[indexVertice[1]][0]), D3DVAL(v[indexVertice[1]][1]), D3DVAL(-v[indexVertice[1]][2]));
	MyFace->AddVertex(D3DVAL(v[indexVertice[2]][0]), D3DVAL(v[indexVertice[2]][1]), D3DVAL(-v[indexVertice[2]][2]));
	MyFace->AddVertex(D3DVAL(v[indexVertice[3]][0]), D3DVAL(v[indexVertice[3]][1]), D3DVAL(-v[indexVertice[3]][2]));
	

	// enlarge the face
	builder->Scale(D3DVAL(2.5), D3DVAL(2.5), D3DVAL(2.5));
	// Add texture to the face 
	MyFace->SetTextureCoordinates(0, D3DVAL(0), D3DVAL(0));
	MyFace->SetTextureCoordinates(1, D3DVAL(0), D3DVAL(1));
	MyFace->SetTextureCoordinates(2, D3DVAL(1), D3DVAL(1));
	MyFace->SetTextureCoordinates(3, D3DVAL(1), D3DVAL(0));

	// Create mesh associated with builder for rendering
	if (FAILED(builder->CreateMesh(&mesh)))
		ASSERT(FALSE);

	// Add one MeshBuilder's sample to user to be rendered
	if (FAILED(user->AddVisual((LPDIRECT3DRMVISUAL) mesh)))
		ASSERT(FALSE);
	
	RELEASE(builder);
	RELEASE(user);
    RELEASE(mesh);
}

BOOL CMyDirect3DWnd::AddMoreFrames(LPDIRECT3DRMDEVICE2 dev, LPDIRECT3DRMVIEWPORT view,
	   LPDIRECT3DRMFRAME2 scene, LPDIRECT3DRMFRAME2 camera)
{
	//Load All Texture into Memory
	for (int i = 0; i<6; i++)
	{
		CString str = "texture0";
		str.SetAt((str.GetLength() - 1), '0'+i);
		str += ".bmp";

		if(lpD3DRM->LoadTexture(str, &m_lpMyTexture[i]) != D3DRM_OK)
			MessageBox("Where have you put the texture?.bmp");
		//  make it Transparency
		//m_lpMyTexture->SetDecalTransparency(TRUE);
	}
	
	
	// Add Parent frame------m_rmParentFrame
	if (FAILED(lpD3DRM->CreateFrame(scene, &m_rmParentFrame)))
		ASSERT(FALSE);

	// set user callback
	if (FAILED(m_rmParentFrame->AddMoveCallback(UserControl, NULL)))
		ASSERT(FALSE);
	
	for(i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			BuildItem(i, j);
		}
	}
	UpdateAllColors();
	/////////Create the circle
	if (FAILED(lpD3DRM->CreateFrame(m_rmParentFrame, &m_rmCircleFrame)))
		ASSERT(FALSE);
	
	LPDIRECT3DRMMESHBUILDER2 builder = NULL;
	LPDIRECT3DRMMESH mesh = NULL;

	HRESULT rval;
	
	if (FAILED(lpD3DRM->CreateMeshBuilder(&builder)))
		ASSERT(FALSE);
    rval = builder->Load("circle.x", NULL, D3DRMLOAD_FROMFILE, NULL, NULL);
  				
    if (rval != D3DRM_OK)
		AfxMessageBox("Failed to load circle.x.\n%s");
	if (FAILED(builder->Scale(D3DVAL(0.08), D3DVAL(0.08), D3DVAL(0.08))))
		ASSERT(FALSE);
	// use rgba to make it transparantcy
	builder->SetColor(D3DRMCreateColorRGBA(D3DVAL(1.0), D3DVAL(1.0), D3DVAL(1.0), D3DVAL(0.2))); 

	// Create mesh associated with builder for rendering
	if (FAILED(builder->CreateMesh(&mesh)))
		ASSERT(FALSE);

	// Add one MeshBuilder's sample to user to be rendered
	if (FAILED(m_rmCircleFrame->AddVisual((LPDIRECT3DRMVISUAL) mesh)))
		ASSERT(FALSE);
	
	RELEASE(builder);
	RELEASE(mesh);

	SetCirclePosition();

	return TRUE;
	
}

void CMyDirect3DWnd::SetCirclePosition()
{
	//m_nCurrentHand = 0; // 0,1,2,
	//m_nCurrentDirection = 0; //0, 1
	//m_nCurrentItem = 0;  //0,1,2

	if(m_nCurrentHand == 0)
	{
		if(m_nCurrentDirection == 0)
		{
			LPDIRECT3DRMFRAMEARRAY Frames = NULL;

			m_rmParentFrame->GetChildren(&Frames);
			DWORD size = Frames->GetSize();

			LPDIRECT3DRMFRAME Myframe = NULL;
			Frames->GetElement((6*9), &Myframe);

			LPDIRECT3DRMFRAME pParantFrames = NULL;
			Myframe->GetParent(&pParantFrames);
			
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(0), D3DVAL(0.0));
			Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0), D3DVAL(0),
										   D3DVAL(0), D3DVAL(GetAngle(0)));
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(-1.5*m_nCurrentItem+1.4), D3DVAL(0.0));
			
		}
		else if(m_nCurrentDirection == 1)
		{
			LPDIRECT3DRMFRAMEARRAY Frames = NULL;

			m_rmParentFrame->GetChildren(&Frames);
			DWORD size = Frames->GetSize();

			LPDIRECT3DRMFRAME Myframe = NULL;
			Frames->GetElement((6*9), &Myframe);

			LPDIRECT3DRMFRAME pParantFrames = NULL;
			Myframe->GetParent(&pParantFrames);

			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(0), D3DVAL(0.0));
			Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0), D3DVAL(0),
										   D3DVAL(0), D3DVAL(GetAngle(0)));
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(-1.5*m_nCurrentItem+1.4), D3DVAL(0.0));

		}
		else{ASSERT(FALSE);}
	}
	else if(m_nCurrentHand == 1)
	{
		if(m_nCurrentDirection == 0)
		{
			LPDIRECT3DRMFRAMEARRAY Frames = NULL;

			m_rmParentFrame->GetChildren(&Frames);
			DWORD size = Frames->GetSize();

			LPDIRECT3DRMFRAME Myframe = NULL;
			Frames->GetElement((6*9), &Myframe);

			LPDIRECT3DRMFRAME pParantFrames = NULL;
			Myframe->GetParent(&pParantFrames);
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(0), D3DVAL(0.0));

			Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0), D3DVAL(0),
										   D3DVAL(1), D3DVAL(GetAngle(90)));
			Myframe->SetPosition(pParantFrames, D3DVAL(1.5*m_nCurrentItem-1.4), D3DVAL(0), D3DVAL(0.0));
		}
		else if(m_nCurrentDirection == 1)
		{
			LPDIRECT3DRMFRAMEARRAY Frames = NULL;

			m_rmParentFrame->GetChildren(&Frames);
			DWORD size = Frames->GetSize();

			LPDIRECT3DRMFRAME Myframe = NULL;
			Frames->GetElement((6*9), &Myframe);

			LPDIRECT3DRMFRAME pParantFrames = NULL;
			Myframe->GetParent(&pParantFrames);
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(0), D3DVAL(0.0));

			Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0), D3DVAL(0),
										   D3DVAL(1), D3DVAL(GetAngle(90)));
			Myframe->SetPosition(pParantFrames, D3DVAL(1.5*m_nCurrentItem-1.4), D3DVAL(0), D3DVAL(0.0));

		}
		else{ASSERT(FALSE);}
	}
	else if(m_nCurrentHand == 2)
	{
		if(m_nCurrentDirection == 0)
		{
			LPDIRECT3DRMFRAMEARRAY Frames = NULL;

			m_rmParentFrame->GetChildren(&Frames);
			DWORD size = Frames->GetSize();

			LPDIRECT3DRMFRAME Myframe = NULL;
			Frames->GetElement((6*9), &Myframe);

			LPDIRECT3DRMFRAME pParantFrames = NULL;
			Myframe->GetParent(&pParantFrames);
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(0), D3DVAL(0.0));

			Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(1), D3DVAL(0),
										   D3DVAL(0), D3DVAL(GetAngle(90)));
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(0), D3DVAL(1.5*m_nCurrentItem-1.4));
			
		}
		else if(m_nCurrentDirection == 1)
		{
			LPDIRECT3DRMFRAMEARRAY Frames = NULL;

			m_rmParentFrame->GetChildren(&Frames);
			DWORD size = Frames->GetSize();

			LPDIRECT3DRMFRAME Myframe = NULL;
			Frames->GetElement((6*9), &Myframe);

			LPDIRECT3DRMFRAME pParantFrames = NULL;
			Myframe->GetParent(&pParantFrames);
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(0), D3DVAL(0.0));

			Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(1), D3DVAL(0),
										   D3DVAL(0), D3DVAL(GetAngle(90)));
			Myframe->SetPosition(pParantFrames, D3DVAL(0), D3DVAL(0), D3DVAL(1.5*m_nCurrentItem-1.4));

		}
		else{ASSERT(FALSE);}
	}
	
}

// get the map
void CMyDirect3DWnd::GetRotateMap(int nHand, int nItem, int nDirection, BYTE map[6][9])
{
	int nPage = -1;
	
	switch(nHand)
	{
		case 0:
			{
				if (nItem == 0) nPage = 1;
				else if (nItem == 2) nPage = 3;
				
				int nRow = nItem*3;

				if (nDirection == 0)
				{
					map[0][0+nRow] = m_map[4][2+nRow];
					map[0][1+nRow] = m_map[4][1+nRow];
					map[0][2+nRow] = m_map[4][0+nRow];
					
					map[4][0+nRow] = m_map[2][0+nRow];
					map[4][1+nRow] = m_map[2][1+nRow];
					map[4][2+nRow] = m_map[2][2+nRow];

					map[2][0+nRow] = m_map[5][2+nRow];
					map[2][1+nRow] = m_map[5][1+nRow];
					map[2][2+nRow] = m_map[5][0+nRow];

					map[5][0+nRow] = m_map[0][0+nRow];
					map[5][1+nRow] = m_map[0][1+nRow];
					map[5][2+nRow] = m_map[0][2+nRow];
				}
				else if (nDirection == 1)
				{
					map[4][2+nRow] = m_map[0][0+nRow];
					map[4][1+nRow] = m_map[0][1+nRow];
					map[4][0+nRow] = m_map[0][2+nRow];
					
					map[2][0+nRow] = m_map[4][0+nRow];
					map[2][1+nRow] = m_map[4][1+nRow];
					map[2][2+nRow] = m_map[4][2+nRow];

					map[5][2+nRow] = m_map[2][0+nRow];
					map[5][1+nRow] = m_map[2][1+nRow];
					map[5][0+nRow] = m_map[2][2+nRow];

					map[0][0+nRow] = m_map[5][0+nRow];
					map[0][1+nRow] = m_map[5][1+nRow];
					map[0][2+nRow] = m_map[5][2+nRow];
				}
				else
					ASSERT(FALSE);
				break;
					
			}
		case 1:
			{
				if (nItem == 0) nPage = 4;
				else if (nItem == 2) nPage = 5;
				int nRow = nItem;

				if (nDirection == 0)
				{
					map[0][0+nRow] = m_map[3][0+nRow];
					map[0][3+nRow] = m_map[3][3+nRow];
					map[0][6+nRow] = m_map[3][6+nRow];
					
					map[1][6+nRow] = m_map[0][0+nRow];
					map[1][3+nRow] = m_map[0][3+nRow];
					map[1][0+nRow] = m_map[0][6+nRow];

					map[2][0+nRow] = m_map[1][0+nRow];
					map[2][3+nRow] = m_map[1][3+nRow];
					map[2][6+nRow] = m_map[1][6+nRow];

					map[3][6+nRow] = m_map[2][0+nRow];
					map[3][3+nRow] = m_map[2][3+nRow];
					map[3][0+nRow] = m_map[2][6+nRow];
				}
				else if (nDirection == 1)
				{
					map[0][0+nRow] = m_map[1][6+nRow];
					map[0][3+nRow] = m_map[1][3+nRow];
					map[0][6+nRow] = m_map[1][0+nRow];
					
					map[1][6+nRow] = m_map[2][6+nRow];
					map[1][3+nRow] = m_map[2][3+nRow];
					map[1][0+nRow] = m_map[2][0+nRow];

					map[2][0+nRow] = m_map[3][6+nRow];
					map[2][3+nRow] = m_map[3][3+nRow];
					map[2][6+nRow] = m_map[3][0+nRow];

					map[3][6+nRow] = m_map[0][6+nRow];
					map[3][3+nRow] = m_map[0][3+nRow];
					map[3][0+nRow] = m_map[0][0+nRow];
				}
				else
					ASSERT(FALSE);
		
				break;
			}
		case 2:
			{
				if (nItem == 0) nPage = 0;
				else if (nItem == 2) nPage = 2;
				int nRow = nItem*3;

				if (nDirection == 0)
				{
					map[5][0+nItem] = m_map[1][0+nRow];
					map[5][3+nItem] = m_map[1][1+nRow];
					map[5][6+nItem] = m_map[1][2+nRow];
					
					map[1][0+nRow] = m_map[4][6+nItem];
					map[1][1+nRow] = m_map[4][3+nItem];
					map[1][2+nRow] = m_map[4][0+nItem];

					map[4][0+nItem] = m_map[3][0+nRow];
					map[4][3+nItem] = m_map[3][1+nRow];
					map[4][6+nItem] = m_map[3][2+nRow];

					map[3][0+nRow] = m_map[5][6+nItem];
					map[3][1+nRow] = m_map[5][3+nItem];
					map[3][2+nRow] = m_map[5][0+nItem];
				}
				else if (nDirection == 1)
				{
					map[1][0+nRow] = m_map[5][0+nItem];
					map[1][1+nRow] = m_map[5][3+nItem];
					map[1][2+nRow] = m_map[5][6+nItem];
					
					map[4][6+nItem] = m_map[1][0+nRow];
					map[4][3+nItem] = m_map[1][1+nRow];
					map[4][0+nItem] = m_map[1][2+nRow];

					map[3][0+nRow] = m_map[4][0+nItem];
					map[3][1+nRow] = m_map[4][3+nItem];
					map[3][2+nRow] = m_map[4][6+nItem];

					map[5][6+nItem] = m_map[3][0+nRow];
					map[5][3+nItem] = m_map[3][1+nRow];
					map[5][0+nItem] = m_map[3][2+nRow];
				}
				else
					ASSERT(FALSE);
		
				break;
			}
		default:
			{
				ASSERT(FALSE);
			}
	}
	if (nPage>=0)
	{
		for(int j=0; j<9; j++)
		{
			int offset = 0;
			if (j == 0) offset = 6;
			if (j == 1) offset = 2;
			if (j == 2) offset = -2;
			if (j == 3) offset = 4;
			if (j == 4) offset = 0;
			if (j == 5) offset = -4;
			if (j == 6) offset = 2;
			if (j == 7) offset = -2;
			if (j == 8) offset = -6;

			ASSERT(((j+offset)<9) && ((j+offset)>=0));
			if (nDirection == 0)
				map[nPage][j] = m_map[nPage][j+offset];
			else if (nDirection == 1)
				map[nPage][j+offset] = m_map[nPage][j];
			else
				ASSERT(FALSE);
		}
	}
} // void CMyDirect3DWnd::GetRotateMap

void CMyDirect3DWnd::AnimateRotationFrame(float  wAngleX, float  wAngleY, float  wAngleZ, BYTE map[6][9])
{
	LPDIRECT3DRMFRAMEARRAY Frames = NULL;
	
	m_rmParentFrame->GetChildren(&Frames);
	DWORD size = Frames->GetSize();

	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			if (map[i][j] != 0xff)
			{
				ASSERT((map[i][j]<6) && (map[i][j]>=0));
				
				LPDIRECT3DRMFRAME Myframe = NULL;
				//LPDIRECT3DRMFRAME2 MyParent = NULL;
				
				Frames->GetElement((i*9+j), &Myframe);
				//Myframe->GetScene(&MyParent);
				if(wAngleX != 0)
				{
					Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(1), D3DVAL(0.0),
										   D3DVAL(0), D3DVAL(GetAngle(wAngleX)));
				}
				else if(wAngleY != 0)
				{
					Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0), D3DVAL(1.0),
										   D3DVAL(0), D3DVAL(GetAngle(wAngleY)));
				}
				else if(wAngleZ != 0)
				{
					Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0), D3DVAL(0.0),
										   D3DVAL(1), D3DVAL(GetAngle(wAngleZ)));
				}
				else
				{
					Myframe->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0), D3DVAL(0),
										   D3DVAL(0), D3DVAL(GetAngle(0.0f)));
				}
			}
		}
	}
	UpdateAllFrames();
}

void CMyDirect3DWnd::DoRotate()
{
	//////////////////
	BYTE map[6][9];
	memset(map, 0xff, sizeof(map));
	// Now get map, the needed -rotated item, map [i][j] will
	// be filled with the value which it would been rotated to.
	GetRotateMap(m_nCurrentHand, m_nCurrentItem, m_nCurrentDirection, map);
	
	// now do different animation.
	switch(m_nCurrentHand)
	{
	case 0:
		{
			float  wAngleY = 0.0f;
			if (m_nCurrentDirection == 1)
			{
				while(wAngleY <= 90.0f)
				{
					wAngleY += 2.0f;
					AnimateRotationFrame(0, wAngleY, 0, map);
					Sleep(15);
				}
			}
			else if (m_nCurrentDirection == 0)
			{
				while(wAngleY >= -90.0f)
				{
					wAngleY -= 2.0f;
					AnimateRotationFrame(0, wAngleY, 0, map);
					Sleep(15);
				}
			}
			else{ASSERT(FALSE);}

			break;
		}
	case 1:
		{
			float  wAngleX = 0.0f;
			if (m_nCurrentDirection == 0)
			{
				while(wAngleX <= 90.0f)
				{
					wAngleX += 2.0f;
					AnimateRotationFrame(wAngleX, 0, 0, map);
					Sleep(15);
				}
			}
			else if (m_nCurrentDirection == 1)
			{
				while(wAngleX >= -90.0f)
				{
					wAngleX -= 2.0f;
					AnimateRotationFrame(wAngleX, 0, 0, map);
					Sleep(15);
				}
			}
			else{ASSERT(FALSE);}
			break;
		}
	case 2:
		{
			float  wAngleZ = 0.0f;
			if (m_nCurrentDirection == 1)
			{
				while(wAngleZ <= 90.0f)
				{
					wAngleZ += 2.0f;
					AnimateRotationFrame(0, 0, wAngleZ, map);
					Sleep(15);
				}
			}
			else if (m_nCurrentDirection == 0)
			{
				while(wAngleZ >= -90.0f)
				{
					wAngleZ -= 2.0f;
					AnimateRotationFrame(0, 0, wAngleZ, map);
					Sleep(15);
				}
			}
			else{ASSERT(FALSE);}
			break;
		}
	default:
		{
			ASSERT(FALSE);
		}
	}

	// Now reset the map
	ReSetMap(map);
	UpdateAllColors();

	// now render all frames with the new map
	AnimateRotationFrame(0.0f, 0.0f, 0.0f, map);
}

void CMyDirect3DWnd::UpdateAllColors()
{
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			UpdateItemColor(i, j);
		}
	}
}

void CMyDirect3DWnd::UpdateItemColor(int nPage, int nItem)
{
	// get the color
	float color[3] = { 0.0f, 0.0f, 0.0f };
	BYTE nColor = m_map[nPage][nItem];
	switch(nColor)
	{
	case 0: //red
		{
			color[0] = 1.0f;
			break;
		}
	case 1: //blue
		{
			color[2] = 1.0f;
			break;
		}
	case 2: // green
		{
			color[1] = 1.0f;
			break;
		}
	case 3: //pink
		{
			color[0] = 1.0f;
			color[2] = 1.0f;
			break;
		}
	case 4: //yellow
		{
			color[0] = 1.0f;
			color[1] = 1.0f;
			break;
		}
	case 5: // white
		{
			color[0] = 1.0f;
			color[1] = 1.0f;
			color[2] = 1.0f;
			break;
		}
	default:
		{
			ASSERT(FALSE);
		}
	}
	
	LPDIRECT3DRMFRAMEARRAY Frames = NULL;
	
	m_rmParentFrame->GetChildren(&Frames);
	DWORD size = Frames->GetSize();

	LPDIRECT3DRMFRAME Myframe = NULL;
	Frames->GetElement((nPage*9+nItem), &Myframe);
	
	Myframe->SetMaterialMode(D3DRMMATERIAL_FROMFRAME);
	Myframe->SetTexture(m_lpMyTexture[m_map[nPage][nItem]]);
}

void CMyDirect3DWnd::ReSetMap(BYTE map[][9])
{
	for(int i=0; i<6; i++)
	{
		for(int j=0; j<9; j++)
		{
			if (map[i][j] != 0xff)
			{
				m_map[i][j] = map[i][j];
			}
		}
	}
}

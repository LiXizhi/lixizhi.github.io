// Super3DDlg.h : header file
//

#if !defined(AFX_SUPER3DDLG_H__48B891A3_C5DF_11D2_A5EA_000021E2BB14__INCLUDED_)
#define AFX_SUPER3DDLG_H__48B891A3_C5DF_11D2_A5EA_000021E2BB14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSuper3DDlg dialog
class CMyDirect3DWnd;
class CSuper3DDlg : public CDialog
{
// Construction
public:
	CMyDirect3DWnd * m_pMyTestWnd;
	CSuper3DDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSuper3DDlg)
	enum { IDD = IDD_SUPER3D_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuper3DDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSuper3DDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnChangeGroup();
	afx_msg void OnChangeItem();
	afx_msg void OnChangeDirection();
	afx_msg void OnRotate();
	afx_msg void OnChangesize();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUPER3DDLG_H__48B891A3_C5DF_11D2_A5EA_000021E2BB14__INCLUDED_)

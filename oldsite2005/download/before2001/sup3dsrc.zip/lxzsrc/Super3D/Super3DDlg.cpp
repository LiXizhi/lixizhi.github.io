// Super3DDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Super3D.h"
#include "Super3DDlg.h"
#include "MyDirect3DWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuper3DDlg dialog

CSuper3DDlg::CSuper3DDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSuper3DDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSuper3DDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSuper3DDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSuper3DDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSuper3DDlg, CDialog)
	//{{AFX_MSG_MAP(CSuper3DDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHANGE_GROUP, OnChangeGroup)
	ON_BN_CLICKED(IDC_CHANGE_ITEM, OnChangeItem)
	ON_BN_CLICKED(IDC_CHANGE_DIRECTION, OnChangeDirection)
	ON_BN_CLICKED(IDC_Rotate, OnRotate)
	ON_BN_CLICKED(IDC_CHANGESIZE, OnChangesize)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuper3DDlg message handlers

BOOL CSuper3DDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	OnChangesize();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSuper3DDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSuper3DDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSuper3DDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

int CSuper3DDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_pMyTestWnd = new CMyDirect3DWnd;
	m_pMyTestWnd->Create(CRect(0, 0, 400, 300), this, 666);
	
	return 0;
}

void CSuper3DDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	m_pMyTestWnd->OnDestroy();
	delete m_pMyTestWnd;
}


void CSuper3DDlg::OnChangeGroup() 
{
	m_pMyTestWnd->m_nCurrentHand ++;
	m_pMyTestWnd->m_nCurrentHand = m_pMyTestWnd->m_nCurrentHand%3;
	m_pMyTestWnd->SetCirclePosition();
	m_pMyTestWnd->RenderLoop();
}

void CSuper3DDlg::OnChangeItem() 
{
	m_pMyTestWnd->m_nCurrentItem ++;
	m_pMyTestWnd->m_nCurrentItem = m_pMyTestWnd->m_nCurrentItem%3;
	m_pMyTestWnd->SetCirclePosition();
	m_pMyTestWnd->RenderLoop();
	
}

void CSuper3DDlg::OnChangeDirection() 
{
	m_pMyTestWnd->m_nCurrentDirection ++;
	m_pMyTestWnd->m_nCurrentDirection = m_pMyTestWnd->m_nCurrentDirection%2;
	m_pMyTestWnd->SetCirclePosition();
	m_pMyTestWnd->RenderLoop();
}

void CSuper3DDlg::OnRotate() 
{
	m_pMyTestWnd->DoRotate();
}

void CSuper3DDlg::OnChangesize() 
{
	static int mode = 1;
	mode++;
	mode = mode%3;

	CRect rect;
	GetDlgItem(IDC_RECT)->GetWindowRect(&rect);
	ScreenToClient(&rect);

	if(mode == 0)
	{
		MoveWindow(10, 10, 600, 450, TRUE);
		m_pMyTestWnd->MoveWindow(140, 0, 400, 300, FALSE);
		m_pMyTestWnd->UpdateAllFrames();
	}
	else if(mode == 1)
	{
		MoveWindow(10, 10, 450, 350, TRUE);
		m_pMyTestWnd->MoveWindow(140, 0, 300, 200, FALSE);
		m_pMyTestWnd->UpdateAllFrames();
	}
	else if(mode == 2)
	{
		MoveWindow(0, 0, 850, 600, TRUE);
		m_pMyTestWnd->MoveWindow(140, 0, 700, 500, FALSE);
		m_pMyTestWnd->UpdateAllFrames();
	}
	else
	{
		ASSERT(FALSE);
	}
	
}

// Direct3D.cpp : implementation file
//
#define INITGUID

#include "stdafx.h"
#include "Super3D.h"
#include "Direct3D.h"
#include <math.h> 

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
#define PI2 6.28318
#define XPOS 0.0
#define INTERPOLATE_STEP 0.05
D3DRMQUATERNION q;

MyDirect3D CDirect3D::myglobs;
LPDIRECT3DRM2 CDirect3D::lpD3DRM;           /* Direct3DRM object */
LPDIRECTDRAWCLIPPER CDirect3D::lpDDClipper;/* DirectDrawClipper object */
int CDirect3D::view_width;
int CDirect3D::view_height;
//int CDirect3D::dev_width;
//int CDirect3D::dev_height;
DWORD BPPToDDBD(int bpp);
/////////////////////////////////////////////////////////////////////////////
// CDirect3D

CDirect3D::CDirect3D()
{
}

CDirect3D::~CDirect3D()
{
}


BEGIN_MESSAGE_MAP(CDirect3D, CWnd)
	//{{AFX_MSG_MAP(CDirect3D)
	ON_WM_DESTROY()
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_MOUSEMOVE()
	ON_WM_ACTIVATE()
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDirect3D message handlers

void CDirect3D::OnDestroy() 
{
	CWnd::OnDestroy();
	DelDirect3D();
}

int CDirect3D::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	return 0;
}

void CDirect3D::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent == 1)
	{
		RenderLoop();
	}

	CWnd::OnTimer(nIDEvent);
}

BOOL CDirect3D::PreCreateWindow(CREATESTRUCT& cs) 
{
	return CWnd::PreCreateWindow(cs);
}

/****************************************************************************/
/*                   Initialization and object creation                     */
/****************************************************************************/
/*
 * InitApp
 * Creates window and initializes all objects neccessary to begin rendering
 */
HWND CDirect3D::InitDirect3D(HINSTANCE this_inst, int cmdshow) // HINSTANCE this_inst not useful
{
    Defaults defaults;
    HRESULT rval;
    RECT rc;
	
	HWND hWnd = GetSafeHwnd();
	ASSERT(hWnd);
   
    /*
     * Initialize the global variables and allow the sample code to override
     * some of these default settings.
     */
    InitGlobals();
    defaults.bNoTextures = myglobs.bNoTextures;
    defaults.bConstRenderQuality = myglobs.bConstRenderQuality;
    defaults.bResizingDisabled = FALSE;
    lstrcpy(defaults.Name, "D3DRM Example");
    OverrideDefaults(&defaults);	// allow override this to set default setting
    myglobs.bNoTextures = defaults.bNoTextures;
    myglobs.bConstRenderQuality = defaults.bConstRenderQuality;
    
    /*
     * Record the current display BPP
     */
	CDC* pDC = GetDC();
    myglobs.BPP = pDC->GetDeviceCaps(BITSPIXEL);
    ReleaseDC(pDC);
    /*
     * Enumerate the D3D drivers and select one
     */
    if (!EnumDevices(hWnd))
        ASSERT(FALSE);
    /*
     * Create the D3DRM object and the D3DRM window object
     */
    
	
	
	/*
     * Need DX5 version for alpha blending and progressive meshes.
     */
	//DWORD	dwDXVersion, dwDXPlatform;
	//GetdxVersion

	LPDIRECT3DRM lpD3DRM1;
    rval = Direct3DRMCreate(&lpD3DRM1);
    if (rval != D3DRM_OK) {
	MessageBox("Failed to create Direct3DRM.\n%s");
	ASSERT(FALSE);
    }

    rval = lpD3DRM1->QueryInterface(IID_IDirect3DRM2, (LPVOID*)&lpD3DRM);
    if (rval != D3DRM_OK) {
	MessageBox("Failed to QI for IID_IDirect3DRM2.\n%s");
	ASSERT(FALSE);
    }

	/*
     * Create the master scene frame and camera frame
     */
    rval = lpD3DRM->CreateFrame(NULL, &myglobs.scene);
    if (rval != D3DRM_OK) {
        AfxMessageBox("Failed to create the master scene frame.\n%s");
        return FALSE;
    }
    rval = lpD3DRM->CreateFrame(myglobs.scene, &myglobs.camera);
    if (rval != D3DRM_OK) {
        AfxMessageBox("Failed to create the camera's frame.\n%s");
        return FALSE;
    }
    rval = myglobs.camera->SetPosition(myglobs.scene, D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0));
    if (rval != D3DRM_OK) {
        AfxMessageBox("Failed to position the camera in the frame.\n%s");
        return FALSE;
    }
    /*
     * Create a clipper and associate the window with it
     */
    rval = DirectDrawCreateClipper(0, &lpDDClipper, NULL);
    if (rval != DD_OK) {
        AfxMessageBox("Failed to create DirectDrawClipper");
        return FALSE;
    }
	
	rval = lpDDClipper->SetHWnd(0, hWnd);
    if (rval != DD_OK) {
        AfxMessageBox("Failed to set hwnd on the clipper");
        return FALSE;
    }
    /*
     * Created the D3DRM device with the selected D3D driver
     */
    GetClientRect(&rc);
    if (rval = CreateDevAndView(lpDDClipper, myglobs.CurrDriver, rc.right, rc.bottom)) {
	myglobs.CurrDriver = 0;
	if (rval = CreateDevAndView(lpDDClipper, myglobs.CurrDriver, rc.right, rc.bottom)) {
	    AfxMessageBox("Failed to create the D3DRM device.\n%s");
	    return FALSE;
	}
    }
    /*
     * Create the scene to be rendered by calling this sample's BuildScene
     */
    if (!BuildScene(myglobs.dev, myglobs.view, myglobs.scene, myglobs.camera))
        return FALSE;
    /*
     * Display the window
     */
    ShowWindow(SW_SHOW);
    UpdateWindow();
    /*
     * Now we are ready to render
     */
    myglobs.bInitialized = TRUE;

    //UpdateAllFrames();
	return hWnd;
}

/*
 * InitGlobals
 * Initialize the global variables
 */
void CDirect3D::InitGlobals(void)
{
    lpD3DRM = NULL;
    memset(&myglobs, 0, sizeof(myglobs));
    myglobs.RenderQuality = D3DRMLIGHT_ON | D3DRMFILL_SOLID |
                            D3DRMSHADE_GOURAUD;
    myglobs.TextureQuality = D3DRMTEXTURE_NEAREST;
}

void CDirect3D::OverrideDefaults(Defaults* defaults)
{
    defaults->bNoTextures = FALSE;
    defaults->bConstRenderQuality = TRUE;
    lstrcpy(defaults->Name, "My direct3d test by LiXizhi");
}

/*
 * enumDeviceFunc
 * Callback function which records each usable D3D driver's name and GUID
 * Chooses a driver to begin with and sets *lpContext to this starting driver
 */
HRESULT WINAPI CDirect3D::enumDeviceFunc(LPGUID lpGuid, LPSTR lpDeviceDescription, LPSTR lpDeviceName,
        LPD3DDEVICEDESC lpHWDesc, LPD3DDEVICEDESC lpHELDesc, LPVOID lpContext)
{
    static BOOL hardware = FALSE; /* current start driver is hardware */
    static BOOL mono = FALSE;     /* current start driver is mono light */
    LPD3DDEVICEDESC lpDesc;
    int *lpStartDriver = (int *)lpContext;
    /*
     * Decide which device description we should consult
     */
    lpDesc = lpHWDesc->dcmColorModel ? lpHWDesc : lpHELDesc;
    /*
     * If this driver cannot render in the current display bit depth skip
     * it and continue with the enumeration.
     */
    if (!(lpDesc->dwDeviceRenderBitDepth & BPPToDDBD(myglobs.BPP)))
        return D3DENUMRET_OK;
    /*
     * Record this driver's info
     */
    memcpy(&myglobs.DriverGUID[myglobs.NumDrivers], lpGuid, sizeof(GUID));
    lstrcpy(&myglobs.DriverName[myglobs.NumDrivers][0], lpDeviceName);
    /*
     * Choose hardware over software, RGB lights over mono lights
     */
    if (*lpStartDriver == -1) {
        /*
         * this is the first valid driver
         */
        *lpStartDriver = myglobs.NumDrivers;
        hardware = lpDesc == lpHWDesc ? TRUE : FALSE;
        mono = lpDesc->dcmColorModel & D3DCOLOR_MONO ? TRUE : FALSE;
    } else if (lpDesc == lpHWDesc && !hardware) {
        /*
         * this driver is hardware and start driver is not
         */
        *lpStartDriver = myglobs.NumDrivers;
        hardware = lpDesc == lpHWDesc ? TRUE : FALSE;
        mono = lpDesc->dcmColorModel & D3DCOLOR_MONO ? TRUE : FALSE;
    } else if ((lpDesc == lpHWDesc && hardware ) || (lpDesc == lpHELDesc
                                                     && !hardware)) {
        if (lpDesc->dcmColorModel == D3DCOLOR_MONO && !mono) {
            /*
             * this driver and start driver are the same type and this
             * driver is mono while start driver is not
             */
            *lpStartDriver = myglobs.NumDrivers;
            hardware = lpDesc == lpHWDesc ? TRUE : FALSE;
            mono = lpDesc->dcmColorModel & D3DCOLOR_MONO ? TRUE : FALSE;
        }
    }
    myglobs.NumDrivers++;
    if (myglobs.NumDrivers == MAX_DRIVERS)
        return (D3DENUMRET_CANCEL);
    return (D3DENUMRET_OK);
}

/*
 * EnumDevices
 * Enumerate the available D3D drivers, add them to the file menu, and choose
 * one to use.
 */
BOOL CDirect3D::EnumDevices(HWND win)
{
    LPDIRECTDRAW lpDD;
    LPDIRECT3D lpD3D;
    HRESULT rval;
    //HMENU hmenu;
    //int i;

    /*
     * Create a DirectDraw object and query for the Direct3D interface to use
     * to enumerate the drivers.
     */
    rval = DirectDrawCreate(NULL, &lpDD, NULL);
    if (rval != DD_OK) {
        AfxMessageBox("Creation of DirectDraw HEL failed.\n%s");
        return FALSE;
    }
    rval = lpDD->QueryInterface(IID_IDirect3D, (void**) &lpD3D);
    if (rval != DD_OK) {
        AfxMessageBox("Creation of Direct3D interface failed.\n%s");
        lpDD->Release();
        return FALSE;
    }
    /*
     * Enumerate the drivers, setting CurrDriver to -1 to initialize the
     * driver selection code in enumDeviceFunc
     */
    myglobs.CurrDriver = -1;
    rval = lpD3D->EnumDevices(enumDeviceFunc, &myglobs.CurrDriver);
    if (rval != DD_OK) {
        AfxMessageBox("Enumeration of drivers failed.\n%s");
        return FALSE;
    }
    /*
     * Make sure we found at least one valid driver
     */
    if (myglobs.NumDrivers == 0) {
        AfxMessageBox("Could not find a D3D driver which is compatible with this display depth");
        return FALSE;
    }
    lpD3D->Release();
    lpDD->Release();

    // Add the driver names to the File menu
    /*
	hmenu = GetSubMenu(GetMenu(win), 0);
    for (i = 0; i < myglobs.NumDrivers; i++) {
        InsertMenu(hmenu, 5 + i, MF_BYPOSITION | MF_STRING, MENU_FIRST_DRIVER + i,
                   myglobs.DriverName[i]);
    }
	*/
    return TRUE;
}

/*
 * CreateDevAndView
 * Create the D3DRM device and viewport with the given D3D driver and of the
 * specified size.
 */
HRESULT CDirect3D::CreateDevAndView(LPDIRECTDRAWCLIPPER lpDDClipper, int driver, int width, int height)
{
    HRESULT rval;

    if (!width || !height)
        return D3DRMERR_BADVALUE;
    /*
     * Create the D3DRM device from this window and using the specified D3D
     * driver.
     */
    rval = lpD3DRM->CreateDeviceFromClipper(lpDDClipper, &myglobs.DriverGUID[driver],
                                        width, height, &myglobs.dev);
    if (rval != D3DRM_OK)
        return rval;
    /*
     * Create the D3DRM viewport using the camera frame.  Set the background
     * depth to a large number.  The width and height may be slightly
     * adjusted, so get them from the device to be sure.
     */
    width = myglobs.dev->GetWidth();
    height = myglobs.dev->GetHeight();
    rval = lpD3DRM->CreateViewport(myglobs.dev, myglobs.camera, 0, 0, width,
                                   height, &myglobs.view);
    if (rval != D3DRM_OK) {
	myglobs.bInitialized = FALSE;
        RELEASE(myglobs.dev);
        return rval;
    }
    rval = myglobs.view->SetBack(D3DVAL(5000.0));
    if (rval != D3DRM_OK) {
	myglobs.bInitialized = FALSE;
        RELEASE(myglobs.dev);
        RELEASE(myglobs.view);
        return rval;
    }
    /*
     * Set the render quality, fill mode, lighting state and color shade info
     */
    if (rval = SetRenderState()) {
	myglobs.bInitialized = FALSE;
        RELEASE(myglobs.dev);
        RELEASE(myglobs.view);
        return rval;
    }

    return D3DRM_OK;
}

BOOL CDirect3D::BuildScene(LPDIRECT3DRMDEVICE2 dev, LPDIRECT3DRMVIEWPORT view,
	   LPDIRECT3DRMFRAME2 scene, LPDIRECT3DRMFRAME2 camera)
{
	// Add some code here ------by Lxz
	D3DRMRENDERQUALITY quality = D3DRMRENDER_FLAT;
	LPDIRECT3DRMFRAME2 lights = NULL;
	LPDIRECT3DRMLIGHT l1 = NULL;
    LPDIRECT3DRMLIGHT l2 = NULL;
	
	if (FAILED(dev->SetQuality(quality)))
		ASSERT(FALSE);
	view_width = view->GetWidth();
    view_height = view->GetHeight();
	
	// set camera's Position
	if (FAILED(camera->SetPosition(scene, D3DVAL(0), D3DVAL(0), D3DVAL(-12))))
		ASSERT(FALSE);
	
	// initialize the lights in the scene
    if (FAILED(lpD3DRM->CreateFrame(scene, &lights)))
		ASSERT(FALSE);
    if (FAILED(lights->SetOrientation(scene, D3DVAL(-1), D3DVAL(-1), D3DVAL(0), D3DVAL(0), D3DVAL(1), D3DVAL(0))))
		ASSERT(FALSE);
    if (FAILED(lpD3DRM->CreateLightRGB(D3DRMLIGHT_DIRECTIONAL  , D3DVAL(1), D3DVAL(1), D3DVAL(1), &l1)))
		ASSERT(FALSE);
    if (FAILED(lights->AddLight(l1)))
		ASSERT(FALSE);
    if (FAILED(lpD3DRM->CreateLightRGB(D3DRMLIGHT_AMBIENT, D3DVAL(0.5), D3DVAL(0.5), D3DVAL(0.5), &l2)))
		ASSERT(FALSE);
    if (FAILED(scene->AddLight(l2)))
		ASSERT(FALSE);

	////// Fog enables
	//LPDIRECT3DRMFRAME2 fog;
	//if (FAILED(lpD3DRM->CreateFrame(scene, &fog)))
		//ASSERT(FALSE);

	//scene->SetSceneFogEnable(TRUE);
	//scene->SetSceneFogColor(D3DRMCreateColorRGBA(D3DVAL(0.5), D3DVAL(0.5), D3DVAL(0.0), D3DVAL(0.3)));
	//scene->SetSceneFogMode(D3DRMFOG_EXPONENTIAL);
	//scene->SetSceneFogParams(D3DVAL(-12), D3DVAL(12), D3DVAL(0.01));
	scene->SetSceneBackground(D3DRMCreateColorRGB(D3DVAL(0.5372549), D3DVAL(0.5372549), D3DVAL(0.5372549)));
	
	//////////////// D3DRMLIGHT_DIRECTIONAL is the default///////////////////
	//D3DRMLIGHTTYPE lightType = l1->GetType(); 
	//lightType = D3DRMLIGHT_DIRECTIONAL
	//l1->SetType(lightType);
	/////////////////////////////////////////////////////////////////////////

	// Add More User-defined Frames
	AddMoreFrames(dev, view, scene, camera);

	RELEASE(lights);
    RELEASE(l1);
    RELEASE(l2);
    
    return TRUE;
}

/*
 * DelDirect3D()
 * Release all D3DRM objects, post a quit message and set the bQuit flag
 */
void CDirect3D::DelDirect3D()
{
    myglobs.bInitialized = FALSE;
    RELEASE(myglobs.scene);
    RELEASE(myglobs.camera);
    RELEASE(myglobs.view);
    RELEASE(myglobs.dev);
    RELEASE(lpD3DRM);
    RELEASE(lpDDClipper);
    myglobs.bQuit = TRUE;
}

/*
 * BPPToDDBD
 * Converts bits per pixel to a DirectDraw bit depth flag
 */
static DWORD
BPPToDDBD(int bpp)
{
    switch(bpp) {
        case 1:
            return DDBD_1;
        case 2:
            return DDBD_2;
        case 4:
            return DDBD_4;
        case 8:
            return DDBD_8;
        case 16:
            return DDBD_16;
        case 24:
            return DDBD_24;
        case 32:
            return DDBD_32;
        default:
            return 0;
    }
}
/*
 * SetRenderState
 * Set the render quality, dither toggle and shade info if any of them has
 * changed
 */
HRESULT CDirect3D::SetRenderState(void)
{
    HRESULT rval;
	
	rval = myglobs.dev->SetRenderMode(D3DRMRENDERMODE_BLENDEDTRANSPARENCY|D3DRMRENDERMODE_SORTEDTRANSPARENCY);
	if(rval!= D3DRM_OK)
	{
		ASSERT(FALSE);
	}
    /*
     * Set the render quality (light toggle, fill mode, shade mode)
     */
    if (myglobs.dev->GetQuality() != myglobs.RenderQuality) {
        rval = myglobs.dev->SetQuality(myglobs.RenderQuality);
        if (rval != D3DRM_OK)
	    return rval;
    }
    /*
     * Set dithering toggle
     */
    if (myglobs.dev->GetDither() != myglobs.bDithering) {
        rval = myglobs.dev->SetDither(myglobs.bDithering);
        if (rval != D3DRM_OK) 
	    return rval;
    }
    /*
     * Set the texture quality (point or linear filtering)
     */
    if (myglobs.dev->GetTextureQuality() != myglobs.TextureQuality) {
        rval = myglobs.dev->SetTextureQuality(myglobs.TextureQuality);
        if (rval != D3DRM_OK) 
	    return rval;
    }
    /*
     * Set shade info based on current bits per pixel
     */
    switch (myglobs.BPP) {
    case 1:
        if (rval = myglobs.dev->SetShades(4))
            return rval;
        if (rval = lpD3DRM->SetDefaultTextureShades(4))
            return rval;
        break;
    case 16:
        if (rval = myglobs.dev->SetShades(32))
            return rval;
        if (rval = lpD3DRM->SetDefaultTextureColors(64))
            return rval;
        if (rval = lpD3DRM->SetDefaultTextureShades(32))
            return rval;
        break;
    case 24:
    case 32:
        if (rval = myglobs.dev->SetShades(256))
            return rval;
        if (rval = lpD3DRM->SetDefaultTextureColors(64))
            return rval;
        if (rval = lpD3DRM->SetDefaultTextureShades(256))
            return rval;
        break;
    }
    return D3DRM_OK;
}

BOOL CDirect3D::Create(CRect rect, CWnd* pWnd, UINT nID)
{
	VERIFY( CWnd::Create(NULL, NULL, WS_CHILD | WS_VISIBLE, rect, pWnd, nID) );
	HWND    hwnd;
	
	hwnd = InitDirect3D(NULL, SW_SHOW);
	ASSERT(hwnd);

	HACCEL  accel;
	accel = LoadAccelerators(AfxGetInstanceHandle(), "AppAccel");
	return TRUE;
}
/****************************************************************************/
/*                             Render Loop                                  */
/****************************************************************************/
/*
 * Clear the viewport, render the next frame and update the window
 */

BOOL CDirect3D::RenderLoop()
{
    HRESULT rval;
    /*
     * Tick the scene
     */
    rval = myglobs.scene->Move(D3DVAL(1.0));
	
	if (rval != D3DRM_OK) {
        ASSERT(FALSE);
        return FALSE;
    }
    /* 
     * Clear the viewport
     */
    rval = myglobs.view->Clear();
    if (rval != D3DRM_OK) {
        //Msg("Clearing viewport failed.\n%s", D3DRMErrorToString(rval));
		ASSERT(FALSE);
        return FALSE;
    }
    /*
     * Render the scene to the viewport
     */
    rval = myglobs.view->Render(myglobs.scene);
    if (rval != D3DRM_OK) {
		ASSERT(FALSE);
        //Msg("Rendering scene failed.\n%s", D3DRMErrorToString(rval));
        return FALSE;
    }
    /*
     * Update the window
     */
    rval = myglobs.dev->Update();
    if (rval != D3DRM_OK) {
        //Msg("Updating device failed.\n%s", D3DRMErrorToString(rval));
		ASSERT(FALSE);
        return FALSE;
    }
    return TRUE;
}

// very same as RenderLoop.
// The same as Swap function as in the OpenGL. 
// when a frame is changed , Call this to render them to the real screen from the memory
BOOL CDirect3D::UpdateAllFrames()
{
	return RenderLoop();
}

/*
 * ReadMouse
 * Returns the mouse status for interaction with sample code
 */
void CDirect3D::ReadMouse(int* b, int* x, int* y)
{
    *b = myglobs.mouse_buttons;
    *x = myglobs.mouse_x;
    *y = myglobs.mouse_y;
}

void CDirect3D::UserControl(LPDIRECT3DRMFRAME frame, void* arg, D3DVALUE delta)
{
    int mx, my, mb;
    LPDIRECT3DRMFRAME scene;
    D3DVALUE angle;
    D3DVECTOR vx = {D3DVAL(1), D3DVAL(0), D3DVAL(0)},
     vy = {D3DVAL(0), D3DVAL(1), D3DVAL(0)};
    D3DRMQUATERNION qx, qy;
    D3DRMMATRIX4D mat;

    //arg = arg;

    ReadMouse(&mb, &mx, &my);
    angle = D3DMultiply((-D3DVAL(0.5) + D3DDivide(D3DVAL(my),
                       D3DVAL(view_height))), D3DVAL(PI2));
    D3DRMQuaternionFromRotation(&qx, &vx, angle);
    angle = D3DMultiply((-D3DVAL(0.5) + D3DDivide(D3DVAL(mx),
                       D3DVAL(view_width))), D3DVAL(PI2));
    D3DRMQuaternionFromRotation(&qy, &vy, angle);
    D3DRMQuaternionMultiply(&q, &qx, &qy);
    D3DRMMatrixFromQuaternion(mat, &q);
    frame->AddTransform(D3DRMCOMBINE_REPLACE, mat);
    frame->GetScene(&scene);
    frame->SetPosition(scene, D3DVAL(-XPOS), D3DVAL(0),
                               D3DVAL(0));

    RELEASE(scene);
}

// Loaded by BuildScene after the Lights are initialized,
// as well as other pre initializations
// add your init here.
BOOL CDirect3D::AddMoreFrames(LPDIRECT3DRMDEVICE2 dev, LPDIRECT3DRMVIEWPORT view,
	   LPDIRECT3DRMFRAME2 scene, LPDIRECT3DRMFRAME2 camera)
{
//////////////Load a *.x file delete this//////////////////////////////////////////////////
//////////////Only a demo of how to create a frame/////////////////////////////////////////
	LPDIRECT3DRMFRAME2 user = NULL;
	LPDIRECT3DRMMESHBUILDER2 builder = NULL;
	LPDIRECT3DRMMESH mesh = NULL;

	HRESULT rval;

	// Add a new frame------user
	if (FAILED(lpD3DRM->CreateFrame(scene, &user)))
		ASSERT(FALSE);
	// Add a new MeshBuilder into ------3D
	if (FAILED(lpD3DRM->CreateMeshBuilder(&builder)))
		ASSERT(FALSE);
    rval = builder->Load("mesh1.x", NULL, D3DRMLOAD_FROMFILE, NULL, NULL);
  				
    if (rval != D3DRM_OK)
		AfxMessageBox("Failed to load dropship.x.\n%s");
	//if (FAILED(builder->Scale(D3DVAL(0.1), D3DVAL(0.08), D3DVAL(0.1))))
	if (FAILED(builder->Scale(D3DVAL(0.4), D3DVAL(0.4), D3DVAL(0.4))))
		ASSERT(FALSE);
	//builder->SetColor(D3DRMCreateColorRGB(D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0))); 

	LPDIRECT3DRMMATERIAL lpD3DRMMaterial;
	lpD3DRM->CreateMaterial(D3DVAL(0.001), &lpD3DRMMaterial);
	lpD3DRMMaterial->SetEmissive(D3DVAL(0.5), D3DVAL(0.1), D3DVAL(0.0));
	builder->SetMaterial(lpD3DRMMaterial);
	
	// Create mesh associated with builder for rendering
	if (FAILED(builder->CreateMesh(&mesh)))
		ASSERT(FALSE);
	// Add one MeshBuilder's sample to user to be rendered
	if (FAILED(user->AddVisual((LPDIRECT3DRMVISUAL) mesh)))
		ASSERT(FALSE);
	// set user callback
	//if (FAILED(user->AddMoveCallback(UserControl, NULL)))
	//	ASSERT(FALSE);

	RELEASE(builder);
	RELEASE(user);
    RELEASE(mesh);
////////////////////////////////////////////////////////////////
	/*
	//////////Your code should be added here//////////////////
	LPDIRECT3DRMFRAME Square = NULL;
	LPDIRECT3DRMMESHBUILDER mesh; 
 
	LPDIRECT3DRMMESH MyMesh = NULL;
	LPDIRECT3DRMFACE MyFace = NULL;

	//HRESULT rval;

	// Add a new frame------user
	if (FAILED(lpD3DRM->CreateFrame(scene, &Square)))
		ASSERT(FALSE);
	// Add a new MeshBuilder into ------3D
	if (FAILED(lpD3DRM->CreateMeshBuilder(&mesh)))
		ASSERT(FALSE);

    
	
	D3DVECTOR v1 = {D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0)}; 
	D3DVECTOR v2 = {D3DVAL(2.0), D3DVAL(0), D3DVAL(0.0)}; 
	D3DVECTOR v3 = {D3DVAL(2.0), D3DVAL(1.0), D3DVAL(0.0)}; 
	D3DVECTOR v4 = {D3DVAL(1.0), D3DVAL(1.0), D3DVAL(0.0)}; 
	AddRod(mesh, D3DVAL(0.5), v1, v2); 
    AddRod(mesh, D3DVAL(0.5), v2, v3); 
	AddRod(mesh, D3DVAL(0.5), v3, v4); 
    AddRod(mesh, D3DVAL(0.5), v4, v1); 

	//mesh->AddFaces(16, v, 8, n, rod_faces, NULL); 
	
	LPDIRECT3DRMTEXTURE lpD3DRMTexture;
	if (FAILED(lpD3DRM->LoadTexture("texture.bmp", &lpD3DRMTexture)))
		AfxMessageBox("Failed to load texture.bmp.\n%s");
	mesh->SetTexture(lpD3DRMTexture);

	/*
	mesh->CreateFace(&MyFace);
	MyFace->AddVertex(D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0));
	MyFace->AddVertex(D3DVAL(2.0), D3DVAL(0), D3DVAL(0.0));
	MyFace->AddVertex(D3DVAL(2.0), D3DVAL(1.0), D3DVAL(0.0));
	MyFace->AddVertex(D3DVAL(1.0), D3DVAL(1.0), D3DVAL(0.0));
	*/
	
/*
	MyFace->SetTexture(lpD3DRMTexture);
	mesh->AddFace(MyFace);
	mesh->AddVertex(D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0));
	mesh->AddVertex(D3DVAL(2.0), D3DVAL(0), D3DVAL(0.0));
	mesh->AddVertex(D3DVAL(2.0), D3DVAL(1.0), D3DVAL(0.0));
	mesh->AddVertex(D3DVAL(1.0), D3DVAL(1.0), D3DVAL(0.0));
	mesh->SetTexture(lpD3DRMTexture);
*/	
	//mesh->SetColor(D3DRMCreateColorRGB(D3DVAL(1.0), D3DVAL(1.0), D3DVAL(0.0))); 
/*
	LPDIRECT3DRMMATERIAL lpD3DRMMaterial;
	lpD3DRM->CreateMaterial(D3DVAL(1), &lpD3DRMMaterial);
	lpD3DRMMaterial->SetEmissive(D3DVAL(0.5), D3DVAL(0.1), D3DVAL(0.0));
	mesh->SetMaterial(lpD3DRMMaterial);

	
	// Create mesh associated with builder for rendering
	if (FAILED(mesh->CreateMesh(&MyMesh)))
		ASSERT(FALSE);
	// Add MeshBuilder to user to be rendered
	if (FAILED(Square->AddVisual((LPDIRECT3DRMVISUAL) MyMesh)))
		ASSERT(FALSE);

	RELEASE(mesh);
	RELEASE(Square);
    RELEASE(MyMesh);

	RELEASE(MyFace);
	*/
	return TRUE;
}

void CDirect3D::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	/*
	if (!myglobs.bInitialized || !myglobs.dev)
		CWnd::OnActivate(nState, pWndOther, bMinimized);
	
	LPDIRECT3DRMWINDEVICE windev;
	if (SUCCEEDED(myglobs.dev->QueryInterface(IID_IDirect3DRMWinDevice, (void **) &windev)))
	{
		if (FAILED(windev->HandleActivate(nState)))
			ASSERT(FALSE);
        windev->Release();
    } else {
        ASSERT(FALSE);
    }
	*/
	//UpdateAllFrames();
}

void CDirect3D::OnPaint() 
{
	if (!myglobs.bInitialized || !myglobs.dev)
		return;
	UpdateAllFrames();
	/*
	CPaintDC dc(this); // device context for painting
	if (!myglobs.bInitialized || !myglobs.dev)
		return;
	
	LPDIRECT3DRMWINDEVICE windev;
	if (SUCCEEDED(myglobs.dev->QueryInterface(IID_IDirect3DRMWinDevice, (void **) &windev)))
	{
		if (FAILED(windev->HandlePaint(dc.m_hDC)))
			ASSERT(FALSE);
        windev->Release();
    } else {
        ASSERT(FALSE);
    }
	*/
	//UpdateAllFrames();
	
	// Do not call CWnd::OnPaint() for painting messages
}


void CDirect3D::OnSize(UINT nType, int cx, int cy) 
{
	//CWnd::OnSize(nType, cx, cy);
	
	HRESULT rval;
	/*
     * Handle resizing of the window
     */
    int width = cx;
    int height = cy;
    if (width && height && myglobs.view && myglobs.dev) 
	{
        int view_width = myglobs.view->GetWidth();
        int view_height = myglobs.view->GetHeight();
        int dev_width = myglobs.dev->GetWidth();
        int dev_height = myglobs.dev->GetHeight();
        /*
         * If the window hasn't changed size and we aren't returning from
         * a minimize, there is nothing to do
         */
        if (view_width == width && view_height == height &&
            !myglobs.bMinimized)
            return;
        if (width <= dev_width && height <= dev_height)
		{
            /*
             * If the window has shrunk, we can use the same device with a
             * new viewport
             */
			myglobs.bInitialized = FALSE;
            RELEASE(myglobs.view);
            rval = lpD3DRM->CreateViewport(myglobs.dev, myglobs.camera,
                                           0, 0, width, height,
                                           &myglobs.view);
            if (rval != D3DRM_OK) {
                MessageBox("Failed to resize the viewport.\n%s");
                DelDirect3D();
                return;
            }
            rval = myglobs.view->SetBack(D3DVAL(5000.0));
            if (rval != D3DRM_OK) {
                MessageBox("Failed to set background depth after viewport resize.\n%s");
                    
                DelDirect3D();
                return;
            }
	myglobs.bInitialized = TRUE;
        }
		else 
		{
            /*
             * If the window got larger than the current device, create a
             * new device.
             */
			myglobs.bInitialized = FALSE;
					RELEASE(myglobs.view);
					RELEASE(myglobs.dev);
			if (rval = CreateDevAndView(lpDDClipper, myglobs.CurrDriver, width, height))
											
			{
				myglobs.CurrDriver = 0;
				if (rval = CreateDevAndView(lpDDClipper, myglobs.CurrDriver,
							width, height))
				{
				MessageBox("Failed to create the D3DRM device.\n%s");
				DelDirect3D();
				}
				else
				{
				MessageBox("There was not enough video memory available to use the 3D accelerated hardware device.\nUsing software rendering instead.");
				myglobs.bInitialized = TRUE;
				}
			}
			else
			{
				myglobs.bInitialized = TRUE;
			}
			myglobs.bInitialized = TRUE;
		}
		/*
		 * We must not longer be minimized
		 */
		myglobs.bMinimized = FALSE;
	} 
	else 
	{
		/*
		 * This is a minimize message
		 */
		myglobs.bMinimized = TRUE;
	}
	myglobs.bDrawAFrame = TRUE;	
}

void CDirect3D::OnLButtonDown(UINT nFlags, CPoint point) 
{
	SetCapture();
	MouseEvent3D(nFlags, point);

	CWnd::OnLButtonDown(nFlags, point);
}

void CDirect3D::OnLButtonUp(UINT nFlags, CPoint point) 
{
	ReleaseCapture();
	MouseEvent3D(nFlags, point);

	CWnd::OnLButtonUp(nFlags, point);
}

void CDirect3D::OnMouseMove(UINT nFlags, CPoint point) 
{
	MouseEvent3D(nFlags, point);

	CWnd::OnMouseMove(nFlags, point);
}


void CDirect3D::MouseEvent3D(UINT nFlags, CPoint point)
{
	if (nFlags == MK_LBUTTON)
	{
		myglobs.mouse_buttons = nFlags;
		myglobs.mouse_x = point.x;
		myglobs.mouse_y = point.y;
	
		RenderLoop();
	}
}


void CDirect3D::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	MessageBeep(-1);	
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

#if !defined(AFX_DIRECT3D_H__48B891AB_C5DF_11D2_A5EA_000021E2BB14__INCLUDED_)
#define AFX_DIRECT3D_H__48B891AB_C5DF_11D2_A5EA_000021E2BB14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Direct3D.h : header file
//
#include <d3drmwin.h>
#include <d3drm.h>
//#include "rmerror.h"

#undef RELEASE
#ifdef __cplusplus
#define RELEASE(x) if (x != NULL) {x->Release(); x = NULL;}
#else
#define RELEASE(x) if (x != NULL) {x->lpVtbl->Release(x); x = NULL;}
#endif

#define MAX_DRIVERS 5           /* maximum D3D drivers we ever expect to find */

struct MyDirect3D {
    LPDIRECT3DRMDEVICE2 dev;     /* Direct3DRM device */
    LPDIRECT3DRMVIEWPORT view;  /* Direct3DRM viewport through which we view
                                   the scene */
    LPDIRECT3DRMFRAME2 scene;    /* Master frame in which others are placed */
    LPDIRECT3DRMFRAME2 camera;   /* Frame describing the users POV */

    GUID DriverGUID[MAX_DRIVERS];     /* GUIDs of the available D3D drivers */
    char DriverName[MAX_DRIVERS][50]; /* names of the available D3D drivers */
    int  NumDrivers;                  /* number of available D3D drivers */
    int  CurrDriver;                  /* number of D3D driver currently
                                         being used */

    D3DRMRENDERQUALITY RenderQuality;   /* current shade mode, fill mode and
                                           lighting state */
    D3DRMTEXTUREQUALITY TextureQuality; /* current texture interpolation */
    BOOL bDithering;                    /* is dithering on? */
    BOOL bAntialiasing;                 /* is antialiasing on? */

    BOOL bQuit;                 /* program is about to terminate */
    BOOL bInitialized;          /* all D3DRM objects have been initialized */
    BOOL bMinimized;            /* window is minimized */
    BOOL bSingleStepMode;       /* render one frame at a time */
    BOOL bDrawAFrame;           /* render on this pass of the main loop */
    BOOL bNoTextures;           /* this sample doesn't use any textures */
    BOOL bConstRenderQuality;   /* this sample is not constructed with
                                   MeshBuilders and so the RenderQuality
                                   cannot be changed */

    int BPP;                    /* bit depth of the current display mode */

    int mouse_buttons;          /* mouse button state */
    int mouse_x;                /* mouse cursor x position */
    int mouse_y;                /* mouse cursor y position */
};

typedef struct Defaultstag {
	BOOL bNoTextures;
	BOOL bResizingDisabled;
	BOOL bConstRenderQuality;
	char Name[50];
} Defaults;

/////////////////////////////////////////////////////////////////////////////
// CDirect3D window


class CDirect3D : public CWnd
{
// Construction
public:
	CDirect3D();
	BOOL Create(CRect rect, CWnd* pWnd, UINT nID = 666);

// Attributes
public:
	// names should be m_..... after succeed
	static MyDirect3D myglobs;
	static LPDIRECT3DRM2 lpD3DRM;           /* Direct3DRM object */
	static LPDIRECTDRAWCLIPPER lpDDClipper;/* DirectDrawClipper object */
	
	static int view_width;
	static int view_height;
	//static int dev_width;
	//static int dev_height;

// Functions
public:
	HWND InitDirect3D(HINSTANCE, int);
	void DelDirect3D(void);
	void InitGlobals(void);
	HRESULT CreateDevAndView(LPDIRECTDRAWCLIPPER lpDDClipper, int driver, int width, int height);
	BOOL RenderLoop(void);
	HRESULT SetRenderState(void);
	BOOL EnumDevices(HWND win);
	static void ReadMouse(int* b, int* x, int* y);
	
	// callbacks
	static void UserControl(LPDIRECT3DRMFRAME frame, void* arg, D3DVALUE delta);
	static HRESULT WINAPI enumDeviceFunc(LPGUID lpGuid, LPSTR lpDeviceDescription, LPSTR lpDeviceName,
        LPD3DDEVICEDESC lpHWDesc, LPD3DDEVICEDESC lpHELDesc, LPVOID lpContext);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDirect3D)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDirect3D();

	// Generated message map functions
public:
	
	// should be virtual after succeed
	BOOL UpdateAllFrames();
	void OverrideDefaults(Defaults* defaults);
	BOOL BuildScene(LPDIRECT3DRMDEVICE2 dev, LPDIRECT3DRMVIEWPORT view,
		LPDIRECT3DRMFRAME2 scene, LPDIRECT3DRMFRAME2 camera);
	virtual BOOL AddMoreFrames(LPDIRECT3DRMDEVICE2 dev, LPDIRECT3DRMVIEWPORT view,
		LPDIRECT3DRMFRAME2 scene, LPDIRECT3DRMFRAME2 camera);
	virtual void  MouseEvent3D(UINT nFlags, CPoint point = NULL);
	
	//{{AFX_MSG(CDirect3D)
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIRECT3D_H__48B891AB_C5DF_11D2_A5EA_000021E2BB14__INCLUDED_)

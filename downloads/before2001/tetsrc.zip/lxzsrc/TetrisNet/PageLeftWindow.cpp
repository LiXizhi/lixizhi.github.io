// PageLeftWindow.cpp : implementation file
//

#include "stdafx.h"
#include "tetris.h"
#include "PageLeftWindow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageLeftWindow property page

IMPLEMENT_DYNCREATE(CPageLeftWindow, CPropertyPage)

CPageLeftWindow::CPageLeftWindow() : CPropertyPage(CPageLeftWindow::IDD)
{
	//{{AFX_DATA_INIT(CPageLeftWindow)
	m_nLeftName = -1;
	//}}AFX_DATA_INIT
}

CPageLeftWindow::~CPageLeftWindow()
{
}

void CPageLeftWindow::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageLeftWindow)
	DDX_Control(pDX, IDC_KEY_ROTATE_LEFT, m_hkcLeftRotate);
	DDX_Control(pDX, IDC_KEY_RIGHT_LEFT, m_hkcLeftRight);
	DDX_Control(pDX, IDC_KEY_LEFT_LEFT, m_hkcLeftLeft);
	DDX_Control(pDX, IDC_KEY_DOWN_LEFT, m_hkcLeftDown);
	DDX_CBIndex(pDX, ID_LEFTNAMEWND, m_nLeftName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageLeftWindow, CPropertyPage)
	//{{AFX_MSG_MAP(CPageLeftWindow)
	ON_BN_CLICKED(IDC_RESETKEYS_LEFT, OnResetkeysLeft)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageLeftWindow message handlers

void CPageLeftWindow::OnResetkeysLeft() 
{
	m_hkcLeftRotate.SetHotKey('U', HOTKEYF_EXT);
	m_hkcLeftRight.SetHotKey('I', HOTKEYF_EXT);
	m_hkcLeftLeft.SetHotKey('Y', HOTKEYF_EXT);
	m_hkcLeftDown.SetHotKey(' ', HOTKEYF_EXT);
}

BOOL CPageLeftWindow::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	GetParent()->SetFont(GetFont());

	CComboBox* pcbLeftName = (CComboBox*)(GetDlgItem(ID_LEFTNAMEWND));
	CString str;
	str.LoadString(IDS_COMPUTERNAME);
	pcbLeftName->AddString(str);
	
	str.LoadString(IDS_HUMANNAME);
	pcbLeftName->AddString(str);
	
	m_hkcLeftRotate.SetRules(HKCOMB_NONE, HOTKEYF_EXT);
	m_hkcLeftRight.SetRules(HKCOMB_NONE, HOTKEYF_EXT);
	m_hkcLeftLeft.SetRules(HKCOMB_NONE, HOTKEYF_EXT);
	m_hkcLeftDown.SetRules(HKCOMB_NONE, HOTKEYF_EXT);
	
	m_hkcLeftRotate.SetHotKey(m_keys.rotate, HOTKEYF_EXT);
	m_hkcLeftRight.SetHotKey(m_keys.right, HOTKEYF_EXT);
	m_hkcLeftLeft.SetHotKey(m_keys.left, HOTKEYF_EXT);
	m_hkcLeftDown.SetHotKey(m_keys.down, HOTKEYF_EXT);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPageLeftWindow::OnOK() 
{
	WORD wModifiers;
	m_hkcLeftRotate.GetHotKey((WORD&)m_keys.rotate, wModifiers);
	m_hkcLeftRight.GetHotKey((WORD&)m_keys.right, wModifiers);
	m_hkcLeftLeft.GetHotKey((WORD&)m_keys.left, wModifiers);
	m_hkcLeftDown.GetHotKey((WORD&)m_keys.down, wModifiers);

	CPropertyPage::OnOK();
}

#define EDITTETRISHEIGHT 14
#define EDITTETRISWIDTH 14

enum EDITTETRIS {etEnd, etNull, et0, et1, et2, et3, et4, et5, et6};
	
/////////////////////////////////////////////////////////////////////////////
// COwnerBtn window

class COwnerBtn : public CButton
{
// Construction
public:
	COwnerBtn();

// Attributes
public:
	int m_etCurrectTetris;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COwnerBtn)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~COwnerBtn();

	// Generated message map functions
protected:
	//{{AFX_MSG(COwnerBtn)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// EditMap.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEditMap dialog

class CTetrisDoc;
class CTetrisWnd;
class CEditMap : public CDialog
{
// Construction
public:
	CTetrisDoc* m_pDoc;
	CTetrisWnd* m_pLeftWnd;
	CTetrisWnd* m_pRightWnd;
	CEditMap(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEditMap)
	enum { IDD = IDD_EDITMAP };
	COwnerBtn	m_btnTetrisType;
	int		m_nEditWndType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditMap)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditMap)
	afx_msg void OnClearAll();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

// PageEachWindow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPageEachWindow dialog

class CPageEachWindow : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageEachWindow)

// Construction
public:
	CPageEachWindow();
	~CPageEachWindow();
	
	int m_nTotalRow;
	int m_nTotalCol;

// Dialog Data
	//{{AFX_DATA(CPageEachWindow)
	enum { IDD = IDD_PAGE_EACHWND };
	CSpinButtonCtrl	m_spinWidth;
	CSpinButtonCtrl	m_spinHeight;
	BOOL	m_bWarMode;
	BOOL	m_bOnSound;
	int		m_nComputerSpeed;
	int		m_nHumanSpeed;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageEachWindow)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPageEachWindow)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

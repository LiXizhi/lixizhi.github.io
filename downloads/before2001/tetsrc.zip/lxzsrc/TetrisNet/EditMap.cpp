// EditMap.cpp : implementation file
//

#include "stdafx.h"
#include "tetris.h"
#include "EditMap.h"

#include "tetrisDoc.h"
#include "tetrisView.h"
#include "tetwnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditMap dialog


CEditMap::CEditMap(CWnd* pParent /*=NULL*/)
	: CDialog(CEditMap::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditMap)
	m_nEditWndType = -1;
	//}}AFX_DATA_INIT
}


void CEditMap::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditMap)
	DDX_Control(pDX, ID_TETRISTYPE, m_btnTetrisType);
	DDX_CBIndex(pDX, ID_EDITWNDTYPE, m_nEditWndType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditMap, CDialog)
	//{{AFX_MSG_MAP(CEditMap)
	ON_BN_CLICKED(IDC_CLEARALL, OnClearAll)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditMap message handlers

void CEditMap::OnClearAll() 
{
	UpdateData(TRUE);
	CTetrisWnd* pEditWnd = (m_nEditWndType == 0) ? m_pLeftWnd : m_pRightWnd;
	memset(pEditWnd->m_map, tsNull, sizeof(pEditWnd->m_map));
	
	pEditWnd->InvalidateRect(NULL);
	pEditWnd->UpdateWindow();
}

void CEditMap::OnOK() 
{
	m_pDoc->SetModifiedFlag();
	UpdateData(TRUE);
	memcpy(m_pLeftWnd->m_DocMap, m_pLeftWnd->m_map, sizeof(m_pLeftWnd->m_map));
	memcpy(m_pRightWnd->m_DocMap, m_pRightWnd->m_map, sizeof(m_pRightWnd->m_map));
	m_pLeftWnd->UpDateMap();
	m_pRightWnd->UpDateMap();
	CDialog::OnOK();
}

void CEditMap::OnCancel() 
{
	m_pLeftWnd->UpDateMap();
	m_pRightWnd->UpDateMap();
	
	CDialog::OnCancel();
}

BOOL CEditMap::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_pLeftWnd->UpDateMap();
	m_pRightWnd->UpDateMap();

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEditMap::OnLButtonDown(UINT nFlags, CPoint point) 
{
	
}

/////////////////////////////////////////////////////////////////////////////
// COwnerBtn

COwnerBtn::COwnerBtn()
{
	m_etCurrectTetris = -1;
}

COwnerBtn::~COwnerBtn()
{
}


BEGIN_MESSAGE_MAP(COwnerBtn, CButton)
	//{{AFX_MSG_MAP(COwnerBtn)
	ON_WM_LBUTTONDOWN()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COwnerBtn message handlers

void COwnerBtn::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	ASSERT(pDC != NULL);
	
	CDC dcMem;
	dcMem.CreateCompatibleDC(pDC);
	CBitmap bmpBand;
	bmpBand.LoadBitmap(IDB_EDIT_BAND);
	CBitmap* pOldBmp = dcMem.SelectObject(&bmpBand);

	if(m_etCurrectTetris != -1)
	{
		CRect rect;
		rect.left = EDITTETRISWIDTH*m_etCurrectTetris;
		rect.top = 0;
		rect.right = rect.left + EDITTETRISWIDTH;
		rect.bottom = rect.top + EDITTETRISHEIGHT;
		CBrush br(RGB(192, 192, 192));
		dcMem.FillRect(rect, &br);
	}

	CRect rectBand;
	GetClientRect(&rectBand);
	pDC->BitBlt(0, 0, rectBand.Width(), rectBand.Height(), &dcMem, 0, 0, SRCCOPY);

	dcMem.SelectObject(pOldBmp);
}

int COwnerBtn::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CButton::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// allow me as large as my bitbmp
	/*
	BITMAP bmp;
	bmpBand.GetObject(0, &bmp);
	CRect rectMe;
	GetWindowRect(&rectMe);
	rectMe.right = bmp.bmWidth;
	rectMe.bottom = bmp.bmHeight;
	MoveWindow(rectMe);
	*/
	
	return 0;
}

void COwnerBtn::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CEditMap* pWnd = ((CEditMap*)GetParent());
	pWnd->UpdateData(TRUE);
	CTetrisWnd* pEditWnd = (pWnd->m_nEditWndType == 0) ?
		pWnd->m_pLeftWnd : pWnd->m_pRightWnd;

	// set capture to the window which received this message
	SetCapture();
	ASSERT(CWnd::GetCapture());

	struct LASTMOVE
	{
		int LastTetris;
		int x;
		int y;
	} LastTime;
	
	LastTime.LastTetris = -1;
	LastTime.x = -1;
	LastTime.y = -1;

	// WM_LBUTTONDOWN
	m_etCurrectTetris = point.x / EDITTETRISWIDTH;
	InvalidateRect(NULL);
	UpdateWindow();

	// get messages until capture lost or cancelled/accepted
	BOOL bExitLoop = FALSE;
	while(!bExitLoop)
	{
		MSG msg;
		VERIFY(::GetMessage(&msg, NULL, 0, 0));

		switch (msg.message)
		{
		// handle movement/accept messages
		case WM_MOUSEMOVE:
			{
				CPoint point((int)(short)LOWORD(msg.lParam), (int)(short)HIWORD(msg.lParam));
				ClientToScreen(&point);
				pEditWnd->ScreenToClient(&point);
				CRect rect;
				pEditWnd->GetClientRect(&rect);
				if ( !(rect.PtInRect(point)))
					break;
				point.x = int(point.x/BOXWIDTH); // col
				point.y = int(point.y/BOXHEIGHT); // row
				if (LastTime.LastTetris != -1)
				{
					if ((point.x == LastTime.x) && (point.y == LastTime.y))
						break;
					pEditWnd->m_map[LastTime.y][LastTime.x] = LastTime.LastTetris;
				}
				rect.left = LastTime.x * BOXWIDTH;
				rect.top = LastTime.y * BOXHEIGHT;
				rect.right = rect.left + BOXWIDTH;
				rect.bottom = rect.top + BOXHEIGHT;
				pEditWnd->InvalidateRect(&rect);

				LastTime.LastTetris = pEditWnd->m_map[point.y][point.x];
				LastTime.x = point.x;
				LastTime.y = point.y;
				
				BYTE ts = tsNull;
				switch (m_etCurrectTetris)
				{
					//enum EDITTETRIS {etEnd, etNull, et0, et1, et2, et3, et4, et5, et6};
					//enum TETRISSHAPE {ts0, ts1, ts2, ts3, ts4, ts5, ts6, tsEnd, tsNull};
				case etEnd:
					ts = tsEnd;
					break;
				case etNull:
					ts = tsNull;
					break;
				default:
					ts = m_etCurrectTetris - et0;
					break;
				}
				pEditWnd->m_map[point.y][point.x] = ts;
				
				rect.left = point.x * BOXWIDTH;
				rect.top = point.y * BOXHEIGHT;
				rect.right = rect.left + BOXWIDTH;
				rect.bottom = rect.top + BOXHEIGHT;
				pEditWnd->InvalidateRect(&rect);
				pEditWnd->UpdateWindow();
				break;
			}
		case WM_LBUTTONUP:
			{
				m_etCurrectTetris = -1;
				InvalidateRect(NULL);
				UpdateWindow();
				bExitLoop = TRUE;
				break;
			}
		// handle cancel messages
		case WM_KEYDOWN:
			if (msg.wParam != VK_ESCAPE)
				break;
		// just dispatch rest of the messages
		default:
			DispatchMessage(&msg);
			break;
		}
	}
	ReleaseCapture();
}

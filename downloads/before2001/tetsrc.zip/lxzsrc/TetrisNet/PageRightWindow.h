// PageRightWindow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPageRightWindow dialog

class CPageRightWindow : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageRightWindow)

// Construction
public:
	CPageRightWindow();
	~CPageRightWindow();

	KEYRESULT m_keys;

// Dialog Data
	//{{AFX_DATA(CPageRightWindow)
	enum { IDD = IDD_PAGE_RIGHTWND };
	CHotKeyCtrl	m_hkcRightRotate;
	CHotKeyCtrl	m_hkcRightRight;
	CHotKeyCtrl	m_hkcRightLeft;
	CHotKeyCtrl	m_hkcRightDown;
	int		m_nRightName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageRightWindow)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPageRightWindow)
	afx_msg void OnResetkeysRight();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

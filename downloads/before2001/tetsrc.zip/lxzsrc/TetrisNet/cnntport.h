#ifdef _DLL
	#define CLASS_DECLSPEC    __declspec(dllexport)
#else
	#define CLASS_DECLSPEC    __declspec(dllimport)
#endif

// the struct used to transfer things
typedef struct {
	DWORD	name;	// the name of the message to be transfered
	int		len; // size ofthe package not including name and len. only the size of the date of the pointer below
	char*	buf; // the pointer to the data(package)
} PACKAGE, *LPPACKAGE;

// Deal this system message to display string like, xxx has joined, *** has left, etc.
const UINT SYSTEM_MESSAGE = 100;
const UINT CHAT_MESSAGE = 101;

CLASS_DECLSPEC int FirstStartCom(HWND hWnd, int (*)(LPPACKAGE));
CLASS_DECLSPEC int FirstStartCom(CWnd* pWnd, int (*)(LPPACKAGE));
CLASS_DECLSPEC void LastEndCom();
CLASS_DECLSPEC void SendPackage(LPPACKAGE pkg, BOOL bGuaranteed = FALSE);

// Chat dlg functions
CLASS_DECLSPEC void CreateChat(CWnd * pWnd);
CLASS_DECLSPEC void DestroyChat();
CLASS_DECLSPEC void ShowChatWnd(int nCmdShow);

// Change the proc where to send a messsage when a package is received
CLASS_DECLSPEC void SetProcAddress(int (*)(LPPACKAGE));
// launch the Chat Dlg
CLASS_DECLSPEC int RunChatDlg();

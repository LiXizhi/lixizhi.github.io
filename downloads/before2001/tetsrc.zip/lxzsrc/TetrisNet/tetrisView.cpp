// tetrisView.cpp : implementation of the CTetrisView class
//

#include "stdafx.h"
#include "tetris.h"

#include "MainFrm.h"
#include "tetrisDoc.h"
#include "tetrisView.h"

#include "tetwnd.h"
#include "nextbloc.h"
#include "warmode.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTetrisView
int CTetrisWnd::nTotalRow;
int CTetrisWnd::nTotalCol;
BOOL CTetrisWnd::m_bWarMode;
int CTetrisWnd::m_nPreviousScore;
int CTetrisView::m_nHumanSpeed;
int CTetrisView::m_nComputerSpeed;

IMPLEMENT_DYNCREATE(CTetrisView, CView)

BEGIN_MESSAGE_MAP(CTetrisView, CView)
	//{{AFX_MSG_MAP(CTetrisView)
	ON_MESSAGE(WM_DIRECTION, OnDirection)
	ON_WM_CREATE()
	ON_WM_KEYDOWN()
	ON_CBN_SELCHANGE(ID_LEFTNAMEWND, OnLeftNameSelChange)
	ON_CBN_SELCHANGE(ID_RIGHTNAMEWND, OnRightNameSelChange)
	ON_COMMAND(ID_WARMODE, OnWarmode)
	ON_UPDATE_COMMAND_UI(ID_WARMODE, OnUpdateWarmode)
	ON_WM_DESTROY()
	ON_CBN_SELENDCANCEL(ID_LEFTNAMEWND, OnLeftNameSelChange)
	ON_CBN_SELENDCANCEL(ID_RIGHTNAMEWND, OnRightNameSelChange)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTetrisView construction/destruction

CTetrisView::CTetrisView()
{
	//{{AFX_DATA_INIT(CTetrisView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	
	m_pWarModeWnd = new CWarMode;

	m_pLeftTetrisWnd = new CTetrisWnd;
	m_pLeftTetrisWnd->m_keys.left = 'Y';
	m_pLeftTetrisWnd->m_keys.right = 'I';
	m_pLeftTetrisWnd->m_keys.rotate = 'U';
	m_pLeftTetrisWnd->m_keys.down = ' ';
	
	m_pRightTetrisWnd = new CTetrisWnd;
	m_pRightTetrisWnd->m_keys.left = VK_HOME;
	m_pRightTetrisWnd->m_keys.right = VK_PRIOR;	
	m_pRightTetrisWnd->m_keys.rotate = VK_UP;
	m_pRightTetrisWnd->m_keys.down = VK_INSERT;

	m_nHumanSpeed = 1;
	m_nComputerSpeed = 1;
	m_bIsConnected = FALSE;

	Initial();
}

CTetrisView::~CTetrisView()
{
	Terminal();
	delete m_pWarModeWnd;
	delete m_pLeftTetrisWnd;
	delete m_pRightTetrisWnd;
}

void CTetrisView::Initial()
{
	m_pLeftTetrisWnd->m_keys.left = AfxGetApp()->GetProfileInt("LeftWindow", "Left", 'Y');
	m_pLeftTetrisWnd->m_keys.right = AfxGetApp()->GetProfileInt("LeftWindow", "Right", 'I');
	m_pLeftTetrisWnd->m_keys.rotate = AfxGetApp()->GetProfileInt("LeftWindow", "Rotate", 'U');
	m_pLeftTetrisWnd->m_keys.down = AfxGetApp()->GetProfileInt("LeftWindow", "Down", ' ');
	m_pLeftTetrisWnd->m_nPlayer = AfxGetApp()->GetProfileInt("LeftWindow", "Player", 0);
	
	m_pRightTetrisWnd->m_keys.left = AfxGetApp()->GetProfileInt("RightWindow", "Left", VK_HOME);
	m_pRightTetrisWnd->m_keys.right = AfxGetApp()->GetProfileInt("RightWindow", "Right", VK_PRIOR);
	m_pRightTetrisWnd->m_keys.rotate = AfxGetApp()->GetProfileInt("RightWindow", "Rotate", VK_UP);
	m_pRightTetrisWnd->m_keys.down = AfxGetApp()->GetProfileInt("RightWindow", "Down", VK_INSERT);
	m_pRightTetrisWnd->m_nPlayer = AfxGetApp()->GetProfileInt("RightWindow", "Player", 1);
	
	m_nHumanSpeed = AfxGetApp()->GetProfileInt("General", "HumanSpeed", 1);
	m_nComputerSpeed = AfxGetApp()->GetProfileInt("General", "ComputerSpeed", 1);
	CTetrisWnd::m_bWarMode = AfxGetApp()->GetProfileInt("General", "WarMode", TRUE);
	CTetrisWnd::nTotalRow = AfxGetApp()->GetProfileInt("General", "TotalRow", 20);
	CTetrisWnd::nTotalCol = AfxGetApp()->GetProfileInt("General", "TotalCol", 10);
}

void CTetrisView::Terminal()
{
	AfxGetApp()->WriteProfileInt("LeftWindow", "Left", m_pLeftTetrisWnd->m_keys.left);
	AfxGetApp()->WriteProfileInt("LeftWindow", "Right", m_pLeftTetrisWnd->m_keys.right);
	AfxGetApp()->WriteProfileInt("LeftWindow", "Rotate", m_pLeftTetrisWnd->m_keys.rotate);
	AfxGetApp()->WriteProfileInt("LeftWindow", "Down", m_pLeftTetrisWnd->m_keys.down);
	AfxGetApp()->WriteProfileInt("LeftWindow", "Player", m_pLeftTetrisWnd->m_nPlayer);

	AfxGetApp()->WriteProfileInt("RightWindow", "Left", m_pRightTetrisWnd->m_keys.left);
	AfxGetApp()->WriteProfileInt("RightWindow", "Right", m_pRightTetrisWnd->m_keys.right);
	AfxGetApp()->WriteProfileInt("RightWindow", "Rotate", m_pRightTetrisWnd->m_keys.rotate);
	AfxGetApp()->WriteProfileInt("RightWindow", "Down", m_pRightTetrisWnd->m_keys.down);
	AfxGetApp()->WriteProfileInt("RightWindow", "Player", m_pRightTetrisWnd->m_nPlayer);

	AfxGetApp()->WriteProfileInt("General", "HumanSpeed", m_nHumanSpeed);
	AfxGetApp()->WriteProfileInt("General", "ComputerSpeed", m_nComputerSpeed);
	AfxGetApp()->WriteProfileInt("General", "WarMode", CTetrisWnd::m_bWarMode);
	AfxGetApp()->WriteProfileInt("General", "TotalRow", CTetrisWnd::nTotalRow);
	AfxGetApp()->WriteProfileInt("General", "TotalCol", CTetrisWnd::nTotalCol);
}

void CTetrisView::DoDataExchange(CDataExchange* pDX)
{
	CView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTetrisView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CTetrisView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTetrisView printing

BOOL CTetrisView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTetrisView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTetrisView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CTetrisView::OnPrint(CDC* pDC, CPrintInfo*)
{
	// TODO: add code to print the controls
}

/////////////////////////////////////////////////////////////////////////////
// CTetrisView diagnostics

#ifdef _DEBUG
void CTetrisView::AssertValid() const
{
	CView::AssertValid();
}

void CTetrisView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTetrisDoc* CTetrisView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTetrisDoc)));
	return (CTetrisDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTetrisView message handlers

LONG CTetrisView::OnDirection(WPARAM wParam, LPARAM)
{
	switch(wParam)
	{
		case DIR_WARMODE: m_pWarModeWnd->InvalidateMode(); break;
		case DIR_LEFT: m_pWarModeWnd->LeftPoint(); break;
		case DIR_RIGHT: m_pWarModeWnd->RightPoint(); break;
		default:
			ASSERT(FALSE);
	}

	return TRUE;
}

void CTetrisView::DrawTetrisFrame(CDC* pDC, CTetrisWnd* pTetrisWnd)
{
	CRect rectSmall, rectBig;
	pTetrisWnd->GetWindowRect(&rectSmall);
	ScreenToClient(&rectSmall);
	rectSmall.left--;
	rectSmall.top--;

	int entrancex = (rectSmall.Width() - TETFRAME_ENTRANCE) / 2 + rectSmall.left;

	CPen penHilight(PS_SOLID, 0, GetSysColor(COLOR_BTNHIGHLIGHT));
	CPen penShadow(PS_SOLID, 0, GetSysColor(COLOR_BTNSHADOW));
	CPen penBorder(PS_SOLID, 0, GetSysColor(COLOR_WINDOWFRAME));

	CBrush brFace(GetSysColor(COLOR_BTNFACE));
	CBrush* pOldBrush = pDC->SelectObject(&brFace);

	CPen* pOldPen = pDC->SelectObject(&penBorder);

	rectBig = rectSmall;
	rectBig.InflateRect(TETFRAME_WIDTH, TETFRAME_HEIGHT);

	POINT ptArray[] =
	{
		{entrancex, rectBig.top},
		{rectBig.left, rectBig.top},
		{rectBig.left, rectBig.bottom},
		{rectBig.right, rectBig.bottom},
		{rectBig.right, rectBig.top},
		{entrancex+TETFRAME_ENTRANCE, rectBig.top},
		{entrancex+TETFRAME_ENTRANCE, rectSmall.top},
		{rectSmall.right, rectSmall.top},
		{rectSmall.right, rectSmall.bottom},
		{rectSmall.left, rectSmall.bottom},
		{rectSmall.left, rectSmall.top},
		{entrancex, rectSmall.top},
		{entrancex, rectBig.top}
	};
	pDC->Polygon(ptArray, sizeof(ptArray) / sizeof(POINT));

	for(int i=1; i<TETFRAME_SHADOW+1; i++)
	{
		POINT ptHighlight0[] = 
		{
			{entrancex-i, rectBig.top+i},
			{rectBig.left+i, rectBig.top+i},
			{rectBig.left+i, rectBig.bottom-i},
		};
	
		POINT ptHighlight1[] = 
		{
			{rectSmall.left-i, rectSmall.bottom+i},
			{rectSmall.right+i, rectSmall.bottom+i},
			{rectSmall.right+i, rectSmall.top-i},
		};

		POINT ptHighlight2[] = 
		{
			{entrancex+TETFRAME_ENTRANCE+i, rectSmall.top-i},
			{entrancex+TETFRAME_ENTRANCE+i, rectBig.top+i},
			{rectBig.right-i, rectBig.top+i},
		};
	
		pDC->SelectObject(&penHilight);
		pDC->Polyline(ptHighlight0, sizeof(ptHighlight0) / sizeof(POINT));
		pDC->Polyline(ptHighlight1, sizeof(ptHighlight1) / sizeof(POINT));
		pDC->Polyline(ptHighlight2, sizeof(ptHighlight2) / sizeof(POINT));

		POINT ptShadow0[] = 
		{
			{entrancex-i, rectBig.top+i},
			{entrancex-i, rectSmall.top-i},
			{rectSmall.left-i, rectSmall.top-i},
			{rectSmall.left-i, rectSmall.bottom+i},
		};
	
		POINT ptShadow1[] = 
		{
			{rectBig.left+i, rectBig.bottom-i},
			{rectBig.right-i, rectBig.bottom-i},
			{rectBig.right-i, rectBig.top+i},
		};

		POINT ptShadow2[] = 
		{
			{entrancex+TETFRAME_ENTRANCE+i, rectSmall.top-i},
			{rectSmall.right+i, rectSmall.top-i},
		};
	
		pDC->SelectObject(&penShadow);
		pDC->Polyline(ptShadow0, sizeof(ptShadow0) / sizeof(POINT));
		pDC->Polyline(ptShadow1, sizeof(ptShadow1) / sizeof(POINT));
		pDC->Polyline(ptShadow2, sizeof(ptShadow2) / sizeof(POINT));
	}
	
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);
} // DrawFrame

CRect CTetrisView::GetNameWindowRect(CTetrisWnd* pTetrisWnd)
{
	CRect rectSmall, rectBig;
	pTetrisWnd->GetWindowRect(&rectSmall);
	ScreenToClient(&rectSmall);
	rectSmall.left;
	rectSmall.top;
	int entrancex = (rectSmall.Width() - TETFRAME_ENTRANCE) / 2 + rectSmall.left;
	rectBig = rectSmall;
	rectBig.InflateRect(TETFRAME_WIDTH, TETFRAME_HEIGHT);
	rectBig.top--;
	
	CRect rect(entrancex, rectBig.top,
		entrancex+TETFRAME_ENTRANCE-1, rectBig.top+TETFRAME_HEIGHT);
	rect.bottom = rect.bottom*2;
	rect.left ++;
	return rect;
}

void CTetrisView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	UpdateMyNames();
}

int CTetrisView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create m_pLeftTetrisWnd
	m_pLeftTetrisWnd->Create(this, ((MAINWND_WIDTH - 2 * (WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10))/2), TETWND_TOP, ID_LEFTWND);

	// Create m_pRigshtTetrisWnd
	m_pRightTetrisWnd->Create(this, ((MAINWND_WIDTH - 2 * (WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10))/2)+
			2*(WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10)-(CTetrisWnd::nTotalCol)*BOXWIDTH, 
			TETWND_TOP, ID_RIGHTWND);
	// Create m_pWarModeWnd
	
	CRect rect;
	rect.left = ((MAINWND_WIDTH - 2 * (WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10))/2)+(CTetrisWnd::nTotalCol)*BOXWIDTH+TETFRAME_WIDTH;
	rect.top = TETWND_TOP+(CTetrisWnd::nTotalRow)*BOXHEIGHT-WARWND_HEIGHT-10;
	rect.right = rect.left+2*((WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10)-(CTetrisWnd::nTotalCol)*BOXWIDTH-TETFRAME_WIDTH);
	rect.bottom = rect.top+WARWND_HEIGHT;

    m_pWarModeWnd->Create(NULL, NULL, WS_CHILD | (CTetrisWnd::m_bWarMode ? WS_VISIBLE : 0),
		rect, this, 188);
	
	m_cbLeftName.Create(WS_CHILD|WS_VISIBLE|CBS_DROPDOWNLIST,
		GetNameWindowRect(m_pLeftTetrisWnd), this, ID_LEFTNAMEWND);
	m_cbRightName.Create(WS_CHILD|WS_VISIBLE|CBS_DROPDOWNLIST,
		GetNameWindowRect(m_pRightTetrisWnd), this, ID_RIGHTNAMEWND);
	
	CString str;
	str.LoadString(IDS_COMPUTERNAME);
	m_cbLeftName.AddString(str);
	m_cbRightName.AddString(str);

	str.LoadString(IDS_HUMANNAME);
	m_cbLeftName.AddString(str);
	m_cbRightName.AddString(str);

	CMainFrame::m_pMyView = this;
	ASSERT(CMainFrame::m_pMyView);
	
	return 0;
}

void CTetrisView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if( ((CMainFrame*)GetParentFrame())->m_bPause == FALSE )
	{
		if(m_pLeftTetrisWnd->IsMovementKey(nChar))
			return;
		m_pRightTetrisWnd->IsMovementKey(nChar);
	}
	
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL CTetrisView::IsBegin()
{
	return (m_pLeftTetrisWnd->m_bBegun || m_pRightTetrisWnd->m_bBegun);
}

void CTetrisView::EndAllTetrisWnd()
{
    if (m_pLeftTetrisWnd->m_bBegun && m_pRightTetrisWnd->m_bBegun)
	{
		if (m_pLeftTetrisWnd->m_lScore > m_pRightTetrisWnd->m_lScore)
		{
			m_pRightTetrisWnd->EndGame();
			m_pLeftTetrisWnd->EndGame();
		}
		else
		{
			m_pLeftTetrisWnd->EndGame();
			m_pRightTetrisWnd->EndGame();
		}
	}
	else
	{
		if(m_pLeftTetrisWnd->m_bBegun)
			m_pLeftTetrisWnd->EndGame();
		if(m_pRightTetrisWnd->m_bBegun)
			m_pRightTetrisWnd->EndGame();
	}
}

void CTetrisView::OnDraw(CDC* pDC) 
{
	CRect rect;
	GetClientRect(&rect);
	CBrush brush(RGB(192, 192, 192));
	pDC->FillRect(&rect, &brush);
	
	DrawTetrisFrame(pDC, m_pLeftTetrisWnd);
	DrawTetrisFrame(pDC, m_pRightTetrisWnd);
}

void CTetrisView::OnLeftNameSelChange()
{
	m_pLeftTetrisWnd->m_nPlayer = m_cbLeftName.GetCurSel();
	m_pLeftTetrisWnd->ClsTetris();
	m_pLeftTetrisWnd->GenerateNewBlock();
	SetFocus();
}

void CTetrisView::OnRightNameSelChange()
{
	m_pRightTetrisWnd->m_nPlayer = m_cbRightName.GetCurSel();
	m_pRightTetrisWnd->ClsTetris();
	m_pRightTetrisWnd->GenerateNewBlock();
	SetFocus();
}

void CTetrisView::UpdateMyNames()
{
   	m_cbLeftName.SetCurSel(m_pLeftTetrisWnd->m_nPlayer);
	m_cbRightName.SetCurSel(m_pRightTetrisWnd->m_nPlayer);
}

void CTetrisView::UpdateAllMyChildWndRect()
{
	// move the windows on he lefthand side
	int x, y;
	x = ((MAINWND_WIDTH - 2 * (WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10))/2);
	y = TETWND_TOP;
	CRect rect(x, y, x+(CTetrisWnd::nTotalCol)*BOXWIDTH, y+(CTetrisWnd::nTotalRow)*BOXHEIGHT);
	m_pLeftTetrisWnd->MoveWindow(rect);
	
	int scorex = rect.right+WIDTH_SCORESPACE;
	m_pLeftTetrisWnd->m_wndScore.MoveWindow(CRect(scorex, rect.top+TOP_SCORE, scorex+WIDTH_SCORE, rect.top+TOP_SCORE+HEIGHT_SCORE));
	
	CRect rectNextBlock;
	rectNextBlock.left = (rect.Width()-WIDTH_NEXTBLOCK)/2+rect.left;
	rectNextBlock.top = TOP_NEXTBLOCK;
	rectNextBlock.right = rectNextBlock.left + WIDTH_NEXTBLOCK;
	rectNextBlock.bottom = rectNextBlock.top + HEIGHT_NEXTBLOCK;
	m_pLeftTetrisWnd->m_pNextBlockWnd->MoveWindow(rectNextBlock);
		
	m_cbLeftName.MoveWindow(GetNameWindowRect(m_pLeftTetrisWnd));
	
	// move the windows on he righthand side
	x = ((MAINWND_WIDTH - 2 * (WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10))/2) + 2*(WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10)-(CTetrisWnd::nTotalCol)*BOXWIDTH;
	rect.SetRect(x, y, x+(CTetrisWnd::nTotalCol)*BOXWIDTH, y+(CTetrisWnd::nTotalRow)*BOXHEIGHT);
	m_pRightTetrisWnd->MoveWindow(rect);
	
	scorex = rect.left-WIDTH_SCORESPACE-WIDTH_SCORE;
	m_pRightTetrisWnd->m_wndScore.MoveWindow(CRect(scorex, rect.top+TOP_SCORE, scorex+WIDTH_SCORE, rect.top+TOP_SCORE+HEIGHT_SCORE));

	rectNextBlock.left = (rect.Width()-WIDTH_NEXTBLOCK)/2+rect.left;
	rectNextBlock.top = TOP_NEXTBLOCK;
	rectNextBlock.right = rectNextBlock.left + WIDTH_NEXTBLOCK;
	rectNextBlock.bottom = rectNextBlock.top + HEIGHT_NEXTBLOCK;
	m_pRightTetrisWnd->m_pNextBlockWnd->MoveWindow(rectNextBlock);

	m_cbRightName.MoveWindow(GetNameWindowRect(m_pRightTetrisWnd));
	
	// move the warmode window
	rect.left = ((MAINWND_WIDTH - 2 * (WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10))/2)+(CTetrisWnd::nTotalCol)*BOXWIDTH+TETFRAME_WIDTH;
	rect.top = TETWND_TOP+(CTetrisWnd::nTotalRow)*BOXHEIGHT-WARWND_HEIGHT-10;
	rect.right = rect.left+2*((WIDTH_SCORESPACE+WIDTH_SCORE+(CTetrisWnd::nTotalCol)*BOXWIDTH+10)-(CTetrisWnd::nTotalCol)*BOXWIDTH-TETFRAME_WIDTH);
	rect.bottom = rect.top+WARWND_HEIGHT;
    m_pWarModeWnd->MoveWindow(rect);

	InvalidateRect(NULL);
	UpdateWindow();
}

void CTetrisView::OnWarmode() 
{
	CTetrisWnd::m_bWarMode = !CTetrisWnd::m_bWarMode;
	m_pWarModeWnd->m_pcMode = CWarMode::WARMODE;
	if(CTetrisWnd::m_bWarMode)
		m_pWarModeWnd->ShowWindow(SW_SHOW);
	else
		m_pWarModeWnd->ShowWindow(SW_HIDE);
}

void CTetrisView::OnUpdateWarmode(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(CTetrisWnd::m_bWarMode);
}


void CTetrisView::SetNetWnd()
{
	
}

void CTetrisView::OnDestroy() 
{
	CView::OnDestroy();
}

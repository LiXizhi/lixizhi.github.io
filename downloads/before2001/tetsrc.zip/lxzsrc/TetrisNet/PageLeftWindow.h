// PageLeftWindow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPageLeftWindow dialog

class CPageLeftWindow : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageLeftWindow)

// Construction
public:
	CPageLeftWindow();
	~CPageLeftWindow();

	KEYRESULT m_keys;

// Dialog Data
	//{{AFX_DATA(CPageLeftWindow)
	enum { IDD = IDD_PAGE_LEFTWND };
	CHotKeyCtrl	m_hkcLeftRotate;
	CHotKeyCtrl	m_hkcLeftRight;
	CHotKeyCtrl	m_hkcLeftLeft;
	CHotKeyCtrl	m_hkcLeftDown;
	int		m_nLeftName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageLeftWindow)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPageLeftWindow)
	afx_msg void OnResetkeysLeft();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

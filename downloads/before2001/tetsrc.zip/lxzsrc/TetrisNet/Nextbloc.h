// nextbloc.h : header file
//
/////////////////////////////////////////////////////////////////////////////

extern BYTE enumRotateTetris[7][4][SHAPEROW][SHAPECOL];

class CNextBlockWnd : public CWnd
{
public:
	CNextBlockWnd();
    virtual ~CNextBlockWnd();
    
public:
	BYTE m_tetris[SHAPEROW][SHAPECOL];
	TETRISSHAPE m_ts;
	
	void GenerateNewBlock(BOOL bMission = TRUE);
	TETRISSHAPE GetTetris(BYTE tetris[SHAPEROW][SHAPECOL]);

protected:
	CBitmap m_bmpBand;
	BYTE m_DrawTetris[SHAPEROW][SHAPECOL];
	
	void DrawTetris();
	
protected:
	//{{AFX_MSG(CNextBlockWnd)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	
};

/////////////////////////////////////////////////////////////////////////////

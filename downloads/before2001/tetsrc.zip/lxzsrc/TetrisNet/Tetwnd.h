// tetwnd.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CTetrisWnd window

#define WIDTH_SCORESPACE	30
#define WIDTH_SCORE	70
#define HEIGHT_SCORE 180
#define TOP_SCORE	20

#define WIDTH_NEXTBLOCK		BOXWIDTH*4+1
#define HEIGHT_NEXTBLOCK	BOXHEIGHT*2+1
#define TOP_NEXTBLOCK	20

#define NETVIEWROW	20
#define NETVIEWCOL	10

#define NET_ADDROW  WM_USER+123

struct ADDROWNET
{
	int bUpdate;
	int row;
	BYTE biAddMap[5];
};

enum {ID_LEFTWND=1000, ID_RIGHTWND=1001};

// package define for remout
// {
// }

class CNextBlockWnd;

class CTetrisWnd : public CWnd
{
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CTetrisWnd();
public:
	virtual ~CTetrisWnd();
public:
	CNextBlockWnd* m_pNextBlockWnd;
	CStatic m_wndScore;
	
	// write or read them both in CTetrisView
	static int nTotalRow;	// write to *.INI
	static int nTotalCol;	// write to *.INI
	static BOOL m_bWarMode;	// write to *.INI
	int m_nPlayer;	// write to *.INI
	KEYRESULT m_keys;	// write to *.INI
	
	BOOL m_bBegun;
	BOOL m_bIsWin;
	long m_lScore;
	BOOL m_bGroup;
	int m_nWinCount;
	BOOL m_bWinShow;

	static int m_nPreviousScore;
	BYTE m_map[TOTALROW][TOTALCOL];
	BYTE m_DocMap[TOTALROW][TOTALCOL];
	ADDROWNET m_netAddRow;
	
public:
	void AddTetrisNet(int add, char * lpMap);
	void FitForNetView();
	void UpdateNetView(char* lpMap);
	BOOL m_bIsMeNetViewWnd;
	BOOL m_bIsMeNetWnd;
	void Create(CWnd* pParent, int x, int y, UINT nID);
	void DisplayScore();
	void UpDateMap();
	
	BOOL GenerateNewBlock();
	void BeginGame();
	void EndGame();
	void ClsTetris();
	void TellStop();
	BOOL IsMovementKey(UINT nChar);
	void AllAddTetris(int add, BYTE AddTetris[SHAPEROW][TOTALCOL]);
	
	void SetLoopSound(BOOL bRePeat = FALSE);
	CTetrisWnd* GetPartnerWnd();
	
	//{{AFX_MSG(CTetrisWnd)
	afx_msg void OnEditMe();
	//}}AFX_MSG
protected:
	afx_msg void OnContextMenu(CWnd*, CPoint point);
	struct COMMPUTERMETHOD
	{
		int m_nMaxNew;
		int m_nTimeNew;
		int m_nTetrisLeftNew;
		int m_nTetrisTopNew;
	};

	BYTE m_tetris[SHAPEROW][SHAPECOL];
    TETRISSHAPE m_ts;
	int m_nRotate;
	int m_nTetrisLeft;
	int m_nTetrisTop;
	
    CBitmap m_bmpBand;
    
	long m_lLines;
	int m_nLevel;
	
protected:
	void MoveRotate(BOOL draw = TRUE);
	BOOL MoveTetris(int row, int col, 
			BOOL bRedraw = TRUE, BOOL bNodraw = TRUE);

	BOOL AddRows(int add, BYTE AddTetris[SHAPEROW][TOTALCOL]);
	int ClearRows();
	void Direction();

	void OptimizePos();
	void ToCountBest(COMMPUTERMETHOD* CommputerMethod);

	void Connect();
	void StopTime();
	void EndTheGame();
	void DrawWinOrFail(CDC* pDC);
	
	//{{AFX_MSG(CTetrisWnd)
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnBeginMe();
	afx_msg void OnBeginMeNet();
	afx_msg void OnEndMe();
	//}}AFX_MSG
	afx_msg LRESULT OnNetAddrow(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
	

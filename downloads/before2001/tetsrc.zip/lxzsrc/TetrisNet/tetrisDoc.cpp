// tetrisDoc.cpp : implementation of the CTetrisDoc class
//

#include "stdafx.h"
#include "tetris.h"

#include "tetrisDoc.h"
#include "tetrisView.h"
#include "tetWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTetrisDoc

IMPLEMENT_DYNCREATE(CTetrisDoc, CDocument)

BEGIN_MESSAGE_MAP(CTetrisDoc, CDocument)
	//{{AFX_MSG_MAP(CTetrisDoc)
	ON_COMMAND(ID_MAP_EDITMAP, OnMapEditMap)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTetrisDoc construction/destruction

CTetrisDoc::CTetrisDoc()
{
}

CTetrisDoc::~CTetrisDoc()
{
}

BOOL CTetrisDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	POSITION pos = GetFirstViewPosition();
	CTetrisView* pView = (CTetrisView*)GetNextView( pos );

	pView->EndAllTetrisWnd();
	PlayRcSound(IDSOUND_CHECK, TRUE);

	memset(pView->m_pLeftTetrisWnd->m_DocMap, tsNull, sizeof(pView->m_pLeftTetrisWnd->m_DocMap));
	pView->m_pLeftTetrisWnd->UpDateMap();
	memset(pView->m_pRightTetrisWnd->m_DocMap, tsNull, sizeof(pView->m_pRightTetrisWnd->m_DocMap));
	pView->m_pRightTetrisWnd->UpDateMap();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTetrisDoc serialization

void CTetrisDoc::Serialize(CArchive& ar)
{
	POSITION pos = GetFirstViewPosition();
	CTetrisView* pView = (CTetrisView*)GetNextView( pos );

	if (ar.IsStoring())
	{
		ar<<CTetrisWnd::nTotalRow;
		ar<<CTetrisWnd::nTotalCol;

		for(int row=0; row<CTetrisWnd::nTotalRow; row++)
			for(int col=0; col<CTetrisWnd::nTotalCol; col++) 
				ar<<pView->m_pLeftTetrisWnd->m_DocMap[row][col];
		
		for(row=0; row<CTetrisWnd::nTotalRow; row++)
			for(int col=0; col<CTetrisWnd::nTotalCol; col++) 
				ar<<pView->m_pRightTetrisWnd->m_DocMap[row][col];
	}
	else
	{
		ar>>CTetrisWnd::nTotalRow;
		ar>>CTetrisWnd::nTotalCol;

		for(int row=0; row<CTetrisWnd::nTotalRow; row++)
			for(int col=0; col<CTetrisWnd::nTotalCol; col++) 
				ar>>pView->m_pLeftTetrisWnd->m_DocMap[row][col];
		
		for(row=0; row<CTetrisWnd::nTotalRow; row++)
			for(int col=0; col<CTetrisWnd::nTotalCol; col++) 
				ar>>pView->m_pRightTetrisWnd->m_DocMap[row][col];

	}
}

/////////////////////////////////////////////////////////////////////////////
// CTetrisDoc diagnostics

#ifdef _DEBUG
void CTetrisDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTetrisDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTetrisDoc commands

void CTetrisDoc::OnMapEditMap() 
{
	POSITION pos = GetFirstViewPosition();
	CTetrisView* pView = (CTetrisView*)GetNextView( pos );
	pView->m_pLeftTetrisWnd->OnEditMe();
}

BOOL CTetrisDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	POSITION pos = GetFirstViewPosition();
	CTetrisView* pView = (CTetrisView*)GetNextView( pos );

	pView->EndAllTetrisWnd();
	PlayRcSound(IDSOUND_CHECK, TRUE);

	pView->UpdateAllMyChildWndRect();
	pView->m_pLeftTetrisWnd->UpDateMap();
	pView->m_pRightTetrisWnd->UpDateMap();
	
	return TRUE;
}

// warmode.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWarMode window

class CWarMode : public CWnd
{
// Construction
public:
	CWarMode();

public:
	enum PRINTCONTENT {RIGHTPOINT, LEFTPOINT, WARMODE};
	PRINTCONTENT m_pcMode;
	
	void InvalidateMode();
	void RightPoint();
	void LeftPoint();

protected:	
	CBitmap m_bmpWarMode;
	CBitmap m_bmpRound;
	int m_nMoveTime;
	int m_nAllTime;
	
	void DrawMoveRect();
		
public:
	virtual ~CWarMode();

protected:
	// Generated message map functions
	//{{AFX_MSG(CWarMode)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

// PageRightWindow.cpp : implementation file
//

#include "stdafx.h"
#include "tetris.h"
#include "PageRightWindow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageRightWindow property page

IMPLEMENT_DYNCREATE(CPageRightWindow, CPropertyPage)

CPageRightWindow::CPageRightWindow() : CPropertyPage(CPageRightWindow::IDD)
{
	//{{AFX_DATA_INIT(CPageRightWindow)
	m_nRightName = -1;
	//}}AFX_DATA_INIT
}

CPageRightWindow::~CPageRightWindow()
{
}

void CPageRightWindow::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageRightWindow)
	DDX_Control(pDX, IDC_KEY_ROTATE_RIGHT, m_hkcRightRotate);
	DDX_Control(pDX, IDC_KEY_RIGHT_RIGHT, m_hkcRightRight);
	DDX_Control(pDX, IDC_KEY_LEFT_RIGHT, m_hkcRightLeft);
	DDX_Control(pDX, IDC_KEY_DOWN_RIGHT, m_hkcRightDown);
	DDX_CBIndex(pDX, ID_RIGHTNAMEWND, m_nRightName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageRightWindow, CPropertyPage)
	//{{AFX_MSG_MAP(CPageRightWindow)
	ON_BN_CLICKED(IDC_RESETKEYS_RIGHT, OnResetkeysRight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageRightWindow message handlers

void CPageRightWindow::OnResetkeysRight() 
{
	m_hkcRightRotate.SetHotKey(VK_UP, HOTKEYF_EXT);
	m_hkcRightRight.SetHotKey(VK_PRIOR, HOTKEYF_EXT);
	m_hkcRightLeft.SetHotKey(VK_HOME, HOTKEYF_EXT);
	m_hkcRightDown.SetHotKey(VK_INSERT, HOTKEYF_EXT);
}

BOOL CPageRightWindow::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CComboBox* pcbRightName = (CComboBox*)(GetDlgItem(ID_RIGHTNAMEWND));
	CString str;
	str.LoadString(IDS_COMPUTERNAME);
	pcbRightName->AddString(str);
	
	str.LoadString(IDS_HUMANNAME);
	pcbRightName->AddString(str);
	
	m_hkcRightRotate.SetRules(HKCOMB_NONE, HOTKEYF_EXT);
	m_hkcRightRight.SetRules(HKCOMB_NONE, HOTKEYF_EXT);
	m_hkcRightLeft.SetRules(HKCOMB_NONE, HOTKEYF_EXT);
	m_hkcRightDown.SetRules(HKCOMB_NONE, HOTKEYF_EXT);
	
	m_hkcRightRotate.SetHotKey(m_keys.rotate, HOTKEYF_EXT);
	m_hkcRightRight.SetHotKey(m_keys.right, HOTKEYF_EXT);
	m_hkcRightLeft.SetHotKey(m_keys.left, HOTKEYF_EXT);
	m_hkcRightDown.SetHotKey(m_keys.down, HOTKEYF_EXT);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPageRightWindow::OnOK() 
{
	WORD wModifiers;
	m_hkcRightRotate.GetHotKey((WORD&)m_keys.rotate, wModifiers);
	m_hkcRightRight.GetHotKey((WORD&)m_keys.right, wModifiers);
	m_hkcRightLeft.GetHotKey((WORD&)m_keys.left, wModifiers);
	m_hkcRightDown.GetHotKey((WORD&)m_keys.down, wModifiers);
	
	CPropertyPage::OnOK();
}

// tetwnd.cpp : implementation file
//

#include "stdafx.h"
#include "tetris.h"
#include "tetwnd.h"

#include "tetrisView.h"
#include "tetrisDoc.h"
#include "nextbloc.h"
#include "resource.h"
#include "EditMap.h"

#include "MainFrm.h" // cnntport.h included inside


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTetrisWnd

CTetrisWnd::CTetrisWnd()
{
	m_pNextBlockWnd = new CNextBlockWnd;
	
	// setup members
	memset(m_map, tsNull, sizeof(m_map));
	memset(m_DocMap, tsNull, sizeof(m_DocMap));
	memset(m_tetris, tsNull, sizeof(m_tetris));
    m_ts = ts0;
	nTotalRow = TOTALROW;
	nTotalCol = TOTALCOL;
	m_nTetrisLeft = 3;
	m_nTetrisTop = 0;
	m_nPreviousScore = 1;
	m_nPlayer = 1;
	m_bBegun = FALSE;
	m_nRotate = 0;
	
	// about Score
	m_lScore = 0;
	m_lLines = 0;
	m_nLevel = 0;
	m_nWinCount = 0;
	m_bIsWin = FALSE;
	m_bGroup = FALSE;
	m_bWinShow = FALSE;

	m_bIsMeNetWnd = FALSE;
	m_bIsMeNetViewWnd = FALSE;
	
	// about Pictures
	m_bmpBand.LoadBitmap(IDB_BAND);
}

CTetrisWnd::~CTetrisWnd()
{
	m_bmpBand.DeleteObject();
	delete m_pNextBlockWnd;
}

BEGIN_MESSAGE_MAP(CTetrisWnd, CWnd)
	ON_WM_CONTEXTMENU()
	//{{AFX_MSG_MAP(CTetrisWnd)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_COMMAND(ID_BEGIN_ME, OnBeginMe)
	ON_COMMAND(ID_END_ME, OnEndMe)
	ON_COMMAND(ID_EDIT_ME, OnEditMe)
	ON_COMMAND(ID_BEGIN_ME_NET, OnBeginMeNet)
	//}}AFX_MSG_MAP
	ON_MESSAGE(NET_ADDROW, OnNetAddrow)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Create and destroy message handlers

void CTetrisWnd::Create(CWnd* pParent, int x, int y, UINT nID)
{
	ASSERT( nID == ID_LEFTWND || nID == ID_RIGHTWND );

	// create the tetris window
	CRect rect(x, y, x+nTotalCol*BOXWIDTH, y+nTotalRow*BOXHEIGHT);
	VERIFY( CWnd::Create(NULL, NULL, WS_CHILD | WS_VISIBLE, rect, pParent, nID) );

	// create the score window
	int scorex = ( nID == ID_LEFTWND ? rect.right+WIDTH_SCORESPACE : rect.left-WIDTH_SCORESPACE-WIDTH_SCORE );
	m_wndScore.Create(NULL, WS_CHILD | WS_VISIBLE | SS_CENTER,
		CRect(scorex, rect.top+TOP_SCORE, scorex+WIDTH_SCORE, rect.top+TOP_SCORE+HEIGHT_SCORE), 
		pParent);
	
	// create the next block window
	CRect rectNextBlock;
	rectNextBlock.left = (rect.Width()-WIDTH_NEXTBLOCK)/2+rect.left;
	rectNextBlock.top = TOP_NEXTBLOCK;
	rectNextBlock.right = rectNextBlock.left + WIDTH_NEXTBLOCK;
	rectNextBlock.bottom = rectNextBlock.top + HEIGHT_NEXTBLOCK;
	m_pNextBlockWnd->Create(NULL, NULL, WS_CHILD | WS_VISIBLE,
		rectNextBlock, pParent, 0);

	DisplayScore();
}

void CTetrisWnd::OnDestroy()
{
	KillTimer(ID_TIMER);
	CWnd::OnDestroy();
}

void CTetrisWnd::DisplayScore()
{
	if( !m_wndScore.IsWindowVisible() )
		m_wndScore.ShowWindow(SW_SHOW);
	
	CString strFormat;
	strFormat.LoadString(IDP_SCORE);

	CString str;
	wsprintf(str.GetBuffer(100), strFormat, m_lScore, m_lLines, m_nLevel, m_nWinCount);

	m_wndScore.SetWindowText(str);
}

void CTetrisWnd::BeginGame()
{
	m_lScore = 0;
	m_lLines = 0;
	m_nLevel = 0;
	if (!m_bGroup)
		m_nWinCount = 0;
	DisplayScore();
	m_bGroup = TRUE;
	
	m_bWinShow = FALSE;
	m_bBegun = TRUE;
	
	SetLoopSound(TRUE);
	
	memcpy(m_map, m_DocMap, sizeof(m_map));
	memset(m_tetris, tsNull, sizeof(m_tetris));
    
    InvalidateRect(NULL);
	UpdateWindow();
	
	m_pNextBlockWnd->GenerateNewBlock();
	GenerateNewBlock();
	
	if (m_nPlayer == 0) // refer to computer
	{
		int speed = BASETIMER - (150*(((CTetrisView*)GetParent())->m_nHumanSpeed + ((CTetrisView*)GetParent())->m_nComputerSpeed));
		SetTimer(ID_TIMER, speed, NULL);
	}
	else if (m_nPlayer == 1) // refer to human
	{
		SetTimer(ID_TIMER, BASETIMER, NULL);
	}
}

void CTetrisWnd::EndGame()
{
	m_lScore = 0;
	Connect();
	memset(m_tetris, tsNull, sizeof(m_tetris));
	StopTime();
	m_bBegun = FALSE;
	
	KillTimer(ID_TIMER);
}

BOOL CTetrisWnd::GenerateNewBlock()
{
	if (m_bBegun == FALSE) return FALSE;
	m_ts = m_pNextBlockWnd->GetTetris(m_tetris);
				
	if (m_nPlayer == 1)
	{
		// PlayRcSound(IDSOUND_NEWBLOCK);
		BOOL nPass = FALSE;
		for (int nRow=0; nRow<SHAPEROW && nPass == FALSE; nRow++)
		{
			for (int nCol=0; nCol<SHAPECOL; nCol++)
			{
				if(m_tetris[nRow][nCol] != tsNull)
				{
					m_nTetrisLeft = 3;
					m_nTetrisTop = 1-nRow;
					nPass = TRUE;
				}
			}
		}
		m_pNextBlockWnd->GenerateNewBlock();
	}
	else if(m_nPlayer == 0)
	{
		m_nTetrisLeft = 3;
		m_nTetrisTop = 0;
					
		m_pNextBlockWnd->GenerateNewBlock(FALSE);
	}

	m_nRotate = 0;
	
	if(!MoveTetris(0,0))
	{
		EndTheGame();
		return FALSE;
	}
	return TRUE;
}

void CTetrisWnd::StopTime()
{
	CRect rect;
	for(int row=0; row<nTotalRow; row++) 
	{
        rect.top = row * BOXHEIGHT;
		rect.bottom = row * BOXHEIGHT + BOXHEIGHT;
        
		for(int col=0; col<nTotalCol; col++) 
		{
        	rect.left =  col * BOXWIDTH;
        	rect.right = col * BOXWIDTH + BOXWIDTH;
		    
			if (m_map[row][col] != tsNull)
			{
				m_map[row][col] = tsEnd;
				InvalidateRect(&rect);
				continue;
			}
		}
	}
	
	if (m_bWarMode)
	{
		GetPartnerWnd()->TellStop();
	}
	else if(!(GetPartnerWnd()->m_bBegun))
		PlayRcSound(IDSOUND_CLOSE);
}

void CTetrisWnd::TellStop()
{
	if (m_bWarMode)
	{
		m_nWinCount += m_bBegun ? 1 : 0;
		DisplayScore();

		m_bWinShow = TRUE;
		m_bIsWin = m_bBegun;
		
		CBitmap bitmap;
		bitmap.LoadBitmap(m_bIsWin ? IDB_WIN : IDB_FAIL);

		BITMAP bm;
		bitmap.GetObject(sizeof(bm), &bm);
		bitmap.DeleteObject();

		CRect TetrisRect;
		GetClientRect(&TetrisRect);

		CRect MapRect;

		MapRect.left = (TetrisRect.Width()-bm.bmWidth)/2;
		MapRect.top = (TetrisRect.Height()-bm.bmHeight)/2;
		MapRect.right = MapRect.left + bm.bmWidth;
		MapRect.bottom = MapRect.top + bm.bmHeight;

		InvalidateRect(&MapRect);
		UpdateWindow();
		
		PlayRcSound(m_bIsWin ? IDSOUND_LAUGH : IDSOUND_UHOH);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTetrisWnd message handlers -- OnTimer

void CTetrisWnd::OnTimer(UINT nIDEvent)
{
	if(m_nPlayer == 1) // the player is Human
	{
		if(MoveTetris(1, 0))
			return;
	
	    Connect();
    	// if ClearRows() >= 2 then 
		// "GenerateNewBlock();" has run in ClearRows()
		if( !((ClearRows() >= 2) && m_bWarMode) )
			GenerateNewBlock();
	} 
	else if(m_nPlayer == 0) // the player is Computer
	{
		OptimizePos();
		while(MoveTetris(1, 0, FALSE));
		
		Connect();
		UpdateWindow();
		// if ClearRows() >= 2 then 
		// "GenerateNewBlock();" has run in ClearRows()
		if( !((ClearRows() >= 2) && m_bWarMode) )
			GenerateNewBlock();
	}
	// Send net contents
	if (m_bIsMeNetWnd)
	{
		FitForNetView();
		BYTE map[NETVIEWROW][NETVIEWCOL];
		
		for(int row=0; row<nTotalRow; row++)
		{
			for(int col=0; col<nTotalCol; col++) 
			{
				map[row][col] = m_map[row][col];
			}
		}

		for(row=0; row<SHAPEROW; row++) 
		{
    		int mapRow = m_nTetrisTop + row;
			if(mapRow < 0 || mapRow >= nTotalRow) continue;
			
			for(int col=0; col<SHAPECOL; col++) 
			{
				if (m_tetris[row][col]==tsNull) continue;
				int mapCol = m_nTetrisLeft + col;
				if(mapCol<0 || mapCol>=nTotalCol) continue;
				
				map[row][col] = m_tetris[row][col];
			}
		}
		BYTE biMap[25]; // 25 = NETVIEWROW*NETVIEWCOL/8
		memset(biMap, 0, sizeof(biMap));
		int bits = 0;
		int num = 0;
		int offSet = 0;
		BYTE base = 1;
		
		for(row=0; row<nTotalRow; row++)
		{
			for(int col=0; col<nTotalCol; col++) 
			{
				if (map[row][col] != tsNull)
				{
					bits = row*nTotalCol + col;
					offSet = bits%8;
					num = (bits - offSet) / 8;
					biMap[num] = (biMap[num] | (base<<offSet));
				}
			}
		}
		PACKAGE pkg;
		pkg.name = NET_UPDATEVIEW; // Send map 
		pkg.len = sizeof(biMap);
		pkg.buf = (char*)biMap;
		// Guaranteed is assumed
		//CMainFrame::OnPkgReceived(&pkg);
		SendPackage(&pkg, 1); //m_bIsGuaranteed
	}
}

/////////////////////////////////////////////////////////////////////////////
// WM_PAINT message handlers

void CTetrisWnd::OnPaint()
{
	CPaintDC dc(this);

	if (m_bIsMeNetViewWnd)
	{
		CDC dcMem;
		dcMem.CreateCompatibleDC(&dc);

		CBitmap* pOldBmp = dcMem.SelectObject(&m_bmpBand);
		CBrush brSpace(RGB(0, 0, 0));
		CRect rect;
		for(int row=0; row<nTotalRow; row++)
		{
			rect.top = row * BOXHEIGHT;
			rect.bottom = rect.top + BOXHEIGHT;
        
			for(int col=0; col<nTotalCol; col++) 
			{
				rect.left =  col * BOXWIDTH;
        		rect.right = rect.left + BOXWIDTH;
				if(dc.RectVisible(&rect)) 
				{
					if(m_map[row][col] == tsNull) 
					{
						dc.FillRect(&rect, &brSpace);
					}
					else 
					{
						ASSERT( m_map[row][col] >= ts0 && m_map[row][col] <= tsEnd );
						
						dc.BitBlt(rect.left, rect.top, rect.Width(), rect.Height(),
							&dcMem, m_map[row][col]*BOXWIDTH, 0, SRCCOPY);
					}
				}
			}
		}
		return;	
		dcMem.SelectObject(pOldBmp);
	}
	
	BYTE map[TOTALROW][TOTALCOL];
	memcpy(map, m_map, sizeof(map));

	for(int row=0; row<SHAPEROW; row++) 
	{
    	int mapRow = m_nTetrisTop + row;
		if(mapRow < 0 || mapRow >= nTotalRow) continue;
		
		for(int col=0; col<SHAPECOL; col++) 
		{
			if (m_tetris[row][col]==tsNull) continue;
			int mapCol = m_nTetrisLeft + col;
			if(mapCol<0 || mapCol>=nTotalCol) continue;
			
			map[mapRow][mapCol] = m_tetris[row][col];
		}
	}
	
	CDC dcMem;
	dcMem.CreateCompatibleDC(&dc);

	CBitmap* pOldBmp = dcMem.SelectObject(&m_bmpBand);
	CRect rect;
	CBrush brSpace(RGB(0, 0, 0));
	for(row=0; row<nTotalRow; row++)
	{
        rect.top = row * BOXHEIGHT;
		rect.bottom = rect.top + BOXHEIGHT;
        
		for(int col=0; col<nTotalCol; col++) 
		{
			rect.left =  col * BOXWIDTH;
        	rect.right = rect.left + BOXWIDTH;
		    
			if(dc.RectVisible(&rect)) 
			{
				if(map[row][col] == tsNull) 
				{
					dc.FillRect(&rect, &brSpace);
				}
				else 
				{
					ASSERT( map[row][col] >= ts0 && map[row][col] <= tsEnd );
	                
	                dc.BitBlt(rect.left, rect.top, rect.Width(), rect.Height(),
						&dcMem, map[row][col]*BOXWIDTH, 0, SRCCOPY);
				}
			}
		}
	}
	DrawWinOrFail(&dc);
	dcMem.SelectObject(pOldBmp);
}

void CTetrisWnd::DrawWinOrFail(CDC* pDC)
{
	if (m_bWinShow)
	{
		CBitmap bitmap;
		bitmap.LoadBitmap(m_bIsWin ? IDB_WIN : IDB_FAIL);
	
	    CDC dcMem;
		dcMem.CreateCompatibleDC(pDC);
	    CBitmap* pOldBmp = dcMem.SelectObject(&bitmap);
	
	    BITMAP bm;
	    bitmap.GetObject(sizeof(bm), &bm);
	    
	    CRect rect;
		GetClientRect(&rect);
		
		pDC->BitBlt((rect.Width()-bm.bmWidth)/2, (rect.Height()-bm.bmHeight)/2, 
	    	bm.bmWidth, bm.bmHeight, &dcMem, 0, 0, SRCCOPY);
	
		dcMem.SelectObject(pOldBmp)->DeleteObject();
	}
}

/////////////////////////////////////////////////////////////////////////////
// Computer handlers

void CTetrisWnd::ToCountBest(COMMPUTERMETHOD* CommputerMethod)
{
	for(int Col=-2; Col<nTotalCol; Col++)
	{
		m_nTetrisLeft = Col;

		BOOL bPass = FALSE;
		for(int nCol=0; (!bPass) && (nCol<SHAPECOL); nCol++)
		{
			for (int nRow=0; (!bPass) && (nRow<SHAPEROW); nRow++)
			{
				if( (m_tetris[nRow][nCol] != tsNull) &&
					((m_nTetrisLeft + nCol) >= nTotalCol || 
					(m_nTetrisLeft + nCol) < 0) )
					
					bPass = TRUE;
			}
		}
        if(bPass) continue;

		m_nTetrisTop = 0;
		
		while(MoveTetris(1, 0, FALSE, FALSE));

		int nMaxOld = 0;
		for (nCol=0; nCol<SHAPECOL; nCol++)
		{
			for (int nRow=0; nRow<SHAPEROW; nRow++)
			{
				if(m_tetris[nRow][nCol] != tsNull)
				{
					if( ((m_nTetrisTop + nRow + 1) >= nTotalRow) ||
						((nRow+1 < SHAPEROW) && (m_tetris[nRow+1][nCol] != tsNull)) ||
						(m_map[m_nTetrisTop + nRow + 1][m_nTetrisLeft + nCol] != tsNull))
						
						nMaxOld += (m_nTetrisTop + nRow) * 2;
					else
						nMaxOld += (m_nTetrisTop + nRow);
				}
			}
		}

		if(nMaxOld >= CommputerMethod->m_nMaxNew)
		{ 
			CommputerMethod->m_nMaxNew = nMaxOld;
			CommputerMethod->m_nTetrisLeftNew = m_nTetrisLeft;
			CommputerMethod->m_nTetrisTopNew = m_nTetrisTop;
			CommputerMethod->m_nTimeNew = m_nRotate;
		}
	} // for(int row=-
}

void CTetrisWnd::OptimizePos()
{
	BYTE m_newTetris[SHAPEROW][SHAPECOL];
	memcpy(m_newTetris, m_tetris, sizeof(m_newTetris));
	
	COMMPUTERMETHOD CommputerMethod;
	
	CommputerMethod.m_nMaxNew = 0;
	CommputerMethod.m_nTimeNew = 0;
	CommputerMethod.m_nTetrisLeftNew = 0;
	CommputerMethod.m_nTetrisTopNew = 0;
	
	switch(m_ts)
	{
		case ts0:
		{
			/* O */
			ToCountBest(&CommputerMethod);
			break;
		}	
		case ts1:
		{
			/* I */
			// row Add 1
			for (int i=0 ;i<2; i++)
			{
				ToCountBest(&CommputerMethod);
				m_nTetrisLeft = 0;					
				m_nTetrisTop = 0;
				MoveRotate(FALSE);		
			}				
			break;
		}
		case ts2:
		{
			/* L */
			for (int i=0 ;i<4; i++)
			{
				ToCountBest(&CommputerMethod);
				m_nTetrisLeft = 0;					
				m_nTetrisTop = 0;
				MoveRotate(FALSE);
			}				
			break;
		}
		case ts3:
		{
			/* L */
			for (int i=0 ;i<4; i++)
			{
				ToCountBest(&CommputerMethod);
				m_nTetrisLeft = 0;
				m_nTetrisTop = 0;
				MoveRotate(FALSE);		
			}				
			break;
		}
		case ts4:
		{
			/* S */
			for (int i=0 ;i<2; i++)
			{
				ToCountBest(&CommputerMethod);
				m_nTetrisLeft = 0;
				m_nTetrisTop = 0;
				MoveRotate(FALSE);		
			}				
			break;
		}
		case ts5:
		{
			/* S */
			for (int i=0 ;i<2; i++)
			{
				ToCountBest(&CommputerMethod);
				m_nTetrisLeft = 0;
				m_nTetrisTop = 0;
				MoveRotate(FALSE);		
			}				
			break;
		}
		case ts6:
		{
			/* T */
			for (int i=0 ;i<4; i++)
			{
				ToCountBest(&CommputerMethod);
				m_nTetrisLeft = 0;
				m_nTetrisTop = 0;
				MoveRotate(FALSE);		
			}
			break;
		}
		default:
		{
			ASSERT(FALSE);
		}					
	}//switch(m_ts)
			
	m_nTetrisLeft = 3;
	m_nTetrisTop = 0;
	m_nRotate = 0;
	memcpy( m_tetris, m_newTetris, sizeof(m_newTetris));		

	int Once = 0;
	while(m_nRotate < CommputerMethod.m_nTimeNew)
	{
		if (Once > 3) break;
		
		MoveRotate(FALSE);
		Once ++;
	}
	Once = 0;		
	if (CommputerMethod.m_nTetrisLeftNew > m_nTetrisLeft)
	{
		while( CommputerMethod.m_nTetrisLeftNew > m_nTetrisLeft)
		{
			if (Once > nTotalCol) break;
			
			MoveTetris(0, 1, FALSE);
			Once ++;
		}
	}
	else
	{
		while(CommputerMethod.m_nTetrisLeftNew < m_nTetrisLeft)
		{
			if (Once > nTotalCol) break;
			
			MoveTetris(0, -1, FALSE);
			Once ++;
		}
	}

	UpdateWindow();
} // OptimizePos()

/////////////////////////////////////////////////////////////////////////////
// Move handlers

void CTetrisWnd::MoveRotate(BOOL draw)
{
	BYTE m_newTetris[SHAPEROW][SHAPECOL];
	memcpy(m_newTetris, m_tetris, sizeof(m_newTetris));
	
	memcpy(m_tetris, enumRotateTetris[m_ts][(m_nRotate+1) % 4], sizeof(m_tetris));
	
	if (draw && !MoveTetris(0, 0))
	{
		memcpy(m_tetris, m_newTetris, sizeof(m_newTetris));
		return;
	}
	else if (!MoveTetris(0, 0, FALSE, FALSE)) return;
	
	ASSERT(m_nRotate < 4);
	m_nRotate = (m_nRotate+1)%4;
}

BOOL CTetrisWnd::MoveTetris(int row, int col, BOOL bRedraw/*=TRUE*/, BOOL bNodraw/*=TRUE*/)
{
    int oldCol = m_nTetrisLeft;
	int oldRow = m_nTetrisTop;
	
	m_nTetrisLeft += col;
	m_nTetrisTop += row;
	
	for(int nRow=0; nRow<SHAPEROW; nRow++)
	{
		for(int nCol=0; nCol<SHAPECOL; nCol++)
		{
			if(m_tetris[nRow][nCol] != tsNull)
			{
				if ((nRow + m_nTetrisTop) < 0 ||
					(nRow + m_nTetrisTop) >= nTotalRow ||
					(nCol + m_nTetrisLeft) < 0 ||
					(nCol + m_nTetrisLeft) >= nTotalCol ||
					m_map [nRow + m_nTetrisTop][nCol + m_nTetrisLeft] != tsNull)
				{
					m_nTetrisLeft = oldCol;
					m_nTetrisTop = oldRow;
					return FALSE;
				}
			}
		}
	}
	
	if(!bNodraw) return TRUE;
	
	CRect rect;
	rect.left = oldCol * BOXWIDTH;
	rect.top = oldRow * BOXHEIGHT;
	rect.right = rect.left + BOXWIDTH * SHAPECOL;
	rect.bottom = rect.top + BOXHEIGHT * SHAPEROW;
	InvalidateRect(&rect);
	
	rect.left = m_nTetrisLeft * BOXWIDTH;
	rect.top = m_nTetrisTop * BOXHEIGHT;
	rect.right = rect.left + BOXWIDTH * SHAPECOL;
	rect.bottom = rect.top + BOXHEIGHT * SHAPEROW;
	InvalidateRect(&rect);
	
	if(bRedraw) UpdateWindow();
    
	return TRUE;
}//BOOL CTetrisWnd::MoveTetris

/////////////////////////////////////////////////////////////////////////////
// Add handlers

void CTetrisWnd::AllAddTetris(int add, BYTE AddTetris[SHAPEROW][TOTALCOL])
{
	Direction();
	ClsTetris();
	if(!AddRows(add, AddTetris)) return;
	if(!GenerateNewBlock()) return;
}

BOOL CTetrisWnd::AddRows(int add, BYTE AddTetris[SHAPEROW][TOTALCOL])
{
	BOOL nReturn = TRUE;
	
	for (int row=0; row<add; row++)
	{
		for (int j=0; j<nTotalCol; j++)
		{
			for (int i=0; i<nTotalRow; i++)
			{
				if (AddTetris[row][j] == tsNull) break;
				
				if (i==(nTotalRow-1))
				{
					m_map[i][j] = (AddTetris[row][j] == tsEnd) ?
						tsNull : AddTetris[row][j];
				}
				else
					m_map[i][j] = m_map[i+1][j];
				
				CRect rect;
				rect.left = j * BOXWIDTH;
				rect.top = i * BOXHEIGHT;
				rect.right = rect.left + BOXWIDTH;
				rect.bottom = rect.top + BOXHEIGHT;
				InvalidateRect(&rect);
				
				if ( (i==0) && (m_map[i][j] != tsNull) && (nReturn == TRUE))
				{
					EndTheGame();
					nReturn = FALSE;
				}
	    	}//for (int i=
	    }//for (int j=
	}//for (int row=
	
	UpdateWindow();
	return nReturn;
}//BOOL CTetrisWnd::AddRows(int add)	

void CTetrisWnd::Connect()
{
	for(int row=0; row<SHAPEROW; row++) 
	{
    	int mapRow = m_nTetrisTop + row;
		if(mapRow < 0 || mapRow >= nTotalRow) continue;
		
		for(int col=0; col<SHAPECOL; col++) 
		{
			if(m_tetris[row][col] == tsNull) continue;
			int mapCol = m_nTetrisLeft + col;
			if(mapCol < 0 || mapCol >= nTotalCol) continue;
			
			m_map[mapRow][mapCol] = m_tetris[row][col];
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// Clear handlers

void CTetrisWnd::ClsTetris()
{
	for(int row=0; row<SHAPEROW; row++) 
	{
    	int mapRow = m_nTetrisTop + row;
		if(mapRow < 0 || mapRow >= nTotalRow) continue;
		
		for(int col=0; col<SHAPECOL; col++) 
		{
			if(m_tetris[row][col] == tsNull) continue;
			int mapCol = m_nTetrisLeft + col;
			if(mapCol < 0 || mapCol >= nTotalCol) continue;
			
			m_map[mapRow][mapCol] = tsNull;
			
			CRect rect;
			rect.left = mapCol * BOXWIDTH;
			rect.top = mapRow * BOXHEIGHT;
			rect.right = rect.left + BOXWIDTH * SHAPECOL;
			rect.bottom = rect.top + BOXHEIGHT * SHAPEROW;
			
			InvalidateRect(&rect);	
		}
	}
	
	memset(m_tetris, tsNull, sizeof(m_tetris));
	UpdateWindow();
}

int CTetrisWnd::ClearRows()
{
	int add = 0;
    BYTE AddTetris[SHAPEROW][TOTALCOL];
	memset(AddTetris, tsNull, sizeof(AddTetris));
	
	BOOL ClearRow[TOTALROW];
	memset(ClearRow, FALSE, sizeof(ClearRow));
	
	for(int row=m_nTetrisTop; row<(m_nTetrisTop + SHAPEROW); row++)
	{
		BOOL IsGroupFull = TRUE;
		int nGroupStart = 0;
		for(int col=0; col<nTotalCol; col++)
		{
			if (row < 0 || row >= nTotalRow || col < 0 || col >= nTotalCol) break;
			if (m_map[row][col] == tsNull)
			{
				IsGroupFull = FALSE;
				continue;
			}
			if( (IsGroupFull == TRUE) && 
				(((m_map[row][col] == tsEnd) && ((col > 0) && (col < (nTotalCol-1)))) ||// if the tsEnd  on th left or right hand-side is not correct
				(col >= (nTotalCol-1))) )
			{
				// Clear Rows At Here //
				if ( col >= (nTotalCol-1) ) col++;
				for(int i=nGroupStart; i<col; i++)
					AddTetris[add][i] = m_map[row][i];
				
				for(int nCol=0; nCol<SHAPECOL; nCol++)
				{
					if(m_tetris[row - m_nTetrisTop][nCol] != tsNull)
						AddTetris[add][nCol + m_nTetrisLeft] = tsEnd;
				}
								
				for (int j=nGroupStart; j<col; j++)
				{
					for (int i=row; i>=0; i--)
					{
						if (m_map[i][j] == tsEnd) break;
						if (m_map[i][j] != m_map[i-1][j])
						{
							if (i == 0)
							{
								if (m_map[i][j] != tsNull)
									m_map[i][j] = tsNull;
								else
									break;
							}
							else
							{
								m_map[i][j] = m_map[i-1][j];
							}
								
							CRect rect;
							
							rect.left = j * BOXWIDTH;
							rect.top = i * BOXHEIGHT;
							rect.right = rect.left + BOXWIDTH;
							rect.bottom = rect.top + BOXHEIGHT;
							
							InvalidateRect(&rect);
	                    }
			    	}
			    }
				add ++;
				ClearRow[row] = TRUE;
			}
			if (m_map[row][col] == tsEnd)
			{
				IsGroupFull = TRUE;
				nGroupStart = (col+1);
			}
		}//for(int col=
	}//for(int row=
		
	memset(m_tetris, tsNull, sizeof(m_tetris));

	// Let the clear row to shine brightly
	// if you want thr row to shine when they'll be cleared
	// Please delete " && FALSE "
	if(add && FALSE)
	{
		CClientDC dc(this);
		for (int a=0; a<2; a++)
		{
			for (int i=0; i<nTotalRow; i++)
			{
				if (ClearRow[i])
				{	
					for (int j=0; j<nTotalCol; j++)
					{
						dc.PatBlt(j * BOXWIDTH, i * BOXWIDTH,
							BOXWIDTH, BOXHEIGHT, DSTINVERT);
					}
				}
			}
			Delay(100);
	    }
	    UpdateWindow();
	}
	
	// Add Other Rows
	m_lScore += 100 * add * add + 10;
	m_lLines += add;
	m_nLevel = int(m_lScore / 5000);
	DisplayScore();

	if (m_nPlayer == 1) // refer to the human
		SetTimer(ID_TIMER, BASETIMER - (int((m_lScore % 2000) / 2)), NULL);
		
	SetLoopSound();
	
	if( (add >= 2) && m_bWarMode )
	{
		GenerateNewBlock();
		if (m_bIsMeNetWnd)
		{
			BYTE biMap[5]; // 25 = SHAPEROW*TOTALCOL/8
			memset(biMap, 0, sizeof(biMap));
			int bits = 0;
			int num = 0;
			int offSet = 0;
			BYTE base = 1;
			
			for(row=0; row<SHAPEROW; row++)
			{
				for(int col=0; col<nTotalCol; col++) 
				{
					if (AddTetris[row][col] != tsEnd)
					{
						bits = row*nTotalCol + col;
						offSet = bits%8;
						num = (bits - offSet) / 8;
						biMap[num] = (biMap[num] | (base<<offSet));
					}
				}
			}
			PACKAGE pkg;
			pkg.name = NET_ADDROWS+add;
			pkg.len = sizeof(biMap);
			pkg.buf = (char*)biMap;
			// Guaranteed is assumed
			SendPackage(&pkg, 1); //m_bIsGuaranteed
			//CMainFrame::OnPkgReceived(&pkg);
		}
		else
		{
			if (GetPartnerWnd()->m_bBegun)
				GetPartnerWnd()->AllAddTetris(add, AddTetris);
		}
		SetLoopSound(TRUE);
	}
	return add;
}//ClearRows()

/////////////////////////////////////////////////////////////////////////////
// Other helpers

void CTetrisWnd::SetLoopSound(BOOL bRePeat/*FALSE*/)
{
	long lScore = GetPartnerWnd()->m_lScore > m_lScore ?
		GetPartnerWnd()->m_lScore : m_lScore;
	if (lScore%2000 > 1500)
	{
		if ((m_nPreviousScore != 3) || bRePeat)
		{
			m_nPreviousScore = 3;
			PlayRcSound(IDSOUND_LOOP3, TRUE, TRUE);
		}
	}
	else if (lScore%2000 > 700)
	{
		if((m_nPreviousScore != 2) || bRePeat)
		{
			m_nPreviousScore = 2;
			PlayRcSound(IDSOUND_LOOP2, TRUE, TRUE);
		}
	}
	else if (lScore%2000 >= 0)
	{
		if ((m_nPreviousScore != 1) || bRePeat)
		{
		 	m_nPreviousScore = 1;
			PlayRcSound(IDSOUND_LOOP1, TRUE, TRUE);
		}
	}
}
			
BOOL CTetrisWnd::IsMovementKey(UINT nChar)
{
	if (m_nPlayer != 1 || !m_bBegun)
		return FALSE;
	
	if(nChar == m_keys.left)
		MoveTetris(0, -1);
		
	else if(nChar == m_keys.right)
		MoveTetris(0, 1);
		
	else if(nChar == m_keys.rotate)
	{
		// PlayRcSound(IDSOUND_ROTATE);
		MoveRotate();
	}
	else if(nChar == m_keys.down)
	{
		// PlayRcSound(IDSOUND_DOWN);
		MoveTetris(0, 0 , FALSE);
		
		while(MoveTetris(1, 0, FALSE, FALSE));
			MoveTetris(0, 0);
		
		UpdateWindow();
		
		OnTimer(ID_TIMER);
	}
	else
		return FALSE;

	return TRUE;
}

void CTetrisWnd::Direction()
{
	UINT nID = GetWindowWord(m_hWnd, GWL_ID);
	ASSERT( nID == ID_LEFTWND || nID == ID_RIGHTWND );
	if (nID == ID_LEFTWND)
		GetParent()->SendMessage(WM_DIRECTION, DIR_LEFT);
	else if(nID == ID_RIGHTWND)
		GetParent()->SendMessage(WM_DIRECTION, DIR_RIGHT);

	GetParent()->SendMessage(WM_DIRECTION, DIR_WARMODE);
}

CTetrisWnd* CTetrisWnd::GetPartnerWnd()
{
	UINT nID = GetWindowWord(m_hWnd, GWL_ID);
	ASSERT( nID == ID_LEFTWND || nID == ID_RIGHTWND );
	CWnd* pWnd = GetParent()->GetDlgItem(nID == ID_LEFTWND ? ID_RIGHTWND : ID_LEFTWND);
	ASSERT( pWnd != NULL );
	return (CTetrisWnd*) pWnd;
}

void CTetrisWnd::OnContextMenu(CWnd*, CPoint point)
{
	// CG: This function was added by the Pop-up Menu component

	CMenu menu;
	VERIFY(menu.LoadMenu(CG_IDR_POPUP_TETRIS_WND));

	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup != NULL);

	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
		this);
}

BOOL CTetrisWnd::PreTranslateMessage(MSG* pMsg)
{
	// CG: This block was added by the Pop-up Menu component
	{
		// Shift+F10: show pop-up menu.
		if ((((pMsg->message == WM_KEYDOWN || pMsg->message == WM_SYSKEYDOWN) && // If we hit a key and
			(pMsg->wParam == VK_F10) && (GetKeyState(VK_SHIFT) & ~1)) != 0) ||	// it's Shift+F10 OR
			(pMsg->message == WM_CONTEXTMENU))									// Natural keyboard key
		{
			CRect rect;
			GetClientRect(rect);
			ClientToScreen(rect);

			CPoint point = rect.TopLeft();
			point.Offset(5, 5);
			OnContextMenu(NULL, point);

			return TRUE;
		}
	}

	return CWnd::PreTranslateMessage(pMsg);
}

void CTetrisWnd::EndTheGame() 
{
	if (m_bIsMeNetWnd)
	{
		OnBeginMeNet();
	}
	else if(m_bWarMode)
	{
		EndGame();
		GetPartnerWnd()->EndGame();

		if(AfxMessageBox(IDP_PLAYAGAIN, MB_YESNO | MB_ICONQUESTION) == IDYES)
		{
			m_bGroup = TRUE;
			GetPartnerWnd()->m_bGroup = TRUE;
			AfxGetMainWnd()->PostMessage(WM_COMMAND, ID_GAME_BEGIN);
		}
		else
		{
			m_bGroup = FALSE;
			GetPartnerWnd()->m_bGroup = FALSE;
		}
	}
}

void CTetrisWnd::OnBeginMe() 
{
	m_bIsMeNetWnd = FALSE;
	m_bIsMeNetViewWnd = FALSE;

	PlayRcSound(IDSOUND_BEGIN);
	BeginGame();
	((CTetrisView*)GetParent())->SetFocus();
}

void CTetrisWnd::OnEndMe() 
{
	EndTheGame();
}

void CTetrisWnd::OnEditMe()
{
	CTetrisView* pView = ((CTetrisView*)GetParent());

	pView->EndAllTetrisWnd();
	PlayRcSound(IDSOUND_CHECK, TRUE);

	CEditMap dlg;
	
	UINT nID = GetWindowWord(m_hWnd, GWL_ID);
	ASSERT( nID == ID_LEFTWND || nID == ID_RIGHTWND );
	if (nID == ID_LEFTWND)
	{
		dlg.m_pLeftWnd = this;
		dlg.m_pRightWnd = GetPartnerWnd();
		dlg.m_nEditWndType = 0; // refer to Left window
	}
	else if(nID == ID_RIGHTWND)
	{
		dlg.m_pLeftWnd = GetPartnerWnd();
		dlg.m_pRightWnd = this;
		dlg.m_nEditWndType = 1; // refer to Right window
	}
	dlg.m_pDoc = pView->GetDocument();
	if (dlg.DoModal() == IDOK)
	{
	}
}

void CTetrisWnd::UpDateMap()
{
	m_bWinShow = FALSE;
	memcpy(m_map, m_DocMap, sizeof(m_map));
	memset(m_tetris, tsNull, sizeof(m_tetris));

	InvalidateRect(NULL);
	UpdateWindow();
}

void CTetrisWnd::OnBeginMeNet()
{
	// stop both of the window;
	((CTetrisView*)GetParent())->EndAllTetrisWnd();

	if (((CTetrisView*)GetParent())->m_bIsConnected)
	{
		FitForNetView();

		m_bIsMeNetWnd = TRUE;
		m_bIsMeNetViewWnd = FALSE;
		GetPartnerWnd()->m_bIsMeNetWnd = FALSE;
		GetPartnerWnd()->m_bIsMeNetViewWnd = TRUE;
		
		// Begin as formal
		PlayRcSound(IDSOUND_BEGIN);
		BeginGame();
		((CTetrisView*)GetParent())->SetFocus();
	}
}

void CTetrisWnd::UpdateNetView(char *lpMap)
{
	BYTE biMap[25] = {0}; // 25 = NETVIEWROW*NETVIEWCOL/8
	memcpy(biMap, lpMap, sizeof(biMap));
	int bits = 0;
	int num = 0;
	int offSet = 0;
	BYTE base = 1;
	// add code here
	FitForNetView();

	
	CClientDC dc(this);
	CDC dcMem;
	dcMem.CreateCompatibleDC(&dc);

	CBitmap* pOldBmp = dcMem.SelectObject(&m_bmpBand);
	CBrush brSpace(RGB(0, 0, 0));
	CRect rect;
	for(int row=0; row<nTotalRow; row++)
	{
		rect.top = row * BOXHEIGHT;
		rect.bottom = rect.top + BOXHEIGHT;
    
		for(int col=0; col<nTotalCol; col++) 
		{
			rect.left =  col * BOXWIDTH;
        	rect.right = rect.left + BOXWIDTH;
			
			bits = row*nTotalCol + col;
			offSet = bits%8;
			num = (bits - offSet) / 8;
			BOOL bBlock =  (biMap[num] & (base<<offSet)) ? TRUE: FALSE;
			if(((m_map[row][col] == tsNull) && bBlock) ||
				((m_map[row][col] != tsNull) && !bBlock)) 
			{
				m_map[row][col] = bBlock ? tsNet : tsNull; // 0 color is assumed
				//InvalidateRect(&rect);
				
				if(m_map[row][col] == tsNull) 
				{
					dc.FillRect(&rect, &brSpace);
				}
				else 
				{
					ASSERT( m_map[row][col] >= ts0 && m_map[row][col] <= tsEnd );
					
					dc.BitBlt(rect.left, rect.top, rect.Width(), rect.Height(),
						&dcMem, m_map[row][col]*BOXWIDTH, 0, SRCCOPY);
				}
			}
		}
	}
	dcMem.SelectObject(pOldBmp);
	/*
	CRect rect;
	for(int row=0; row<nTotalRow; row++)
	{
        rect.top = row * BOXHEIGHT;
		rect.bottom = rect.top + BOXHEIGHT;
        
		for(int col=0; col<nTotalCol; col++) 
		{
			rect.left =  col * BOXWIDTH;
        	rect.right = rect.left + BOXWIDTH;
		    if(map[row][col] != m_map[row][col]) 
			{
				m_map[row][col] = map[row][col];
				InvalidateRect(&rect);
			}
		}
	}
	UpdateWindow();
	*/
}

void CTetrisWnd::FitForNetView()
{
	if ((nTotalRow != NETVIEWROW) || (NETVIEWCOL != nTotalCol))
	{
		CTetrisWnd::nTotalRow = NETVIEWROW;
		CTetrisWnd::nTotalCol = NETVIEWCOL;
		((CTetrisView*)GetParent())->UpdateAllMyChildWndRect();
	}
}

void CTetrisWnd::AddTetrisNet(int add, char *lpMap)
{
	memcpy(m_netAddRow.biAddMap, lpMap, sizeof(m_netAddRow.biAddMap));
	m_netAddRow.row = add;
	PostMessage(NET_ADDROW);

	/*
	BYTE biMap[5] = {0}; // 25 = SHAPEROW*TOTALCOL/8
	memcpy(biMap, lpMap, sizeof(biMap));
	int bits = 0;
	int num = 0;
	int offSet = 0;
	BYTE base = 1;
	
	BYTE AddTetris[SHAPEROW][TOTALCOL]; // 0 color is assumed
	memset(AddTetris, tsNet, sizeof(AddTetris));
	for(int row=0; row<add; row++)
	{
		for(int col=0; col<nTotalCol; col++) 
		{
			bits = row*nTotalCol + col;
			offSet = bits%8;
			num = (bits - offSet) / 8;
			BOOL bBlock =  (biMap[num] & (base<<offSet)) ? TRUE: FALSE;
			if(!bBlock)
			{
				AddTetris[row][col] = tsEnd; // tsEnd means leak block
			}
		}
	}
	memcpy(m_netAddRow.biAddMap, biMap, sizeof(biMap));
	m_netAddRow.row = add;
	PostMessage(NET_ADDROW);
	/*
	ClsTetris();
	if(!AddRows(add, AddTetris)) return;
	if(!GenerateNewBlock()) return;
	*/
}

LRESULT CTetrisWnd::OnNetAddrow(WPARAM wParam, LPARAM lParam)
{
	BYTE* biMap = m_netAddRow.biAddMap;
	int add = m_netAddRow.row;
	int bits = 0;
	int num = 0;
	int offSet = 0;
	BYTE base = 1;
	
	BYTE AddTetris[SHAPEROW][TOTALCOL];
	memset(AddTetris, tsNet, sizeof(AddTetris));
	
	for(int row=0; row<add; row++)
	{
		for(int col=0; col<nTotalCol; col++) 
		{
			bits = row*nTotalCol + col;
			offSet = bits%8;
			num = (bits - offSet) / 8;
			BOOL bBlock =  (biMap[num] & (base<<offSet)) ? TRUE: FALSE;
			if(!bBlock)
			{
				AddTetris[row][col] = tsEnd; // tsEnd means leak block
			}
		}
	}
	ClsTetris();
	if(!AddRows(add, AddTetris)) return 1;
	if(!GenerateNewBlock()) return 1;
	return 1;
}

// tetris.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "tetris.h"
#include <mmsystem.h>

#include "MainFrm.h"
#include "tetrisDoc.h"
#include "tetrisView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTetrisApp

BEGIN_MESSAGE_MAP(CTetrisApp, CWinApp)
	//{{AFX_MSG_MAP(CTetrisApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTetrisApp construction

CTetrisApp::CTetrisApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTetrisApp object

CTetrisApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTetrisApp initialization

BOOL CTetrisApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CTetrisDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CTetrisView));
	AddDocTemplate(pDocTemplate);

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	if (cmdInfo.m_bShowSplash && m_pStartWnd.Create(m_pMainWnd))
	{
		m_pStartWnd.ShowWindow(SW_SHOW);
		m_pStartWnd.UpdateWindow();
	}
	m_dwSplashTime = ::GetCurrentTime();

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();
	
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CTetrisApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CTetrisApp commands

BOOL CTetrisApp::OnIdle(LONG lCount) 
{
	// call base class idle first
	BOOL bResult = CWinApp::OnIdle(lCount);

	// then do our work
	if (m_pStartWnd.m_hWnd != NULL)
	{
		if (::GetCurrentTime() - m_dwSplashTime > 10000)
		{
			// timeout expired, destroy the splash window
			m_pStartWnd.DestroyWindow();
			m_pMainWnd->UpdateWindow();

			// NOTE: don't set bResult to FALSE,
			//  CWinApp::OnIdle may have returned TRUE
		}
		else
		{
			// check again later...
			bResult = TRUE;
		}
	}

	return bResult;
}

BOOL CTetrisApp::PreTranslateMessage(MSG* pMsg) 
{
	BOOL bResult = CWinApp::PreTranslateMessage(pMsg);

	if (m_pStartWnd.m_hWnd != NULL &&
		(pMsg->message == WM_KEYDOWN ||
		 pMsg->message == WM_SYSKEYDOWN ||
		 pMsg->message == WM_LBUTTONDOWN ||
		 pMsg->message == WM_RBUTTONDOWN ||
		 pMsg->message == WM_MBUTTONDOWN ||
		 pMsg->message == WM_NCLBUTTONDOWN ||
		 pMsg->message == WM_NCRBUTTONDOWN ||
		 pMsg->message == WM_NCMBUTTONDOWN))
	{
		m_pStartWnd.DestroyWindow();
		m_pMainWnd->UpdateWindow();
	}

	return bResult;
}

void Delay(DWORD dwMs)
{
	DWORD dwTime=GetTickCount();
	while ((GetTickCount()-dwTime)<dwMs){};
}

BOOL FindSoundFile(UINT nIDS, CString* str)
{
	switch(nIDS)
	{
	case IDSOUND_WELCOME:
		{
			*str = "blindmce";
			break;
		}
	case IDSOUND_GOODBYE:
		{
			*str = "goodbye";
			break;
		}
	case IDSOUND_OPEN:
		{
			*str = "open";
			break;
		}
	case IDSOUND_CHECK:
		{
			*str = "creak";
			break;
		}
	case IDSOUND_CLOSE: //no5
		{
			*str = "close";
			break;
		}
	case IDSOUND_OK:
		{
			*str = "ok";
			break;
		}
	case IDSOUND_CANCEL:
		{
			*str = "cancel";
			break;
		}
	case IDSOUND_NEWBLOCK:
		{
			*str = "droplet";
			break;
		}
	case IDSOUND_DOWN:
		{
			*str = "down";
			break;
		}
	case IDSOUND_ROTATE://no10
		{
			*str = "wop";
			break;
		}
	case IDSOUND_SENDROW:
		{
			*str = "powrdrvr";
			break;
		}
	case IDSOUND_LOOP1:
		{
			*str = "loop1";
			break;
		}
	case IDSOUND_LOOP2:
		{
			*str = "loop1";
			break;
		}
	case IDSOUND_LOOP3:
		{
			*str = "loop1";
			break;
		}
	case IDSOUND_UHOH:
		{
			*str = "uhoh";
			break;
		}
	case IDSOUND_LAUGH:
		{
			*str = "laugh3";
			break;
		}
	case IDSOUND_MINIMIZE:
		{
			*str = "minimize";
			break;
		}
	case IDSOUND_BEGIN:
		{
			*str = "hockey";
			break;
		}
	case IDSOUND_HELP: //no19
		{
			*str = "help!";
			break;
		}
	default:
		{
			return FALSE;
		}
	}
	return TRUE;
}

void PlayRcSound(UINT nIDS, BOOL bAsync/*FALSE*/, BOOL bLoop/*FALSE*/)
{
	// if isn't select sound
	if (!(CMainFrame::m_bIsSoundOn))
		return;
	
	CString str;
	BOOL bOk = FindSoundFile(nIDS, &str);
	ASSERT(bOk);
	str = "res\\"+str;
	if (bAsync)
	{
		if(bLoop)
		{
			bOk = sndPlaySound(str, 
				SND_NODEFAULT|SND_ASYNC|SND_LOOP);
		}
		else
		{
			bOk = sndPlaySound(str,
				SND_NODEFAULT|SND_ASYNC);
		}
	}
	else
	{
		bOk = sndPlaySound(str,
			SND_NODEFAULT|SND_SYNC);
	}
	if (!bOk)
		AfxMessageBox(IDS_CANNOT_PLAY_SOUND);
}

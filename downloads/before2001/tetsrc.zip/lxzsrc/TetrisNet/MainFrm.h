// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

class CTetrisWnd;
class CWarMode;
class CTetrisView;
//class CDlgChat;

#include "cnntport.h" // connect.dll lib header
#include "defNet.h" // My NET_MESSAGE defines

class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
	static int OnPkgReceived(LPPACKAGE pkg);


	BOOL m_bPause;
    void Initial();
	void Terminal();
	static BOOL m_bIsSoundOn;	// write to *.INI
	
	void Pause();
	void UnPause();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	static CTetrisView* m_pMyView;
	BOOL m_bIsConnected;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar m_wndTool;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnGameBegin();
	afx_msg void OnGameOptions();
	afx_msg void OnSound();
	afx_msg void OnUpdateSound(CCmdUI* pCmdUI);
	afx_msg void OnMinwindow();
	afx_msg void OnPause();
	afx_msg void OnUpdatePause(CCmdUI* pCmdUI);
	afx_msg void OnDestroy();
	afx_msg void OnClose();
	afx_msg void OnContextHelp();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnConnect();
	afx_msg void OnUpdateConnect(CCmdUI* pCmdUI);
	afx_msg void OnGuaranteed();
	afx_msg void OnChatShow();
	afx_msg void OnUpdateChatShow(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#define MAINWND_WIDTH GetSystemMetrics(SM_CXSCREEN)
#define MAINWND_HEIGHT GetSystemMetrics(SM_CYSCREEN)

/////////////////////////////////////////////////////////////////////////////

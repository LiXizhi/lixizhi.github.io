// tetris.h : main header file for the TETRIS application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "start.h"

struct KEYRESULT
{
	UINT left;
	UINT right;
	UINT rotate;
	UINT down;
};

enum TETRISSHAPE {ts0, ts1, ts2, ts3, ts4, ts5, ts6, tsNet, tsEnd, tsNull};

#define MAX_MENCOUNT 10
#define TOTALROW 27
#define TOTALCOL 18
#define SHAPEROW 4
#define SHAPECOL 4
#define BASETIMER		1100
#define ID_TIMER 		102

#define TETWND_TOP (HEIGHT_NEXTBLOCK+TOP_NEXTBLOCK+25)
#define TETFRAME_WIDTH 24
#define TETFRAME_HEIGHT 24
#define TETFRAME_ENTRANCE 90
#define TETFRAME_SHADOW 2
#define WARWND_HEIGHT 30

#define BOXWIDTH  14
#define BOXHEIGHT 14

#define MAINWND_LEFT 5
#define MAINWND_TOP  5

/////////////////////////////////////////////////////////////////////////////
// CTetrisApp:
// See tetris.cpp for the implementation of this class
//

class CTetrisApp : public CWinApp
{
public:
	CStartDlg m_pStartWnd;
	DWORD m_dwSplashTime;
	CTetrisApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTetrisApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTetrisApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#define WM_DIRECTION	(WM_USER+10)
#define DIR_WARMODE		0
#define DIR_LEFT		1
#define DIR_RIGHT		2
/////////////////////////////////////////////////////////////////////////////
extern void Delay(DWORD dwMs);
extern void PlayRcSound(UINT nIDS, BOOL bAsync = FALSE, BOOL bLoop = FALSE);
	

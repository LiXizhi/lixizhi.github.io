// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "tetris.h"

#include "MainFrm.h"
#include "tetrisView.h"

#include "tetwnd.h"
#include "nextbloc.h"
#include "warmode.h"
#include "PageEachWindow.h"
#include "PageLeftWindow.h"
#include "PageRightWindow.h"
//#include "DlgChat.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
BOOL CMainFrame::m_bIsSoundOn;
CTetrisView* CMainFrame::m_pMyView;

//CCriticalSection csCriticalSection;

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_GAME_BEGIN, OnGameBegin)
	ON_COMMAND(ID_GAME_OPTIONS, OnGameOptions)
	ON_COMMAND(ID_SOUND, OnSound)
	ON_UPDATE_COMMAND_UI(ID_SOUND, OnUpdateSound)
	ON_COMMAND(ID_MINWINDOW, OnMinwindow)
	ON_COMMAND(ID_PAUSE, OnPause)
	ON_UPDATE_COMMAND_UI(ID_PAUSE, OnUpdatePause)
	ON_WM_DESTROY()
	ON_WM_CLOSE()
	ON_COMMAND(ID_CONTEXT_HELP, OnContextHelp)
	ON_WM_GETMINMAXINFO()
	ON_COMMAND(ID_CONNECT, OnConnect)
	ON_UPDATE_COMMAND_UI(ID_CONNECT, OnUpdateConnect)
	ON_COMMAND(ID_GUARANTEED, OnGuaranteed)
	ON_COMMAND(ID_CHAT_SHOW, OnChatShow)
	ON_UPDATE_COMMAND_UI(ID_CHAT_SHOW, OnUpdateChatShow)
	//}}AFX_MSG_MAP
	// Global help commands
	ON_COMMAND(ID_HELP_FINDER, CFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP, CFrameWnd::OnHelp)
	ON_COMMAND(ID_CONTEXT_HELP, CFrameWnd::OnContextHelp)
	ON_COMMAND(ID_DEFAULT_HELP, CFrameWnd::OnHelpFinder)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_bIsSoundOn = FALSE;
	m_bPause = FALSE;
//	m_bShowChat = FALSE;
	Initial();
}

CMainFrame::~CMainFrame()
{
	Terminal();
}

/////////////////////////////////////////////////////////////////////////////
// Profile functions

void CMainFrame::Initial()
{
	m_bIsSoundOn = AfxGetApp()->GetProfileInt("General", "Sound", FALSE);
}

void CMainFrame::Terminal()
{
	AfxGetApp()->WriteProfileInt("General", "Sound", m_bIsSoundOn);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndTool.Create(this) ||
		!m_wndTool.LoadToolBar(IDR_TOOLBAR))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	m_wndTool.SetBarStyle(m_wndTool.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	m_wndTool.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndTool);
	
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	
	CreateChat(AfxGetMainWnd());

	MoveWindow(CRect(MAINWND_LEFT, MAINWND_TOP,
		MAINWND_LEFT + MAINWND_WIDTH, MAINWND_TOP + MAINWND_HEIGHT));
	CenterWindow();
	
	//PlayRcSound(IDSOUND_WELCOME, TRUE);
	return 0;
}

void CMainFrame::OnDestroy()
{
	PlayRcSound(IDSOUND_GOODBYE);
	LastEndCom(); /////////////////////
	DestroyChat();
	CFrameWnd::OnDestroy();
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	lpMMI->ptMinTrackSize.x = MAINWND_WIDTH;
	lpMMI->ptMinTrackSize.y = MAINWND_HEIGHT;
	
	CFrameWnd::OnGetMinMaxInfo(lpMMI);
}

void CMainFrame::OnClose() 
{
	((CTetrisView*)GetActiveView())->EndAllTetrisWnd();
	CFrameWnd::OnClose();
}

void CMainFrame::OnGameBegin()
{
	CTetrisView* pView = (CTetrisView*)GetActiveView();
	srand((unsigned)GetTickCount());
    pView->EndAllTetrisWnd();
	PlayRcSound(IDSOUND_BEGIN);

	m_bPause = FALSE;
	pView->m_pLeftTetrisWnd->BeginGame();
	pView->m_pRightTetrisWnd->BeginGame();
	pView->SetFocus();
}

void CMainFrame::OnGameOptions()
{
	CTetrisView* pView = (CTetrisView*)GetActiveView();
	pView->EndAllTetrisWnd();
	PlayRcSound(IDSOUND_CHECK, TRUE);
	
	CPropertySheet dlgSheet(IDS_OPTIONS_SHEET);
	CPageLeftWindow pgLeft;
	CPageRightWindow pgRight;
	CPageEachWindow pgEach;
	
	dlgSheet.AddPage(&pgLeft);
	dlgSheet.AddPage(&pgRight);
	dlgSheet.AddPage(&pgEach);
	
	pgEach.m_bWarMode = CTetrisWnd::m_bWarMode;
	pgEach.m_bOnSound = m_bIsSoundOn;
	
	pgLeft.m_nLeftName = pView->m_pLeftTetrisWnd->m_nPlayer;
	pgRight.m_nRightName = pView->m_pRightTetrisWnd->m_nPlayer;

	memcpy(&pgLeft.m_keys, &pView->m_pLeftTetrisWnd->m_keys, sizeof(pView->m_pLeftTetrisWnd->m_keys));
	memcpy(&pgRight.m_keys, &pView->m_pRightTetrisWnd->m_keys, sizeof(pView->m_pRightTetrisWnd->m_keys));

	pgEach.m_nComputerSpeed = pView->m_nComputerSpeed;
	pgEach.m_nHumanSpeed = pView->m_nHumanSpeed;

	pgEach.m_nTotalRow = CTetrisWnd::nTotalRow;
	pgEach.m_nTotalCol = CTetrisWnd::nTotalCol;

	if(dlgSheet.DoModal() == IDOK)
	{
		PlayRcSound(IDSOUND_OK);
		
		if(CTetrisWnd::m_bWarMode != pgEach.m_bWarMode)
		{
			CTetrisWnd::m_bWarMode = pgEach.m_bWarMode;
			
			pView->m_pWarModeWnd->m_pcMode = CWarMode::WARMODE;
			if(CTetrisWnd::m_bWarMode)
				pView->m_pWarModeWnd->ShowWindow(SW_SHOW);
			else
				pView->m_pWarModeWnd->ShowWindow(SW_HIDE);
		}
		m_bIsSoundOn = pgEach.m_bOnSound;

		pView->m_pLeftTetrisWnd->m_nPlayer = pgLeft.m_nLeftName;
		pView->m_pRightTetrisWnd->m_nPlayer = pgRight.m_nRightName;
		pView->UpdateMyNames();

		memcpy(&pView->m_pLeftTetrisWnd->m_keys, &pgLeft.m_keys, sizeof(pView->m_pLeftTetrisWnd->m_keys));
		memcpy(&pView->m_pRightTetrisWnd->m_keys, &pgRight.m_keys, sizeof(pView->m_pRightTetrisWnd->m_keys));
		
		pView->m_nComputerSpeed = pgEach.m_nComputerSpeed;
		pView->m_nHumanSpeed = pgEach.m_nHumanSpeed;
		
		if ((CTetrisWnd::nTotalRow != pgEach.m_nTotalRow) ||
			(CTetrisWnd::nTotalCol != pgEach.m_nTotalCol))
		{
			CTetrisWnd::nTotalRow = pgEach.m_nTotalRow;
			CTetrisWnd::nTotalCol = pgEach.m_nTotalCol;
			pView->UpdateAllMyChildWndRect();
		}
	}
	else
	{
		PlayRcSound(IDSOUND_CANCEL);
	}
}

void CMainFrame::OnContextHelp() 
{
	PlayRcSound(IDSOUND_HELP);
	((CTetrisView*)GetActiveView())->EndAllTetrisWnd();
	WinExec("winhelp.exe tetris.hlp", SW_SHOW);
}

void CMainFrame::OnPause()
{
	if(m_bPause)
		UnPause();
	else
		Pause();
}

void CMainFrame::OnUpdatePause(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_bPause);
	pCmdUI->Enable(((CTetrisView*)GetActiveView())->IsBegin());
}

void CMainFrame::OnMinwindow()
{
	Pause();
	SendMessage(WM_SYSCOMMAND, SC_ICON);
}

void CMainFrame::OnSound()
{
	if (!m_bIsSoundOn) // want to trun on
	{
		m_bIsSoundOn = !m_bIsSoundOn;
		PlayRcSound(IDSOUND_OPEN);
		if (((CTetrisView*)GetActiveView())->IsBegin())
		{
			((CTetrisView*)GetActiveView())->m_pLeftTetrisWnd->SetLoopSound(TRUE); // or RightWnd->.....
		}
	}
	else // want to trun off
	{
		PlayRcSound(IDSOUND_CLOSE);
		m_bIsSoundOn = !m_bIsSoundOn;
	}
}

void CMainFrame::OnUpdateSound(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_bIsSoundOn);
}

/////////////////////////////////////////////////////////////////////////////
// Other helpers

void CMainFrame::Pause()
{
	CTetrisView* pView = (CTetrisView*)GetActiveView();
	m_bPause = TRUE;
	if (pView->m_pLeftTetrisWnd->m_bBegun)
		pView->m_pLeftTetrisWnd->KillTimer(ID_TIMER);
	if(pView->m_pRightTetrisWnd->m_bBegun)
		pView->m_pRightTetrisWnd->KillTimer(ID_TIMER);
}

void CMainFrame::UnPause()
{
	CTetrisView* pView = (CTetrisView*)GetActiveView();
	m_bPause = FALSE;
	if (pView->m_pLeftTetrisWnd->m_bBegun)
		pView->m_pLeftTetrisWnd->SetTimer(ID_TIMER, BASETIMER, NULL);
	if(pView->m_pRightTetrisWnd->m_bBegun)
		pView->m_pRightTetrisWnd->SetTimer(ID_TIMER, BASETIMER, NULL);
}

void CMainFrame::OnConnect() 
{
	CTetrisView* pView = (CTetrisView*)GetActiveView();
	if (pView->m_bIsConnected)
	{
		LastEndCom();
		pView->m_bIsConnected = FALSE;
		pView->m_pLeftTetrisWnd->m_bIsMeNetViewWnd = FALSE;
		pView->m_pLeftTetrisWnd->m_bIsMeNetWnd = FALSE;
		pView->m_pRightTetrisWnd->m_bIsMeNetViewWnd = FALSE;
		pView->m_pRightTetrisWnd->m_bIsMeNetWnd = FALSE;
	}
	else
	{
		if (FirstStartCom(this, CMainFrame::OnPkgReceived) == 1)
		{
			pView->m_bIsConnected = TRUE;
		}
	}
	
}

void CMainFrame::OnUpdateConnect(CCmdUI* pCmdUI) 
{
	CTetrisView* pView = (CTetrisView*)GetActiveView();
	pCmdUI->SetCheck(pView->m_bIsConnected);
}

int CMainFrame::OnPkgReceived(LPPACKAGE pkg)
{
	//if (m_pMyView->m_pRightTetrisWnd->m_bBusy)
		//TRACE("Busy when receive pkg");
	switch(pkg->name)
	{
	case NET_UPDATEVIEW: // View from remoute received
		{
			CTetrisWnd* lpTetrisWnd = NULL;

			if (m_pMyView->m_pLeftTetrisWnd->m_bIsMeNetViewWnd)
				lpTetrisWnd = m_pMyView->m_pLeftTetrisWnd;
			else if (m_pMyView->m_pRightTetrisWnd->m_bIsMeNetViewWnd)
				lpTetrisWnd = m_pMyView->m_pRightTetrisWnd;
			else return TRUE;
			
			lpTetrisWnd->UpdateNetView(pkg->buf);
			break;
		}
	case NET_ADDROWS:
	case NET_ADDROWS2:
	case NET_ADDROWS3:
	case NET_ADDROWS4:
		{
			// this mechniszem is used to caculate the number of rows
			int add = pkg->name - NET_ADDROWS;

			CTetrisWnd* lpTetrisWnd = NULL;

			if (m_pMyView->m_pRightTetrisWnd->m_bIsMeNetWnd)
				lpTetrisWnd = m_pMyView->m_pRightTetrisWnd;
			else if (m_pMyView->m_pLeftTetrisWnd->m_bIsMeNetWnd)
				lpTetrisWnd = m_pMyView->m_pLeftTetrisWnd;
			else return TRUE;
			/*
			else
			{
				if (m_pMyView->m_pRightTetrisWnd->m_bBegun == FALSE)
				{
					m_pMyView->m_pRightTetrisWnd->BeginGame();
				}
				m_pMyView->m_pRightTetrisWnd->m_bIsMeNetViewWnd = FALSE;
				m_pMyView->m_pRightTetrisWnd->m_bIsMeNetWnd = TRUE;
				CString str;
				str.LoadString(IDS_REMOUTE);
				m_pMyView->MessageBox(str);
			}
			*/
			lpTetrisWnd->AddTetrisNet(add, pkg->buf);
			break;
		}
	}
	return TRUE;
}

void CMainFrame::OnGuaranteed() 
{
	//Make a test here
	CString str = "Hello, I am here.";
	PACKAGE pkg;
	pkg.name = CHAT_MESSAGE; // Send map 
	pkg.len = str.GetLength();
	pkg.buf = (char*)str.GetBuffer(pkg.len);
	// Guaranteed is assumed
	SendPackage(&pkg, TRUE); //m_bIsGuaranteed
	//OnPkgReceived(&pkg);
	str.ReleaseBuffer();
}

void CMainFrame::OnChatShow() 
{
	ShowChatWnd(SW_SHOW);
}

void CMainFrame::OnUpdateChatShow(CCmdUI* pCmdUI) 
{
	CTetrisView* pView = (CTetrisView*)GetActiveView();
	pCmdUI->Enable(pView->m_bIsConnected);
}

// tetrisView.h : interface of the CTetrisView class
//
/////////////////////////////////////////////////////////////////////////////
class CTetrisDoc;
class CTetrisWnd;
class CWarMode;
struct SENDNETCONENTS;

class CTetrisView : public CView
{
protected: // create from serialization only
	CTetrisView();
	DECLARE_DYNCREATE(CTetrisView)

public:
	CTetrisWnd* m_pLeftTetrisWnd;
	CComboBox m_cbLeftName;
	CTetrisWnd* m_pRightTetrisWnd;
	CComboBox m_cbRightName;
	CWarMode* m_pWarModeWnd;

	void Initial();
	void Terminal();
	static int m_nHumanSpeed;	// write to *.INI
	static int m_nComputerSpeed;	// write to *.INI

// Attributes
public:
	CTetrisDoc* GetDocument();
	void EndAllTetrisWnd();
	
	void UpdateAllMyChildWndRect();
	void DrawTetrisFrame(CDC* pDC, CTetrisWnd* pTetrisWnd);
	CRect GetNameWindowRect(CTetrisWnd* pTetrisWnd);
	void UpdateMyNames();
	BOOL IsBegin();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTetrisView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo*);
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetNetWnd();
	BOOL m_bIsConnected;
	virtual ~CTetrisView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
// Generated message map functions
protected:
	//{{AFX_MSG(CTetrisView)
	afx_msg LONG OnDirection(WPARAM wParam, LPARAM);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLeftNameSelChange();
	afx_msg void OnRightNameSelChange();
	afx_msg void OnWarmode();
	afx_msg void OnUpdateWarmode(CCmdUI* pCmdUI);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in tetrisView.cpp
inline CTetrisDoc* CTetrisView::GetDocument()
   { return (CTetrisDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

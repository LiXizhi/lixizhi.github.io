// DlgChat.cpp : implementation file
//

#include "stdafx.h"
#include "tetris.h"
#include "DlgChat.h"

#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgChat dialog


CDlgChat::CDlgChat(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgChat::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgChat)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgChat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgChat)
	DDX_Control(pDX, IDC_VIEW, m_wndView);
	DDX_Control(pDX, IDC_INPUT, m_edtInput);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgChat, CDialog)
	//{{AFX_MSG_MAP(CDlgChat)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_HIDEME, OnHideme)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgChat message handlers

void CDlgChat::OnSend() 
{
	CString str;
	m_edtInput.GetWindowText(str);
	char* string = (char*)str.GetBuffer(str.GetLength());
	SendString(string);
	str.ReleaseBuffer();
}

BOOL CDlgChat::Create(CWnd *pParent)
{
	if (!CDialog::Create(CDlgChat::IDD, pParent))
	{
		TRACE0("Warning: creation of CDlgChat dialog failed\n");
		return FALSE;
	}

	return TRUE;
}

BOOL CDlgChat::SendString(LPSTR str)
{
	PACKAGE pkg;
	pkg.name = 1; // Send map 
	pkg.len = lstrlen(str);
	pkg.buf = (char*)str;
	SendPackage(&pkg, TRUE); //m_bIsGuaranteed

	CString string = "Local:>";
	string = string + str;
	ShowChatString(string);
	
	return TRUE;
}

void CDlgChat::ShowChatString(LPCSTR str)
{
	ShowWindow(SW_SHOW);
	CMainFrame::m_bShowChat = TRUE;
	CString string;
	m_wndView.GetWindowText(string);
	string += str;
	string += "\r\n";
	m_wndView.SetWindowText(string);
	int nLines = m_wndView.GetLineCount();
	m_wndView.LineScroll(nLines);
}

void CDlgChat::OnHideme() 
{
	ShowWindow(SW_HIDE);
	CMainFrame::m_bShowChat = FALSE;
}

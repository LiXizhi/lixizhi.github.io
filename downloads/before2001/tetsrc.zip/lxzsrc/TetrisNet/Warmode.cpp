// warmode.cpp : implementation file
//

#include "stdafx.h"
#include "tetris.h"
#include "mainfrm.h"

#include "warmode.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWarMode
#define MOVERECT 90

CWarMode::CWarMode()
{
	m_pcMode = WARMODE;
	
	m_bmpWarMode.LoadBitmap(IDB_WARMODEBMP);
	m_bmpRound.LoadBitmap(IDB_ROUND);
    m_nMoveTime = 0;
	m_nAllTime = 10;
}

CWarMode::~CWarMode()
{
	m_bmpWarMode.DeleteObject();
	m_bmpRound.DeleteObject();
}

BEGIN_MESSAGE_MAP(CWarMode, CWnd)
	//{{AFX_MSG_MAP(CWarMode)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWarMode message handlers


void CWarMode::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	
    BITMAP bm;
    m_bmpWarMode.GetObject(sizeof(bm), &bm);

	// draw war mode bitmap
	CDC dcMem;
	dcMem.CreateCompatibleDC(&dc);
    CBitmap* pOldBmp = dcMem.SelectObject(&m_bmpWarMode);
    
    CRect rect;
    GetClientRect(&rect);

    dc.StretchBlt( rect.left, rect.top, rect.Width(), rect.Height(), &dcMem,
    	0, bm.bmHeight/3*m_pcMode, bm.bmWidth, bm.bmHeight/3, SRCCOPY );
    //dc.BitBlt(0, 0, bm.bmWidth, bm.bmHeight/3, &dcMem,
    //	0, bm.bmHeight/3*m_pcMode, SRCCOPY);
    
    dcMem.SelectObject(pOldBmp);
    
    // draw round bitmap
    m_bmpRound.GetObject(sizeof(bm), &bm);
    
    CRect MoveRect;
    switch (m_pcMode)
    {
    	case WARMODE: 
    		return;
    		break;
    		
    	case RIGHTPOINT:
			MoveRect.right = (rect.Width()-MOVERECT)/2+
				(MOVERECT+bm.bmWidth/2)*m_nMoveTime/m_nAllTime;
			MoveRect.bottom = (rect.Height()-bm.bmHeight)/2+bm.bmHeight;
			MoveRect.left = MoveRect.right-bm.bmWidth/2;
			MoveRect.top = MoveRect.bottom-bm.bmHeight;
			break;
			
    	case LEFTPOINT:
    	    MoveRect.left = (rect.Width()-MOVERECT)/2+MOVERECT-
				(MOVERECT+bm.bmWidth/2)*m_nMoveTime/m_nAllTime;
			MoveRect.top = (rect.Height()-bm.bmHeight)/2;
			MoveRect.right = MoveRect.left+bm.bmWidth/2;
			MoveRect.bottom = MoveRect.top+bm.bmHeight;
			
    		break;
    	default:
    		ASSERT(FALSE);
    }
    
    pOldBmp = dcMem.SelectObject(&m_bmpRound);
    
    dc.BitBlt(MoveRect.left, MoveRect.top,
    	MoveRect.Width(), MoveRect.Height(), &dcMem,
    	bm.bmWidth/2*m_pcMode, 0, SRCCOPY);
	
	dcMem.SelectObject(pOldBmp);
}

void CWarMode::InvalidateMode()
{
	PlayRcSound(IDSOUND_SENDROW, TRUE);
	DrawMoveRect();
}

void CWarMode::RightPoint()
{
	m_pcMode = RIGHTPOINT;
}

void CWarMode::LeftPoint()
{
	m_pcMode = LEFTPOINT;
}

void CWarMode::DrawMoveRect()
{
	BITMAP bm;
	m_bmpRound.GetObject(sizeof(bm), &bm);
    	
	CRect rect;
    GetClientRect(&rect);
        
	rect.left = (rect.Width()-MOVERECT)/2;
	rect.top = (rect.Height()-bm.bmHeight)/2;
	rect.right = rect.left+MOVERECT;
	rect.bottom = rect.top+bm.bmHeight;
	
	do{
		InvalidateRect(&rect);
		UpdateWindow();
		
		DWORD dwTime=GetTickCount();
		while ((GetTickCount()-dwTime)<80)
		{
			MSG msg;
			VERIFY(::GetMessage(&msg, NULL, 0, 0));
			switch (msg.message)
			{
				case WM_KEYDOWN:
					DispatchMessage(&msg);
					break;
				default:
					break;
			}
		}
	}while ((m_nMoveTime++) <= m_nAllTime);
	
	m_pcMode = WARMODE;
	Invalidate();
	UpdateWindow();
	
	m_nMoveTime = 0;
}


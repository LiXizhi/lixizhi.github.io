#if !defined(AFX_DLGCHAT_H__1D4E5F02_AEFD_11D2_92B3_B8E557499261__INCLUDED_)
#define AFX_DLGCHAT_H__1D4E5F02_AEFD_11D2_92B3_B8E557499261__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgChat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgChat dialog

class CDlgChat : public CDialog
{
// Construction
public:
	BOOL Create(CWnd* pParent);
	void ShowChatString(LPCSTR str);
	BOOL SendString(LPSTR str);
	

	CDlgChat(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgChat)
	enum { IDD = IDD_NET_CHAT };
	CEdit	m_wndView;
	CEdit	m_edtInput;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgChat)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgChat)
	afx_msg void OnSend();
	afx_msg void OnHideme();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCHAT_H__1D4E5F02_AEFD_11D2_92B3_B8E557499261__INCLUDED_)

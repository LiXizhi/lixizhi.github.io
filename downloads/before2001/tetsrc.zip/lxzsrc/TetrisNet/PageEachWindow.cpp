// PageEachWindow.cpp : implementation file
//

#include "stdafx.h"
#include "tetris.h"
#include "PageEachWindow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageEachWindow property page

IMPLEMENT_DYNCREATE(CPageEachWindow, CPropertyPage)

CPageEachWindow::CPageEachWindow() : CPropertyPage(CPageEachWindow::IDD)
{
	m_nTotalRow = TOTALROW;
	m_nTotalCol = TOTALCOL;

	//{{AFX_DATA_INIT(CPageEachWindow)
	m_bWarMode = FALSE;
	m_bOnSound = FALSE;
	m_nComputerSpeed = 1;
	m_nHumanSpeed = 1;
	//}}AFX_DATA_INIT
}

CPageEachWindow::~CPageEachWindow()
{
}

void CPageEachWindow::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageEachWindow)
	DDX_Control(pDX, IDC_SPIN_WIDTH, m_spinWidth);
	DDX_Control(pDX, IDC_SPIN_HEIGHT, m_spinHeight);
	DDX_Check(pDX, IDC_WARMODE, m_bWarMode);
	DDX_Check(pDX, IDC_ONSOUND, m_bOnSound);
	DDX_CBIndex(pDX, IDC_COMPUTERSPEED, m_nComputerSpeed);
	DDX_CBIndex(pDX, IDC_HUMANSPEED, m_nHumanSpeed);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageEachWindow, CPropertyPage)
	//{{AFX_MSG_MAP(CPageEachWindow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageEachWindow message handlers

BOOL CPageEachWindow::OnInitDialog()
{
	CPropertyPage::OnInitDialog();
	
	m_spinWidth.SetRange(10, TOTALCOL);
	m_spinWidth.SetPos(m_nTotalCol);
	m_spinHeight.SetRange(20, TOTALROW);
	m_spinHeight.SetPos(m_nTotalRow);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPageEachWindow::OnOK() 
{
	m_nTotalCol = m_spinWidth.GetPos();
	m_nTotalRow = m_spinHeight.GetPos();

	UpdateData(TRUE);
	CPropertyPage::OnOK();
}

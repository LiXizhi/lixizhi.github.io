// nextbloc.cpp : implementation file
//

#include "stdafx.h"
#include "tetris.h"

#include "nextbloc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

BYTE enumRotateTetris[7][4][SHAPEROW][SHAPECOL] =
{
	{	
		{
			{ts0   , ts0   , tsNull, tsNull},
            {ts0   , ts0   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		},//small 0
				
	    {
	    	{ts0   , ts0   , tsNull, tsNull},
            {ts0   , ts0   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 1
		    
	    {
	    	{ts0   , ts0   , tsNull, tsNull},
            {ts0   , ts0   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 2
		    
	    {   
	    	{ts0   , ts0   , tsNull, tsNull},
            {ts0   , ts0   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    } //small 3
	},//medium ts0
	{	
		{
			{tsNull, tsNull, tsNull, tsNull},
            {ts1   , ts1   , ts1   , ts1   },
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		},//small 0
				
	    {
	    	{tsNull, tsNull, ts1   , tsNull},
            {tsNull, tsNull, ts1   , tsNull},
            {tsNull, tsNull, ts1   , tsNull},
            {tsNull, tsNull, ts1   , tsNull}
	    },//small 1 
		    
	    {
	    	{tsNull, tsNull, tsNull, tsNull},
            {ts1   , ts1   , ts1   , ts1   },
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 2
		    
	    {
	    	{tsNull, tsNull, ts1   , tsNull},
            {tsNull, tsNull, ts1   , tsNull},
            {tsNull, tsNull, ts1   , tsNull},
            {tsNull, tsNull, ts1   , tsNull}
	    } //small 3
	},//medium ts1
	{	
		{
    		{tsNull, tsNull, tsNull, tsNull},
            {ts2   , ts2   , ts2   , tsNull},
            {tsNull, tsNull, ts2   , tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 0
		    
	    {
			{tsNull, ts2   , ts2   , tsNull},
            {tsNull, ts2   , tsNull, tsNull},
            {tsNull, ts2   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		},//small 1
		
		{
			{ts2   , tsNull, tsNull, tsNull},
            {ts2   , ts2   , ts2   , tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		},//small 2
		
		{
			{tsNull, ts2   , tsNull, tsNull},
            {tsNull, ts2   , tsNull, tsNull},
            {ts2   , ts2   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		} //small 3
	},//medium ts2
	{	
	    {
	    	{tsNull, tsNull, tsNull, tsNull},
            {ts3   , ts3   , ts3   , tsNull},
            {ts3   , tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 0
		    
	    {
	    	{tsNull, ts3   , tsNull, tsNull},
            {tsNull, ts3   , tsNull, tsNull},
            {tsNull, ts3   , ts3   , tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 1
	    
	    {
			{tsNull, tsNull, ts3   , tsNull},
            {ts3   , ts3   , ts3   , tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		},//small 2
		
		{
	    	{ts3   , ts3   , tsNull, tsNull},
            {tsNull, ts3   , tsNull, tsNull},
            {tsNull, ts3   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    } //small 3
	},//medium ts3
	{	
		{
			{tsNull, ts4   , ts4   , tsNull},
            {ts4   , ts4   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		},//small 0
				
	    {
	    	{ts4   , tsNull, tsNull, tsNull},
            {ts4   , ts4   , tsNull, tsNull},
            {tsNull, ts4   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 1
		    
	    {
	    	{tsNull, ts4   , ts4   , tsNull},
            {ts4   , ts4   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 2
		    
	    {
	    	{ts4   , tsNull, tsNull, tsNull},
            {ts4   , ts4   , tsNull, tsNull},
            {tsNull, ts4   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    } //small 3
	},//medium ts4
	{	
		{
			{ts5   , ts5   , tsNull, tsNull},
            {tsNull, ts5   , ts5   , tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		},//small 0
				
	    {
	    	{tsNull, ts5   , tsNull, tsNull},
            {ts5   , ts5   , tsNull, tsNull},
            {ts5   , tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 1
		    
	    {
	    	{ts5   , ts5   , tsNull, tsNull},
            {tsNull, ts5   , ts5   , tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 2
		    
	    {
	    	{tsNull, ts5   , tsNull, tsNull},
            {ts5   , ts5   , tsNull, tsNull},
            {ts5   , tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    } //small 3
	},//medium ts5
	{	
		{
	    	{tsNull, tsNull, tsNull, tsNull},
            {ts6   , ts6   , ts6   , tsNull},
            {tsNull, ts6   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 0
		    
	    {
	    	{tsNull, ts6   , tsNull, tsNull},
            {tsNull, ts6   , ts6   , tsNull},
            {tsNull, ts6   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    },//small 1
	    
	    {
			{tsNull, ts6   , tsNull, tsNull},
            {ts6   , ts6   , ts6   , tsNull},
            {tsNull, tsNull, tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
		},//small 2
		
		{
	    	{tsNull, ts6   , tsNull, tsNull},
            {ts6   , ts6   , tsNull, tsNull},
            {tsNull, ts6   , tsNull, tsNull},
            {tsNull, tsNull, tsNull, tsNull}
	    } //small 3
	} //medium ts6
};//big

/////////////////////////////////////////////////////////////////////////////
// CNextBlockWnd

CNextBlockWnd::CNextBlockWnd()
{
	memset(m_tetris, tsNull, sizeof(m_tetris));
	memset(m_DrawTetris, tsNull, sizeof(m_DrawTetris));
	m_ts = ts0;
	m_bmpBand.LoadBitmap(IDB_BAND);
}

CNextBlockWnd::~CNextBlockWnd()
{
	m_bmpBand.DeleteObject();
}

BEGIN_MESSAGE_MAP(CNextBlockWnd, CWnd)
	//{{AFX_MSG_MAP(CNextBlockWnd)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNextBlockWnd message handlers

TETRISSHAPE CNextBlockWnd::GetTetris(BYTE tetris[SHAPEROW][SHAPECOL])
{
	memcpy(tetris, m_tetris, sizeof(m_tetris));
	return m_ts;
}

void CNextBlockWnd::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	CDC dcMem;
	dcMem.CreateCompatibleDC(&dc);
	
	CBitmap* pOldBmp = dcMem.SelectObject(&m_bmpBand);
	
	CBrush brush(RGB(192, 192, 192));

	CRect rect;
	
	for(int col=0; col<4; col++) 
	{
        rect.left = col * BOXWIDTH;
        rect.right = rect.left + BOXWIDTH;
        
        for(int row=0; row < 2; row++) 
        {
        	rect.top = row * BOXHEIGHT;
			rect.bottom = rect.top + BOXHEIGHT;
			
			if(dc.RectVisible(&rect)) 
			{
				if(m_DrawTetris[row][col] == tsNull) 
				{
					dc.FillRect(&rect, &brush);
				}
				else 
				{
					ASSERT( m_DrawTetris[row][col] >= ts0 &&
						m_DrawTetris[row][col] <= tsNull );
	
					dc.BitBlt(rect.left, rect.top, rect.Width(), rect.Height(),
						&dcMem, m_DrawTetris[row][col] * BOXWIDTH, 0, SRCCOPY);
				}
			}
			
		}
	}
	
	dcMem.SelectObject(pOldBmp);
}

void CNextBlockWnd::GenerateNewBlock(BOOL bMission /* TRUE */)
{
	if (bMission)
		m_ts = (TETRISSHAPE) ((long(rand()) * 7) / RAND_MAX);
	else
	{
		m_ts = (TETRISSHAPE) ((long(rand()) * 9) / RAND_MAX);
		if(m_ts == 7 || m_ts == 8)
			m_ts = ts1;
	}
   	memcpy(m_tetris, enumRotateTetris[m_ts][0], sizeof(m_tetris));
   	memcpy(m_DrawTetris, m_tetris, sizeof(m_tetris));
   	DrawTetris();
}

void CNextBlockWnd::DrawTetris()
{
	for(int nRow=0; nRow<SHAPEROW; nRow++)
	{
		for(int nCol=0; nCol<SHAPECOL; nCol++)
		{
			if(m_DrawTetris[nRow][nCol] != tsNull)
			{
				if (nRow == 0)
				{
					Invalidate();
					return;
				}
				m_DrawTetris[nRow-1][nCol] = m_DrawTetris[nRow][nCol];
				m_DrawTetris[nRow][nCol] = tsNull;
			}
		}
	}
	Invalidate();
}